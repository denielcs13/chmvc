package userCreation;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import commonController.Md5;

@Controller
public class ForgotPasswordController {

	
	@RequestMapping(value = "/forgotPassword", method= {RequestMethod.GET,RequestMethod.POST})
	public String forgotPassword(Model model,HttpServletRequest request,HttpServletResponse response) {
	
	
	Connection conn;
	HttpSession session=request.getSession();
	String userName=(String)session.getAttribute("userName");
	String flag=request.getParameter("flg")!=null?request.getParameter("flg"):"";
	String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
	request.setAttribute("msg",msg);
	String query=null;
	CallableStatement callableStmt=null;
	String status=null;
	ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
	try {
		
	if(!(flag.equals(""))){
		conn=new Connectionc().getConnection();
		String EncPass="test12345";
		Md5 md5=new Md5(EncPass);			
		byte[] b = md5.getDigest();
		EncPass = md5.stringify(b);
	String UserId=request.getParameter("lname");	
	callableStmt=conn.prepareCall("{call xxbaf_forgot_password(?,?,?,?,?)}");
	
	callableStmt.setString(1, UserId);
	callableStmt.setString(2, EncPass);
	callableStmt.setString(3, "Forgot Pass");
	callableStmt.registerOutParameter(4, Types.VARCHAR);  //status
	callableStmt.setString(5, "");
	
	callableStmt.execute();		
	status=callableStmt.getString(4);
	
	if(status.equals("Y")) {
		request.setAttribute("msg","Password has been sent on your Mail");
	}else {
		request.setAttribute("msg","Login Id Not Found");
	}
	return "forgotPassword";
		
	}else {
		return "forgotPassword";
	}
		
	
	}catch(Exception e) {
		e.printStackTrace();
		request.setAttribute("msg","Some Error Occurred");
		
	}finally {
		if(callableStmt!=null) {callableStmt=null;}
		if(query!=null) {query=null;}

	}
	return "forgotPassword";
}
}
