package userCreation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import commonController.Md5;

@Controller
public class UserCreationController {

	@RequestMapping(value = "/createUser", method = {RequestMethod.GET,RequestMethod.POST}) 
	  
	public String userCreationScreen(Model model,HttpServletRequest request,HttpServletResponse response) { 
		
		Connection conn;
		HttpSession session=request.getSession();
		ResultSet rs=null;
		PreparedStatement ps=null;
		String [] rlm=null;
		String []spuser=null;
		String []location=null;
		String []grade=null;
		ArrayList roleMaster=new ArrayList();
		ArrayList superUserMaster=new ArrayList();
		ArrayList locationMaster=new ArrayList();
		ArrayList gradeMaster=new ArrayList();
		ArrayList departmentList=new ArrayList();
		String[] department=null;
		ArrayList employeeList=new ArrayList();
		String[] employee=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		try {
			String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
			System.out.println("msad Kaean" + msg);
			request.setAttribute("msg", msg);
			conn=new Connectionc().getConnection();
			//String query="select id,upper(role_nm) from role_mstr";
			String query="select id,upper(role_nm) from XXBAF_ROLE_MSTR where id<>1";
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				rlm=new String[2];
			rlm[0]=rs.getString(1);
			rlm[1]=rs.getString(2);
			
			roleMaster.add(rlm);		
				
			}
			if(rs!=null) {rs=null; }
			if(query!=null) {query=null;}
			
			query="select user_name||'-'||employee_code,user_role,user_id from xxbaf_user_mstr where user_status='A' and user_role=3";
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				spuser=new String[3];
				spuser[0]=rs.getString(1);
				spuser[1]=rs.getString(2);
				spuser[2]=rs.getString(3);
			
				superUserMaster.add(spuser);		
				
			}
			
			if(rs!=null) {rs=null; }
			if(query!=null) {query=null;}
			
			query="select LOOKUP_CODE, DESCRIPTION STATE_CODE,TAG  from apps.fnd_lookup_VALUES  where lookup_type = 'AFP_STATE_CODE'  AND ENABLED_FLAG = 'Y'  AND END_DATE_ACTIVE IS NULL";			
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				location=new String[3];
				location[0]=rs.getString(1);
				location[1]=rs.getString(2);
				location[2]=rs.getString(3);
				
				locationMaster.add(location);
			}
			
			if(rs!=null) {rs=null; }
			if(query!=null) {query=null;}
			
			query="select Meaning  from apps.fnd_lookup_values_vl where lookup_type = 'BAF_EMP_GRADE'  and enabled_flag = 'Y' ";			
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				grade=new String[1];
				grade[0]=rs.getString(1);
				
				gradeMaster.add(grade);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getDepartment");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				department=new String[2];
				department[0]=rs.getString(1);
				department[1]=rs.getString(2);
				
				departmentList.add(department);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getEmployeeDesig");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				employee=new String[1];
				employee[0]=rs.getString(1);
								
				employeeList.add(employee);
			}
						
			request.setAttribute("roleMaster", roleMaster);
			request.setAttribute("superUserMaster", superUserMaster);
			request.setAttribute("locationMaster", locationMaster);
			request.setAttribute("gradeMaster", gradeMaster);
			request.setAttribute("departmentList", departmentList);
			request.setAttribute("employeeList", employeeList);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	    return "userCreate"; 
	  }
	
	@RequestMapping(value = "/createnewusr", method = {RequestMethod.GET,RequestMethod.POST}) 
	  
	public String userCreation(Model model,HttpServletRequest request,HttpServletResponse response) { 
		
		Connection conn;
		HttpSession session=request.getSession();
		ResultSet rs=null;
		PreparedStatement ps=null;
		String query=null;
		int countUser=0;
		conn=new Connectionc().getConnection();
		try {
			String userName=request.getParameter("usrName");
			String usrmail=request.getParameter("usrmail");
			String usrRole=request.getParameter("usrRole");
			String login=request.getParameter("logiId");
			String superUser=request.getParameter("superusr");
			String location=request.getParameter("location");
			String department=request.getParameter("department");
			String loc[]=location.split(",");
			String afpsupplierinv=request.getParameter("afpsupplierinv")!=null?request.getParameter("afpsupplierinv"):"";
			String empcheck=request.getParameter("empcheck")!=null?request.getParameter("empcheck"):"";
			String empCode=request.getParameter("empCode")!=null?request.getParameter("empCode"):"";
			String usrgrd=request.getParameter("usrgrd")!=null?request.getParameter("usrgrd"):"";
			String panno=request.getParameter("panno")!=null?request.getParameter("panno"):"";
			String baseloc=request.getParameter("baseloc")!=null?request.getParameter("baseloc"):"";
			String desig=request.getParameter("desig")!=null?request.getParameter("desig"):"";
			String afpdirectAppr=request.getParameter("afpdirectAppr")!=null?request.getParameter("afpdirectAppr"):"";
			
			//query="select count(*) from user_mstr where (user_name=? or user_email=? or loginId=?)";
			query="select count(*) from XXBAF_USER_MSTR where (user_email=? or loginId=?)";
			ps=conn.prepareStatement(query);
			ps.setString(1, userName);
			ps.setString(2, usrmail);
			ps.setString(3, login);
			
			rs=ps.executeQuery();
			
			if(rs.next()) {
				countUser=rs.getInt(1);
			}
			
		if(countUser>0) {
			request.setAttribute("msg", "User Already Created"); 
			return "redirect:/createUser?msg=User Already Created";
		}else {
			String EncPass="test12345";
			Md5 md5=new Md5(EncPass);			
			byte[] b = md5.getDigest();
			EncPass = md5.stringify(b);
			
			//query="insert into user_mstr(user_name,user_email,user_status,user_role,user_pass,loginId) values(?,?,?,?,?,?)";
			query="insert into XXBAF_USER_MSTR(user_name,user_email,user_status,user_role,user_pass,loginId,user_id,supervisor,Location,tag,creation_date,"
					+ "AFPSUPPLIERCHECK,EMPCHECK,EMPLOYEE_CODE,USER_GRADE,PANNUMBER,DEPARTMENT,USER_BASE_LOC,EMP_DESIG,DIRECT_INV_APPR) "
					+ "values(?,?,?,?,?,?,XXBAF_USER_S.nextval,?,?,?,sysdate,?,?,?,?,?,?,?,?,?)";
			ps=conn.prepareStatement(query);
			ps.setString(1, userName);
			ps.setString(2, usrmail);
			ps.setString(3, "A");
			ps.setString(4, usrRole);
			ps.setString(5, EncPass);
			ps.setString(6, login);
			ps.setString(7, superUser);
			ps.setString(8, loc[0]);
			ps.setString(9, loc[1]);
			if(!("".equals(afpsupplierinv))) {
				ps.setString(10, "Y");	
			}else {
				ps.setString(10, "N");
			}
			if(!("".equals(empcheck))) {
				ps.setString(11, "Y");	
			}else {
				ps.setString(11, "N");
			}
			//ps.setString(12, empCode);
			ps.setString(12, login);			
			ps.setString(13, usrgrd);
			ps.setString(14, panno);
			ps.setString(15, department);
			ps.setString(16, baseloc);
			ps.setString(17, desig);
			ps.setString(18, afpdirectAppr);
			
		int a=	ps.executeUpdate();
		if(a==1) {
			request.setAttribute("msg", "User Created Successfully");
			return "welcome";
		}else {
			request.setAttribute("msg", "Some error Occurred");
			return "welcome";
		 }
		}	
			
		}catch(Exception e){
			try {
			e.printStackTrace();
			conn.rollback();
			request.setAttribute("msg", "Some error Occurred");
			return "welcome";
			}catch(Exception e1) {
				
			}
		}
		
	    return ""; 
	  }
	
	@RequestMapping(value = "/usrUpdatePop", method = {RequestMethod.GET,RequestMethod.POST}) 
	  
	public String usrUpdatePop(Model model,HttpServletRequest request,HttpServletResponse response) { 
		
		Connection conn;
		HttpSession session=request.getSession();
		ResultSet rs=null;
		PreparedStatement ps=null;
		String query=null;
		int countUser=0;
		conn=new Connectionc().getConnection();
		try {
			String userName=request.getParameter("usrName");
			String usrmail=request.getParameter("usrmail");
			String usrRole=request.getParameter("usrRole");
			String login=request.getParameter("logiId");
			String superUser=request.getParameter("superusr");
			//String location=request.getParameter("location");
			String department=request.getParameter("department");
			//String loc[]=location.split(",");
			String afpsupplierinv=request.getParameter("afpsupplierinv")!=null?request.getParameter("afpsupplierinv"):"";
			String empcheck=request.getParameter("empcheck")!=null?request.getParameter("empcheck"):"";
			String empCode=request.getParameter("empCode")!=null?request.getParameter("empCode"):"";
			String usrgrd=request.getParameter("usrgrd")!=null?request.getParameter("usrgrd"):"";
			String panno=request.getParameter("panno")!=null?request.getParameter("panno"):"";
			//String baseloc=request.getParameter("baseloc")!=null?request.getParameter("baseloc"):"";
			String desig=request.getParameter("desig")!=null?request.getParameter("desig"):"";
			String afpdirectAppr=request.getParameter("afpdirectAppr")!=null?request.getParameter("afpdirectAppr"):"";
			String usrId=request.getParameter("usrId");
			String usrstatus=request.getParameter("usrstatus");
			
			query="update XXBAF_USER_MSTR set user_name=?,user_email=?,user_status=?,user_role=?,supervisor=?,"
					+ "AFPSUPPLIERCHECK=?,EMPCHECK=?,USER_GRADE=?,PANNUMBER=?,DEPARTMENT=?,EMP_DESIG=?,DIRECT_INV_APPR=? where user_id=?";
			ps=conn.prepareStatement(query);
			ps.setString(1, userName);
			ps.setString(2, usrmail);
			ps.setString(3, usrstatus);
			ps.setString(4, usrRole);
			ps.setString(5, superUser);
			
			if(!("".equals(afpsupplierinv))) {
				ps.setString(6, "Y");	
			}else {
				ps.setString(6, "N");
			}
			if(!("".equals(empcheck))) {
				ps.setString(7, "Y");	
			}else {
				ps.setString(7, "N");
			}
						
			ps.setString(8, usrgrd);
			ps.setString(9, panno);
			ps.setString(10, department);
			ps.setString(11, desig);
			ps.setString(12, afpdirectAppr);
			ps.setString(13, usrId);
			
		int a=	ps.executeUpdate();
		if(a==1) {
			request.setAttribute("msg", "User Updated Successfully");
			return "userSearchPopUp";
		}else {
			request.setAttribute("msg", "Some error Occurred");
			return "userSearchPopUp";
		 }
			
			
		}catch(Exception e){
			try {
			e.printStackTrace();
			conn.rollback();
			request.setAttribute("msg", "Some error Occurred");
			return "welcome";
			}catch(Exception e1) {
				
			}
		}
		
	    return ""; 
	  }
}
