package userCreation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;

@Controller
public class UserSearchController {

	
	@RequestMapping(value = "/searchUserDtls", method = {RequestMethod.GET,RequestMethod.POST}) 
	  
	public String userSearch(Model model,HttpServletRequest request,HttpServletResponse response) { 
		
		Connection conn;
		HttpSession session=request.getSession();
		ResultSet rs=null;
		PreparedStatement ps=null;
		
		try {
			String [] usrlm=null;
			String[] supervisor=null;
			String []location=null;
			String []grade=null;
			ArrayList userMaster=new ArrayList();
			ArrayList superMaster=new ArrayList();
			ArrayList locationMaster=new ArrayList();
			ArrayList gradeMaster=new ArrayList();
			String msg=request.getParameter("msg")!=null?(String)request.getParameter("msg"):"";
			if(msg.equals("")) {
				msg=request.getAttribute("msg")!=null?(String)request.getAttribute("msg"):"";
			}
			System.out.println("msad Kaean" + msg);
			request.setAttribute("msg", msg);
			conn=new Connectionc().getConnection();
			String query=null;
			String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"";
			ArrayList departmentList=new ArrayList();
			String[] department=null;
			ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			if(flag.equals("search")) {
			String userNm=	request.getParameter("userNm");
			 //query="select user_name,user_email,user_status,usrl.role_nm,ms.loginid  from user_mstr ms,role_mstr usrl where ms.user_role=usrl.id and upper(ms.user_name) = upper(?)";
			//query="select user_name,user_email,user_status,usrl.role_nm,ms.loginid,ms.supervisor,ms.user_role,ms.user_id,ms.location,ms.tag from XXBAF_USER_MSTR ms,XXBAF_ROLE_MSTR usrl where ms.user_role=usrl.id and upper(ms.user_name) like nvl(upper('%"+userNm+"%'),upper(ms.user_name))";
			query="select user_name,user_email,user_status,usrl.role_nm,ms.loginid,ms.supervisor,ms.user_role,ms.user_id,ms.location,ms.tag,ms.user_grade,ms.pannumber,ms.department,ms.user_id from XXBAF_USER_MSTR ms,XXBAF_ROLE_MSTR usrl where ms.user_role=usrl.id and upper(ms.user_name) like nvl(upper('%"+userNm+"%'),upper(ms.user_name))";
			ps=conn.prepareStatement(query);
			//ps.setString(1, userNm);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				usrlm=new String[14];
				usrlm[0]=rs.getString(1);
				usrlm[1]=rs.getString(2);
				usrlm[2]=rs.getString(3);
				usrlm[3]=rs.getString(4);
				usrlm[4]=rs.getString(5);
				usrlm[5]=rs.getString(6);
				usrlm[6]=rs.getString(7);
				usrlm[7]=rs.getString(8);
				usrlm[8]=rs.getString(9);
				usrlm[9]=rs.getString(10);
				usrlm[10]=rs.getString(11);
				usrlm[11]=rs.getString(12);
				usrlm[12]=rs.getString(13);
				usrlm[13]=rs.getString(14);
				
				userMaster.add(usrlm);
			}
			if(rs!=null) {rs=null;}
			if(query!=null) {query=null;}
			query="select user_name||'-'||employee_code,user_id from XXBAF_USER_MSTR where user_status='A' and user_role=3 ";
			ps=conn.prepareStatement(query);
				
			rs=ps.executeQuery();
			
			while(rs.next()) {
				supervisor=new String[2];
				supervisor[0]=rs.getString(1);
				supervisor[1]=rs.getString(2);
				
				superMaster.add(supervisor);
			}
			
			if(rs!=null) {rs=null;}
			if(query!=null) {query=null;}
			
			query="select LOOKUP_CODE, DESCRIPTION STATE_CODE,TAG  from apps.fnd_lookup_VALUES  where lookup_type = 'AFP_STATE_CODE'  AND ENABLED_FLAG = 'Y'  AND END_DATE_ACTIVE IS NULL";
			ps=conn.prepareStatement(query);
				
			rs=ps.executeQuery();
			
			while(rs.next()) {
				location=new String[3];
				location[0]=rs.getString(1);
				location[1]=rs.getString(2);
				location[2]=rs.getString(3);
				
				locationMaster.add(location);
			}
			
			query="select Meaning  from apps.fnd_lookup_values_vl where lookup_type = 'BAF_EMP_GRADE'  and enabled_flag = 'Y' ";			
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				grade=new String[1];
				grade[0]=rs.getString(1);
				
				gradeMaster.add(grade);
			}
			

			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getDepartment");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				department=new String[2];
				department[0]=rs.getString(1);
				department[1]=rs.getString(2);
				
				departmentList.add(department);
			}
			
				request.setAttribute("userMaster", userMaster);
				request.setAttribute("userMasterSize", userMaster.size());
				request.setAttribute("superMaster", superMaster);
				request.setAttribute("superMasterSize", superMaster.size());
				request.setAttribute("locationMaster", locationMaster);
				request.setAttribute("locationMasterSize", locationMaster.size());
				request.setAttribute("gradeMaster", gradeMaster);
				request.setAttribute("gradeMasterSize", gradeMaster.size());
				request.setAttribute("departmentList", departmentList);
			}
			if(flag.equals("update")) {
				String upName=request.getParameter("updatedName");
				String upmail=request.getParameter("updatedmail");
				String upstatus=request.getParameter("updatedst");
				String login=request.getParameter("updatedlogin");
				String superUser=request.getParameter("supervisor");
				String locationusr=request.getParameter("updatedlocation");
				String loc[]=locationusr.split(",");
				String usrgrd=request.getParameter("updatedgrade")!=null?request.getParameter("updatedgrade"):"";
				String panno=request.getParameter("updatedpan")!=null?request.getParameter("updatedpan"):"";
				String dept=request.getParameter("updateddept")!=null?request.getParameter("updateddept"):"";
				
				//query="update user_mstr set user_name=?,user_email=?,user_status=? where loginid=?";
				query="update XXBAF_USER_MSTR set user_name=?,user_email=?,user_status=?,supervisor=?,location=?,tag=?,last_upd_date=sysdate,user_grade=?,pannumber=?,department=? where loginid=?";
				ps=conn.prepareStatement(query);
				ps.setString(1, upName);
				ps.setString(2, upmail);
				ps.setString(3, upstatus);
				ps.setString(4, superUser);
				ps.setString(5, loc[0]);
				ps.setString(6, loc[1]);
				ps.setString(7, usrgrd);
				ps.setString(8, panno);
				ps.setString(9, dept);
				ps.setString(10, login);
				
				int a=ps.executeUpdate();
				
				if(a==1) {
					msg="User Updated Successfully";
				}else {
					msg="User Not Updated";
				}
				request.setAttribute("msg", msg);
				flag="";
				return "userSearch";
			}
			
			if(flag.equals("openWin")) {
				
				String [] rlm=null;
				String[] employee=null;
				ArrayList roleMaster=new ArrayList();
				ArrayList employeeList=new ArrayList();				
				
				String usrId=request.getParameter("id");
				request.setAttribute("usrId", usrId);
				query=bundle.getString("searchEditUserPop");
				ps=conn.prepareStatement(query);
				
				ps.setString(1, usrId);
				
				rs=ps.executeQuery();
				while(rs.next()) {
					usrlm=new String[18];
					usrlm[0]=rs.getString(1);
					usrlm[1]=rs.getString(2);
					usrlm[2]=rs.getString(3);
					usrlm[3]=rs.getString(4);
					usrlm[4]=rs.getString(5);
					usrlm[5]=rs.getString(6);
					usrlm[6]=rs.getString(7);
					usrlm[7]=rs.getString(8);
					usrlm[8]=rs.getString(9);
					usrlm[9]=rs.getString(10);
					usrlm[10]=rs.getString(11);
					usrlm[11]=rs.getString(12);
					usrlm[12]=rs.getString(13);
					usrlm[13]=rs.getString(14);
					usrlm[14]=rs.getString(15);
					usrlm[15]=rs.getString(16);
					usrlm[16]=rs.getString(17);
					usrlm[17]=rs.getString(18);
					//usrlm[18]=rs.getString(19);
					
					userMaster.add(usrlm);				
				}
				
				if(rs!=null) {rs=null;}
				if(ps!=null) {ps=null;}
				if(query!=null) {query=null;}
				
				query="select user_name||'-'||employee_code,user_id from XXBAF_USER_MSTR where user_status='A' and user_role=3 ";
				ps=conn.prepareStatement(query);
					
				rs=ps.executeQuery();
				
				while(rs.next()) {
					supervisor=new String[2];
					supervisor[0]=rs.getString(1);
					supervisor[1]=rs.getString(2);
					
					superMaster.add(supervisor);
				}
				
				if(rs!=null) {rs=null;}
				if(ps!=null) {ps=null;}
				if(query!=null) {query=null;}
				
				query="select LOOKUP_CODE, DESCRIPTION STATE_CODE,TAG  from apps.fnd_lookup_VALUES  where lookup_type = 'AFP_STATE_CODE'  AND ENABLED_FLAG = 'Y'  AND END_DATE_ACTIVE IS NULL";
				ps=conn.prepareStatement(query);
					
				rs=ps.executeQuery();
				
				while(rs.next()) {
					location=new String[3];
					location[0]=rs.getString(1);
					location[1]=rs.getString(2);
					location[2]=rs.getString(3);
					
					locationMaster.add(location);
				}
				
				query="select Meaning  from apps.fnd_lookup_values_vl where lookup_type = 'BAF_EMP_GRADE'  and enabled_flag = 'Y' ";			
				ps=conn.prepareStatement(query);
				rs=ps.executeQuery();
				
				while(rs.next()) {
					grade=new String[1];
					grade[0]=rs.getString(1);
					
					gradeMaster.add(grade);
				}
				

				if(rs!=null) {rs=null;}
				if(ps!=null) {ps=null;}
				if(query!=null) {query=null;}
				
				query=bundle.getString("getDepartment");
				ps=conn.prepareStatement(query);
				
				rs=ps.executeQuery();
				
				while(rs.next()) {
					department=new String[2];
					department[0]=rs.getString(1);
					department[1]=rs.getString(2);
					
					departmentList.add(department);
				}
				
				if(rs!=null) {rs=null;}
				if(ps!=null) {ps=null;}
				if(query!=null) {query=null;}
				
				query="select id,upper(role_nm) from XXBAF_ROLE_MSTR where id<>1";
				ps=conn.prepareStatement(query);
				rs=ps.executeQuery();
				
				while(rs.next()) {
					rlm=new String[2];
				rlm[0]=rs.getString(1);
				rlm[1]=rs.getString(2);
				
				roleMaster.add(rlm);		
					
				}
				
				if(rs!=null) {rs=null;}
				if(ps!=null) {ps=null;}
				if(query!=null) {query=null;}
				
				query=bundle.getString("getEmployeeDesig");
				ps=conn.prepareStatement(query);
				
				rs=ps.executeQuery();
				
				while(rs.next()) {
					employee=new String[1];
					employee[0]=rs.getString(1);
									
					employeeList.add(employee);
				}
				
				request.setAttribute("userMaster", userMaster);
				request.setAttribute("userMasterSize", userMaster.size());
				request.setAttribute("superUserMaster", superMaster);
				request.setAttribute("superUserMasterSize", superMaster.size());
				request.setAttribute("locationMaster", locationMaster);
				request.setAttribute("locationMasterSize", locationMaster.size());
				request.setAttribute("gradeMaster", gradeMaster);
				request.setAttribute("gradeMasterSize", gradeMaster.size());
				request.setAttribute("departmentList", departmentList);
				request.setAttribute("employeeList", employeeList);
				request.setAttribute("roleMaster", roleMaster);
				
				return "userSearchPopUp";
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	    return "userSearch"; 
	  }
}
