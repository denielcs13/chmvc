package commonController;

public class testPass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name="admin";
		String pass="test12345";
		String password=pass;
		try{
		Md5 md5=new Md5(password);
		
		byte[] b = md5.getDigest();
	     String Enc_Pass = md5.stringify(b);
		System.out.println(Enc_Pass);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

}
