package commonController;

import java.net.InetAddress;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.lang.model.type.ArrayType;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String init(Model model) {
		System.out.println("okkkk");
		// model.addAttribute("msg", "Please Enter Your Login Details");
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginAct(Model model, HttpServletRequest request, HttpServletResponse response) throws Exception {

		Connection conn;
		HttpSession session = request.getSession();
		String name = request.getParameter("usrName");
		String pass = request.getParameter("pass");
		String EncPass = pass;
		ResultSet rs = null;
		PreparedStatement ps = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		conn = new Connectionc().getConnection();
		try {
			ArrayList menuList = new ArrayList();
			String[] menu = null;
			String loginName = null;
			String role = null;
			String loginID = null;
			String userId = "";
			String query = null;
			int password_fl = 2;
			int user_lock_fl=2;
			String afpcheck=null;
			String empcheck=null;
			String empGrd=null;
			String empDesig=null;
			String msg = null;
			String lastLoginDt="";
			if (!(name.equals("") && pass.equals(""))) {
				Md5 md5 = new Md5(EncPass);
				byte[] b = md5.getDigest();
				EncPass = md5.stringify(b);
				
				
				query=bundle.getString("getuserDtls");
				ps = conn.prepareStatement(query);
				ps.setString(1, name);
				ps.setString(2, EncPass);
				rs = ps.executeQuery();

				while (rs.next()) {
					loginName = rs.getString(1);
					role = rs.getString(2);
					loginID = rs.getString(3);
					userId = rs.getString(4);
					afpcheck=rs.getString(5)!=null?rs.getString(5):"N";
					empcheck=rs.getString(6)!=null?rs.getString(6):"N";
					empGrd=rs.getString(7)!=null?rs.getString(7):"";
					empDesig=rs.getString(8)!=null?rs.getString(8):"";
					
				}
				
				if(!("".equals(userId))) {
					
				query=bundle.getString("getPasswordflag");
				ps = conn.prepareStatement(query);
				ps.setString(1, name);
				ps.setString(2, EncPass);

				rs = ps.executeQuery();

				while (rs.next()) {
					password_fl = rs.getInt(1);
					//user_lock_fl=rs.getInt(2);
				}

				if (rs != null) {
					rs = null;
				}
				if (ps != null) {
					ps = null;
				}
				if (query != null) {
					query = null;
				}

				if (password_fl == 0) {
					msg = "You are first time user.Please change your password";
					request.setAttribute("msg", msg);
					request.setAttribute("loginId", name);
					return "changeFirstPassword";
				}else {
					session.setAttribute("name", loginName.toUpperCase());
					session.setAttribute("role", role);
					session.setAttribute("loginID", loginID);
					session.setAttribute("userId",userId);
					
					query=bundle.getString("updateUserLastloginDt");
					ps = conn.prepareStatement(query);
					System.out.println(query);
					ps.setString(1, name);
					ps.setString(2, EncPass);
					
					int a=ps.executeUpdate();
					
					if (ps != null) {
						ps = null;
					}
					if (query != null) {
						query = null;
					}
					
					query=bundle.getString("getLastLoginDtls");
					
					ps = conn.prepareStatement(query);
					System.out.println(query);
					ps.setString(1, name);
					ps.setString(2, name);		
					
					rs = ps.executeQuery();
					while (rs.next()) {
						lastLoginDt=rs.getString(1);
					}	
					
					if (rs != null) {
						rs = null;
					}
					if (ps != null) {
						ps = null;
					}
					if (query != null) {
						query = null;
					}
					
					InetAddress address = InetAddress.getLocalHost();
					 String iP = address.getHostAddress() ;
					 
					 System.out.println( "IP: " + iP );
					 
					query=bundle.getString("insertloginDt");
					ps = conn.prepareStatement(query);
					System.out.println(query);
					ps.setString(1, name);
					ps.setString(2, iP);
					
					int c=ps.executeUpdate();
					
					if (ps != null) {
						ps = null;
					}
					if (query != null) {
						query = null;
					}				
					
					query="select description,url from XXBAF_MENU_MSTR mn,XXBAF_ROLE_MENU_MAP rlm where mn.id=rlm.menu_id and rlm.role_id="+ role;
					if(afpcheck.equals("N")) {
						query=query+" and mn.id<>1 ";
					}
					if(empcheck.equals("N")) {
						query=query+" and mn.id not in(7,8) ";
					}
					query=query+" order by mn.id";
					
					System.out.println(query);
					ps = conn.prepareStatement(query);									
					rs = ps.executeQuery();

					while (rs.next()) {
						menu = new String[2];

						menu[0] = rs.getString(1);
						menu[1] = rs.getString(2);

						menuList.add(menu);
					}		
					
					
					session.setAttribute("lastLoginDt", lastLoginDt);
					session.setAttribute("IP", iP);
					session.setAttribute("menuList", menuList);
					System.out.println(menuList.size());
					session.setAttribute("empGrd",empGrd);
					session.setAttribute("empDesig",empDesig);
					return "welcome";

				}
				
			}else {				
						int failSeq=0;
						
						if (rs != null) {
							rs.close();
							rs = null;
						}
						if (ps != null) {
							ps.close();
							ps = null;
						}
						if (query != null) {
							query = null;
						}
						
						query=bundle.getString("updateWrongCreSeq");
						ps = conn.prepareStatement(query);
						System.out.println(query);
						ps.setString(1, name);
						ps.setString(2, name);
						
						int a=ps.executeUpdate();
						
						if (ps != null) {
							ps = null;
						}
						if (query != null) {
							query = null;
						}
						
						query=bundle.getString("getLoginFailSeq");
						ps = conn.prepareStatement(query);
						System.out.println(query);
						ps.setString(1, name);
						
						rs = ps.executeQuery();
						
						if(rs.next()) {
							failSeq=rs.getInt(1);
						}
						
						if(failSeq>=3) {
							query=bundle.getString("updateUserLockFlag");
							ps = conn.prepareStatement(query);
							System.out.println(query);
							ps.setString(1, name);
							
							int d=ps.executeUpdate();
						}
						
						if (ps != null) {
							ps = null;
						}
						if (query != null) {
							query = null;
						}
						
						query=bundle.getString("getuserLockFlag");
						ps = conn.prepareStatement(query);
						System.out.println(query);
						ps.setString(1, name);
						
						rs = ps.executeQuery();
						if(rs.next()) {
							user_lock_fl=rs.getInt(1);
						}
						
						if(user_lock_fl==1) {
							msg = "User Locked.Please click on Forgot Password to Reset";
							request.setAttribute("msg", msg);
							//request.setAttribute("loginId", name);
							return "login";
						}else {
						model.addAttribute("msg", "Wrong Details Entered");
						return "login";
						}
					}
					
					
			} else {
				model.addAttribute("msg", "Please Enter Your Login Details");
				return "login";
			}

		} catch (Exception e) {
			conn.rollback();
			model.addAttribute("msg", "Some Error Occurred");
			e.printStackTrace();
			return "login";
			
		}
		
	}

	@RequestMapping(value = "/logout", method = { RequestMethod.GET, RequestMethod.POST })
	public String logout(Model model, HttpServletRequest request, HttpServletResponse response) {

		System.out.println("In method");
		HttpSession session = request.getSession();
		String messsg = request.getParameter("msg") != null ? (String) request.getParameter("msg") : "";
		session.removeAttribute("name");
		session.removeAttribute("role");
		session.removeAttribute("loginId");
		request.removeAttribute("loginId");

		session.invalidate();

		System.out.println("Logout");
		model.addAttribute("msg", "User Logout Successfully");
		request.setAttribute("messsg", messsg);
		return "login";
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	public String changePassword(Model model, HttpServletRequest request, HttpServletResponse response) {

		Connection conn;
		HttpSession session = request.getSession();
		String flag = request.getParameter("flag") != null ? request.getParameter("flag") : "";
		String forward = "";
		ResultSet rs = null;
		PreparedStatement ps = null;
		String msg = "";
		CallableStatement callableStmt=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		try {
			conn = new Connectionc().getConnection();
			String loginId = session.getAttribute("loginID") != null ? (String) session.getAttribute("loginID") : "";
			if ("".equals(loginId)) {
				loginId = request.getParameter("loginId");
				request.setAttribute("loginId", loginId);
			}
			String name = session.getAttribute("name") != null ? (String) session.getAttribute("name") : "";
			int count = 0;
			if (flag.equals("update")) {
				String oldPass = request.getParameter("oldPass");
				String newPass = request.getParameter("newPass");

				String EncOldPass = oldPass;
				Md5 md = new Md5(EncOldPass);
				byte[] b = md.getDigest();
				EncOldPass = md.stringify(b);

				String EncNewPass = newPass;
				Md5 md1 = new Md5(EncNewPass);
				byte[] b1 = md1.getDigest();
				EncNewPass = md1.stringify(b1);

				/*
				 * callableStmt=conn.prepareCall("{call XXBAF_SP_CHANGE_PWD(?,?,?,?}");
				 * callableStmt.setString(1, loginId); callableStmt.setString(2, EncOldPass);
				 * callableStmt.setString(3, EncNewPass); callableStmt.registerOutParameter(4,
				 * Types.VARCHAR);
				 * 
				 * callableStmt.execute();
				 */

				if (EncOldPass.equals(EncNewPass)) {
					msg = "The New password cannot be same as Old Password";
					forward = "changePassword";
				} else {
					String getUserCount = bundle.getString("getUserCount");
					ps = conn.prepareStatement(getUserCount);

					ps.setString(1, loginId);
					ps.setString(2, EncOldPass);

					rs = ps.executeQuery();

					if (rs.next()) {
						count = rs.getInt(1);
					}
					rs = null;
					ps = null;
					if (count == 0) {
						msg = "Old password is not correct";
						forward = "changePassword";
					} else {
						String updateuserPass = bundle.getString("updateuserPass");
						ps = conn.prepareStatement(updateuserPass);
						ps.setString(1, EncNewPass);
						ps.setString(2, loginId);
						ps.setString(3, EncOldPass);

						int a = ps.executeUpdate();
						if (a == 1) {
							callableStmt=conn.prepareCall("{call xxbaf_forgot_password(?,?,?,?,?)}");
							
							callableStmt.setString(1, loginId);
							callableStmt.setString(2, EncNewPass);
							callableStmt.setString(3, "Change Pass");
							callableStmt.registerOutParameter(4, Types.VARCHAR);  //status
							callableStmt.setString(5, newPass);
							
							callableStmt.execute();		
					        
							msg = "Password Updated Successfully";
							forward = "welcome";
						}
					}

				}
			} else if (flag.equals("updatefirstPass")) {

				String oldPass = request.getParameter("oldPass");
				String newPass = request.getParameter("newPass");

				String EncOldPass = oldPass;
				Md5 md = new Md5(EncOldPass);
				byte[] b = md.getDigest();
				EncOldPass = md.stringify(b);

				String EncNewPass = newPass;
				Md5 md1 = new Md5(EncNewPass);
				byte[] b1 = md1.getDigest();
				EncNewPass = md1.stringify(b1);

				if (EncOldPass.equals(EncNewPass)) {
					msg = "The New password cannot be same as Old Password";
					forward = "changeFirstPassword";
				} else {
					String getUserCount = bundle.getString("getUserCount");
					ps = conn.prepareStatement(getUserCount);

					ps.setString(1, loginId);
					ps.setString(2, EncOldPass);

					rs = ps.executeQuery();

					if (rs.next()) {
						count = rs.getInt(1);
					}
					rs = null;
					ps = null;
					if (count == 0) {
						msg = "Old password is not correct";
						forward = "changeFirstPassword";
					} else {
						String updateuserPass = bundle.getString("updatefirstuserPass");
						ps = conn.prepareStatement(updateuserPass);
						ps.setString(1, EncNewPass);
						ps.setString(2, loginId);
						ps.setString(3, EncOldPass);

						int a = ps.executeUpdate();
						if (a == 1) {
						callableStmt=conn.prepareCall("{call xxbaf_forgot_password(?,?,?,?,?)}");
							
							callableStmt.setString(1, loginId);
							callableStmt.setString(2, "");
							callableStmt.setString(3, "Change Pass");
							callableStmt.registerOutParameter(4, Types.VARCHAR);  //status
							callableStmt.setString(5, newPass);
							
							callableStmt.execute();		
					        
							msg = "Password Updated Successfully";
							request.setAttribute("msg", msg);
							forward = "redirect:/logout?msg=" + msg;
						}else {
							forward = "changePassword";
							msg = "Some Error Occurred";
						}
					}

				}

			}

			else {
				forward = "changePassword";
			}
		} catch (Exception e) {
			forward = "changePassword";
			msg = "Some Error Occurred";
			e.printStackTrace();
		}
		request.setAttribute("msg", msg);
		return forward;
	}
}
