package commonController;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AjaxController {

	@RequestMapping(value = "/getSupplierName", method = { RequestMethod.GET, RequestMethod.POST })
	public String getSupplyName(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		System.out.println("okkkk");

		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String supplierQry = bundle.getString("getsupplierName");
		String supplyId = request.getParameter("supplyId");
		System.out.println("supplyId" + supplyId);
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(supplierQry);
			prepareStmt.setString(1, supplyId);

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<suppliers>");
			while (resultSet.next()) {
				xml.append("<supply>");
				xml.append("<supplierNm>");
				xml.append(resultSet.getString(1));
				xml.append("</supplierNm>");
				xml.append("</supply>");

			}
			xml.append("</suppliers>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}

	@RequestMapping(value = "/getSupplierSites", method = { RequestMethod.GET, RequestMethod.POST })
	public String getSupplySite(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		Connection myConnection = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String supplierQry = bundle.getString("getsuppliersite");
		String supplyId = request.getParameter("supplyId");
		System.out.println("supplyId" + supplyId);
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(supplierQry);
			prepareStmt.setString(1, supplyId);

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<suppliers>");
			while (resultSet.next()) {
				xml.append("<supply>");
				xml.append("<siteId>");
				xml.append(resultSet.getString(1));
				xml.append("</siteId>");
				xml.append("<siteName>");
				String sitename = resultSet.getString(2).contains("&") ? resultSet.getString(2).replace("&", "amp")
						: resultSet.getString(2);
				xml.append(sitename);
				xml.append("</siteName>");
				xml.append("</supply>");

			}
			xml.append("</suppliers>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				return "failure";
			}

		}
		return null;
	}

	@RequestMapping(value = "/getSupplierGST", method = { RequestMethod.GET, RequestMethod.POST })
	public String getSupplyGST(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String supplierQry = bundle.getString("getGSTDetails");
		String supplysiteId = request.getParameter("supplysiteId");
		String supplierId= request.getParameter("supplierid");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(supplierQry);
			prepareStmt.setString(1, supplysiteId);
			prepareStmt.setString(2, supplierId);

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<suppliers>");
			while (resultSet.next()) {
				xml.append("<supply>");
				xml.append("<supplierGST>");
				xml.append(resultSet.getString(1));
				xml.append("</supplierGST>");
				xml.append("</supply>");

			}
			xml.append("</suppliers>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	
	@RequestMapping(value = "/getdepartment", method = { RequestMethod.GET, RequestMethod.POST })
	public String getdepartment(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getDepartment");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String des=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<department>");
			while (resultSet.next()) {
				xml.append("<dept>");
				xml.append("<flexVal>");
				xml.append(resultSet.getString(1));
				xml.append("</flexVal>");
				xml.append("<description>");
				if(resultSet.getString(2).contains("&")) {
					des=resultSet.getString(2).replace("&", "amp");
				}else {
					des=resultSet.getString(2);
				}
				xml.append(des);
				xml.append("</description>");
				xml.append("</dept>");

			}
			xml.append("</department>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getProduct", method = { RequestMethod.GET, RequestMethod.POST })
	public String getProduct(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getProduct");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String des=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<product>");
			while (resultSet.next()) {
				xml.append("<prod>");
				xml.append("<flexVal>");
				xml.append(resultSet.getString(1));
				xml.append("</flexVal>");
				xml.append("<description>");
				if(resultSet.getString(2).contains("&")) {
					des=resultSet.getString(2).replace("&", "amp");
				}else {
					des=resultSet.getString(2);
				}
				xml.append(des);
				xml.append("</description>");
				xml.append("</prod>");

			}
			xml.append("</product>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getDescription", method = { RequestMethod.GET, RequestMethod.POST })
	public String getDescription(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getLineDesc");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String des=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<linedesc>");
			while (resultSet.next()) {
				xml.append("<desc>");
				xml.append("<description>");
				if(resultSet.getString(1).contains("&")) {
					des=resultSet.getString(1).replace("&", "amp");
				}else {
					des=resultSet.getString(1);
				}
				xml.append(des);
				xml.append("</description>");
				xml.append("<glCode>");
				xml.append(resultSet.getString(2));
				xml.append("</glCode>");
				xml.append("</desc>");

			}
			xml.append("</linedesc>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getGLDateValid", method = { RequestMethod.GET, RequestMethod.POST })
	public String getGLDateValid(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String glQry = bundle.getString("gldatecount");
		String glDate = request.getParameter("glDate");
		String glid = request.getParameter("glid");

		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(glQry);
			prepareStmt.setString(1, glDate);
			

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<glDate>");
			while (resultSet.next()) {
				xml.append("<glData>");
				xml.append("<glDateValid>");
				xml.append(resultSet.getString(1));
				xml.append("</glDateValid>");
				xml.append("<glDateID>");
				xml.append(glid);
				xml.append("</glDateID>");
				xml.append("</glData>");

			}
			xml.append("</glDate>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getAttribute1Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute1Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getExpenseAtt1");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		try {
			String expCat=request.getParameter("expCat");
			String ids=request.getParameter("id");
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			prepareStmt.setString(1, expCat);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att1>");
				xml.append("<expenseAtt1>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt1>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att1>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	@RequestMapping(value = "/getAttribute2Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute2Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getExpenseAtttag");	
		String deptQry1 = bundle.getString("getExpenseAttdesc");
		String deptQry2= bundle.getString("getExpenseAtttagOutst");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("OutStation Travel")) {
				query=deptQry2+" and lookup_type = 'BAF_CITY_CATEGORY' ";	
			}
			else if(expCat.equalsIgnoreCase("International Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_STATUS_OF_TRAVEL_AT_EOD' ";	
			}
			else if(expCat.equalsIgnoreCase("Local Conveyance")) {
				query=deptQry+" and lookup_type = 'BAF_MODE_OF_TRANSPORT' ";
			}
			else if(expCat.equalsIgnoreCase("Food Expense")) {
				query=deptQry1+" and lookup_type = 'BAF_MEAL_TYPE' ";	
			}else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getAttribute3Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute3Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry1 = bundle.getString("getExpenseAttdesc");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("OutStation Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_STATUS_OF_TRAVEL_AT_EOD' ";	
			}
			else if(expCat.equalsIgnoreCase("International Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_TRIP' ";	
			}else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}

	@RequestMapping(value = "/getAttribute4Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute4Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
		String deptQry1 = bundle.getString("getExpenseAttdesc");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("OutStation Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_MODE_OF_TRANSPORT' ";	
			}
			else if(expCat.equalsIgnoreCase("International Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_ALLOWANCE' ";	
			}else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getAttribute5Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute5Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		//String deptQry = bundle.getString("getExpenseAtttag");	
		String deptQry1 = bundle.getString("getExpenseAttdesc");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("International Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_ACCOMODATION' ";	
			}else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getAttribute6Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute6Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
		String deptQry1 = bundle.getString("getExpenseAttdesc");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("OutStation Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_FOOD_EXPENSE' ";	
			}
			else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}	

	@RequestMapping(value = "/getAttribute7Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getAttribute7Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
		String deptQry = bundle.getString("getExpenseAtttag");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("OutStation Travel")) {
				query=deptQry+" and lookup_type = 'BAF_MODE_OF_TRANSPORT' ";	
			}
			else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, "Local Conveyance");
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	
	@RequestMapping(value = "/getValidTax", method = { RequestMethod.GET, RequestMethod.POST })
	public String getValidTax(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		Connection myConnection = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String supplierQry = bundle.getString("getsuppliersitecode");
		String lineloc = request.getParameter("lineloc");
		System.out.println("lineloc" + lineloc);
		String supplierst = request.getParameter("supplierst");		
		System.out.println("supplierst" + supplierst);
		String lineid = request.getParameter("lineid");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String lokupcode=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(supplierQry);
			prepareStmt.setString(1, supplierst);

			resultSet = prepareStmt.executeQuery();
			
			while (resultSet.next()) {
				lokupcode=resultSet.getString(1);
			}
			
			
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<states>");
				xml.append("<stcode>");
				xml.append("<stats>");
			if(lokupcode.equalsIgnoreCase(lineloc)) {	
				xml.append("Y");
			}else {
				xml.append("N");
			}
				xml.append("</stats>");
				xml.append("<lineid>");
				xml.append(lineid);
				xml.append("</lineid>");
				xml.append("</stcode>");			
			xml.append("</states>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				return "failure";
			}

		}
		return null;
	}	
	
	@RequestMapping(value = "/getLocation", method = { RequestMethod.GET, RequestMethod.POST })
	public String getLocation(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = "select LOOKUP_CODE, DESCRIPTION STATE_CODE,TAG  from apps.fnd_lookup_VALUES  where lookup_type = 'AFP_STATE_CODE'  AND ENABLED_FLAG = 'Y'  AND END_DATE_ACTIVE IS NULL";
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String des=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<linelocation>");
			while (resultSet.next()) {
				xml.append("<loca>");
				xml.append("<llocation>");
				xml.append(resultSet.getString(1));
				xml.append("</llocation>");
				xml.append("<glCode>");
				xml.append(resultSet.getString(2));
				xml.append("</glCode>");
				xml.append("<tag>");
				xml.append(resultSet.getString(3));
				xml.append("</tag>");
				xml.append("</loca>");

			}
			xml.append("</linelocation>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getTaxType", method = { RequestMethod.GET, RequestMethod.POST })
	public String getTaxType(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getTaxtype");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String des=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<linetax>");
			while (resultSet.next()) {
				xml.append("<taxtype>");
				xml.append("<lttype>");
				des=resultSet.getString(1).replace("%", " per");
				xml.append(des);
				xml.append("</lttype>");
				xml.append("<glCode>");
				xml.append(resultSet.getString(2));
				xml.append("</glCode>");
				xml.append("</taxtype>");

			}
			xml.append("</linetax>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getBaseLocation", method = { RequestMethod.GET, RequestMethod.POST })
	public String getBaseLocation(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getBaseLocation");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String location=request.getParameter("location");
		String des=null;
		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			prepareStmt.setString(1, location);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<baseloc>");
			while (resultSet.next()) {
				xml.append("<loca>");
				xml.append("<baselocv>");
				xml.append(resultSet.getString(1));
				xml.append("</baselocv>");
				xml.append("</loca>");

			}
			xml.append("</baseloc>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getNewempgrdVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getNewempgrdVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
		String deptQry1 = bundle.getString("getemployeeGrade");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			
			String ids=request.getParameter("id");
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry1);
			
			
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expensegrd>");
			while (resultSet.next()) {
				xml.append("<employgr>");
				xml.append("<employeeGr>");
				xml.append(resultSet.getString(1));
				xml.append("</employeeGr>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</employgr>");

			}
			xml.append("</expensegrd>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}		
	
	
	@RequestMapping(value = "/getNewExpCatVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getNewExpCatVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
		String deptQry1 = bundle.getString("getExpenseCategory");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			
			String ids=request.getParameter("id");
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry1);
			
			
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expensegrd>");
			while (resultSet.next()) {
				xml.append("<employgr>");
				xml.append("<employeeGr>");
				xml.append(resultSet.getString(1));
				xml.append("</employeeGr>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</employgr>");

			}
			xml.append("</expensegrd>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}		
	
	
	@RequestMapping(value = "/getInvExpAttribute1Val", method = { RequestMethod.GET, RequestMethod.POST })
	public String getInvExpAttribute1Val(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		String deptQry =null;
		try {
			myConnection = new Connectionc().getConnection();
			String ids=request.getParameter("id");
			String expCat=request.getParameter("expCat");
			if(expCat.equals("Combined - Food and conveyance")) {
				deptQry = bundle.getString("getExpenseInvCombAtt1");
				prepareStmt = myConnection.prepareStatement(deptQry);
				
			}else {
			 deptQry = bundle.getString("getExpenseInvAtt1");
			 prepareStmt = myConnection.prepareStatement(deptQry);
				prepareStmt.setString(1, expCat);
			}		
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att1>");
				xml.append("<expenseAtt1>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt1>");
				xml.append("<lookupCode>");
				xml.append(resultSet.getString(2));
				xml.append("</lookupCode>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("<inpParam>");
				xml.append(expCat);
				xml.append("</inpParam>");
				xml.append("</att1>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getInvNOEVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getInvNOEVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry = bundle.getString("getExpInvoiceNOE");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		try {
			String ids=request.getParameter("id");
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			String sitename="";
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att1>");
				xml.append("<expenseAtt1>");
				sitename = resultSet.getString(1).contains("&") ? resultSet.getString(1).replace("&", "amp")
						: resultSet.getString(1);
				xml.append(sitename);
				xml.append("</expenseAtt1>");
				xml.append("<lookupCode>");
				xml.append(resultSet.getString(2));
				xml.append("</lookupCode>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att1>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getModeOfTransportVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getModeOfTransportVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
		String deptQry1 = bundle.getString("getExpenseAttdesc");	
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			if(expCat.equalsIgnoreCase("OutStation Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_MODE_OF_TRANSPORT' ";	
			}
			else if(expCat.equalsIgnoreCase("International Travel")) {
				query=deptQry1+" and lookup_type = 'BAF_ALLOWANCE' ";	
			}else {
				return null;
			}
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<motrans>");
				xml.append("<motransval>");
				xml.append(resultSet.getString(1));
				xml.append("</motransval>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</motrans>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/gettravelToVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String gettravelToVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry= bundle.getString("getExpenseTravelToOutst");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		String query=null;
		try {
			String expCat=request.getParameter("expCat")!=null?request.getParameter("expCat"):"";
			String ids=request.getParameter("id");
			
				query=deptQry+" and lookup_type = 'BAF_CITY_CATEGORY' ";	
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(query);
			
			//prepareStmt.setString(1, expCat);
			System.out.println(query);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<expenseAtt2>");
				xml.append(resultSet.getString(1));
				xml.append("</expenseAtt2>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getcityClVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getcityClVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String deptQry= bundle.getString("getClassCity");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		try {
			String trvlTo=request.getParameter("trvlTo")!=null?request.getParameter("trvlTo"):"";
			String ids=request.getParameter("id");
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(deptQry);
			
			prepareStmt.setString(1, trvlTo);
			System.out.println(deptQry);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<cat>");
				xml.append(resultSet.getString(1));
				xml.append("</cat>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getCurrNmVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getCurrNmVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String cuurncyNmQry= bundle.getString("getCuurncyNm");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		try {
			String ids=request.getParameter("id");
			
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(cuurncyNmQry);
			
			System.out.println(cuurncyNmQry);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<cat>");
				xml.append(resultSet.getString(1));
				xml.append("</cat>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getExchRtValgetExchRtValNew")
	public @ResponseBody String getExchRtValNew(HttpServletRequest request, HttpServletResponse response)	throws IOException, ServletException {
		
		Connection myConnection = null;
		HttpSession session = request.getSession();
		Statement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int status;
		String finYear=request.getParameter("finYear");
		String frmDate=request.getParameter("frmDate");
		String toDate=request.getParameter("toDate");
		String invtype=request.getParameter("invtype");
		String ids=request.getParameter("id");
		String currNm=request.getParameter("currNm");
		String expcheck = request.getParameter("expcheck");
		String loginId=(String)session.getAttribute("loginID");
		String exeId = null;
		String query=null;
		try {
			
			myConnection = new Connectionc().getConnection();
			statement = myConnection.createStatement();
			List list = new ArrayList();
			
			if("OutStation Travel".equals(expcheck)) {
				//query = "SELECT * FROM XXBAF_INV_EXP_OUT_TRAVEL WHERE PERIOD ='"+Period+"'  AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER('"+expfrom+"') AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper('"+expto+"') AND INVOICE_TYPE ='"+invoiceType+"'  AND EXP_TYPE =INITCAP ('"+expenseType+"') AND  SUBMITTED_BY='"+loginId+"'";
				query = "SELECT * FROM XXBAF_INV_EXP_OUT_TRAVEL WHERE PERIOD =?  AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = UPPER(?) AND INVOICE_TYPE =?  AND EXP_TYPE =INITCAP(?) AND  SUBMITTED_BY=?";
				 	
			}else if("Entertainment".equals(expcheck)) {
			  query = "SELECT * FROM XXBAF_INV_EXP_ENTERT WHERE PERIOD = ? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper(?) AND INVOICE_TYPE = ?  AND EXP_TYPE =INITCAP (?) AND  SUBMITTED_BY=? "; 
				
			} else if("Food Expense".equals(expcheck)) {
				query = "SELECT * FROM XXBAF_INV_EXP_FOOD_EXP WHERE PERIOD = ? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper(?) AND INVOICE_TYPE = ?  AND EXP_TYPE =INITCAP (?) AND  SUBMITTED_BY=? "; 
				
			}else if("Local Conveyance".equals(expcheck)) {
				query = "SELECT * FROM XXBAF_INV_EXP_LOC_CON WHERE PERIOD = ? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper(?) AND INVOICE_TYPE = ?  AND EXP_TYPE =INITCAP (?) AND  SUBMITTED_BY=? "; 
				
			}else if("Miscellaneous".equals(expcheck)) {
			 query = "SELECT * FROM XXBAF_INV_EXP_MISC WHERE PERIOD = ? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper(?) AND INVOICE_TYPE = ?  AND EXP_TYPE =INITCAP (?) AND  SUBMITTED_BY=? "; 
				
			}else if("International Travel".equals(expcheck)) {
				query = "SELECT * FROM XXBAF_INV_EXP_INTL_TRAVEL WHERE PERIOD = ? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper(?) AND INVOICE_TYPE = ?  AND EXP_TYPE =INITCAP (?) AND  SUBMITTED_BY=? "; 				
			
			}else if("Food and conveyance".equals(expcheck)) {
				query = "SELECT * FROM XXBAF_INV_EXP_COMBINED WHERE PERIOD = ? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = upper(?) AND INVOICE_TYPE = ?  AND EXP_TYPE =INITCAP (?) AND  SUBMITTED_BY=? ";
			}
			
			//String sql = "SELECT * FROM '"+tableName+"' WHERE PERIOD =? AND to_char(EXPENSE_FROM,'DD-MON-YYYY') = UPPER(?) AND to_char(EXPENSE_TO,'DD-MON-YYYY') = UPPER(?) AND INVOICE_TYPE =? AND EXP_TYPE =INITCAP(?) AND  SUBMITTED_BY=?";
			System.out.println("Query "+query);
			preparedStatement = myConnection.prepareStatement(query);
			preparedStatement.setString(1, finYear);
			preparedStatement.setString(2, frmDate);
			preparedStatement.setString(3, toDate);
			preparedStatement.setString(4, invtype);
			preparedStatement.setString(5, currNm);
			preparedStatement.setString(6, loginId);
			
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				list.add(resultSet.getString("SUBMITTED_BY"));
			}
			//System.out.println("ExeId = "+exeId);
						
			return list.toString();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "error";
	}
	
	
	@RequestMapping(value = "/getExchRtVal", method = { RequestMethod.GET, RequestMethod.POST })
	public String getExchRtVal(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String exchRtValQry= bundle.getString("getExchRtVal");
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;
		
		try {
			String ids=request.getParameter("id");
			String currNm=request.getParameter("currNm")!=null?request.getParameter("currNm"):"";
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(exchRtValQry);
			
			prepareStmt.setString(1, currNm);
			System.out.println(currNm);
			System.out.println(exchRtValQry);
			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<expenseAtt>");
			while (resultSet.next()) {
				xml.append("<att2>");
				xml.append("<cat>");
				xml.append(resultSet.getString(1));
				xml.append("</cat>");
				xml.append("<ids>");
				xml.append(ids);
				xml.append("</ids>");
				xml.append("</att2>");

			}
			xml.append("</expenseAtt>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
}