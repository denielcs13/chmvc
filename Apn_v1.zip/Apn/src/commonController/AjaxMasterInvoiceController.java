package commonController;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AjaxMasterInvoiceController {

	
	@RequestMapping(value = "/getHotelChargesContl", method = { RequestMethod.GET, RequestMethod.POST })
	public String getHotelChargesContl(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		Connection myConnection = null;
		String error_msg = null;
		HttpSession session = request.getSession();
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String hotelMasterQry = bundle.getString("hotelMasterQry");
		String expCat = request.getParameter("expCat");
		String id = request.getParameter("id");
		String expType = request.getParameter("expType");
		String cityClass = request.getParameter("cityClass");
		String travelDt = request.getParameter("travelDt");
		String empGrd =(String)session.getAttribute("empGrd");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(hotelMasterQry);
			prepareStmt.setString(1, empGrd);
			prepareStmt.setString(2, expCat);
			prepareStmt.setString(3, expType);
			prepareStmt.setString(4, cityClass);			
			prepareStmt.setString(5, travelDt);

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<hotelMstr>");
			while (resultSet.next()) {
				xml.append("<matchAmt>");
				xml.append("<Amount>");
				xml.append(resultSet.getString(1));
				xml.append("</Amount>");
				xml.append("<id>");
				xml.append(id);
				xml.append("</id>");
				xml.append("</matchAmt>");

			}
			xml.append("</hotelMstr>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	
	@RequestMapping(value = "/getFoodChargesContl", method = { RequestMethod.GET, RequestMethod.POST })
	public String getFoodChargesContl(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		Connection myConnection = null;
		String error_msg = null;
		HttpSession session = request.getSession();
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String FoodMasterQry = bundle.getString("FoodMasterQry");
		String expCat = request.getParameter("expCat");
		String id = request.getParameter("id");
		String expType = request.getParameter("expType");
		String cityClass = request.getParameter("cityClass");
		String travelDt = request.getParameter("travelDt");
		String empGrd =(String)session.getAttribute("empGrd");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(FoodMasterQry);
			prepareStmt.setString(1, empGrd);
			prepareStmt.setString(2, expCat);
			prepareStmt.setString(3, expType);
			prepareStmt.setString(4, cityClass);			
			prepareStmt.setString(5, travelDt);
			prepareStmt.setString(6, empGrd);
			prepareStmt.setString(7, expCat);
			prepareStmt.setString(8, expType);
			prepareStmt.setString(9, cityClass);			
			prepareStmt.setString(10, travelDt);			
			prepareStmt.setString(11, empGrd);
			prepareStmt.setString(12, expCat);
			prepareStmt.setString(13, expType);
			prepareStmt.setString(14, cityClass);			
			prepareStmt.setString(15, travelDt);

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<hotelMstr>");
			while (resultSet.next()) {
				xml.append("<matchAmt>");
				xml.append("<Amount>");
				xml.append(resultSet.getString(1));
				xml.append("</Amount>");
				xml.append("<attb>");
				xml.append(resultSet.getString(2));
				xml.append("</attb>");
				xml.append("<id>");
				xml.append(id);
				xml.append("</id>");
				xml.append("</matchAmt>");

			}
			xml.append("</hotelMstr>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}	
	

	@RequestMapping(value = "/getConvChargesContl", method = { RequestMethod.GET, RequestMethod.POST })
	public String getConvChargesContl(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		Connection myConnection = null;
		String error_msg = null;
		HttpSession session = request.getSession();
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String ConvMasterQry = bundle.getString("ConvMasterQry");
		String expCat = request.getParameter("expCat");
		String id = request.getParameter("id");
		String expType = request.getParameter("expType");
		String transMode = request.getParameter("transMode");
		String travelDt = request.getParameter("travelDt");
		String empGrd =(String)session.getAttribute("empGrd");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(ConvMasterQry);
			//prepareStmt.setString(1, empGrd);
			prepareStmt.setString(1, expCat);
			prepareStmt.setString(2, expType);
			prepareStmt.setString(3, transMode);			
			prepareStmt.setString(4, travelDt);
			

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<hotelMstr>");
			while (resultSet.next()) {
				xml.append("<matchAmt>");
				xml.append("<Amount>");
				xml.append(resultSet.getString(1));
				xml.append("</Amount>");
				xml.append("<id>");
				xml.append(id);
				xml.append("</id>");
				xml.append("</matchAmt>");

			}
			xml.append("</hotelMstr>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	
	@RequestMapping(value = "/getFoodExpContl", method = { RequestMethod.GET, RequestMethod.POST })
	public String getFoodExpContl(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		Connection myConnection = null;
		String error_msg = null;
		HttpSession session = request.getSession();
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String FoodExpMasterQry = bundle.getString("FoodExpMasterQry");
		String expCat = request.getParameter("expCat");
		String id = request.getParameter("id");
		String expType = request.getParameter("expType");
		String foodType = request.getParameter("foodType");
		String travelDt = request.getParameter("travelDt");
		String empGrd =(String)session.getAttribute("empGrd");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(FoodExpMasterQry);
			//prepareStmt.setString(1, empGrd);
			prepareStmt.setString(1, expCat);
			prepareStmt.setString(2, expType);
			prepareStmt.setString(3, foodType);			
			prepareStmt.setString(4, travelDt);
			

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<foodExpMstr>");
			while (resultSet.next()) {
				xml.append("<matchAmt>");
				xml.append("<Amount>");
				xml.append(resultSet.getString(1));
				xml.append("</Amount>");
				xml.append("<id>");
				xml.append(id);
				xml.append("</id>");
				xml.append("</matchAmt>");

			}
			xml.append("</foodExpMstr>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getLocConvExpContl", method = { RequestMethod.GET, RequestMethod.POST })
	public String getLocConvExpContl(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		Connection myConnection = null;
		String error_msg = null;
		HttpSession session = request.getSession();
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String LocConvExpMasterQry = bundle.getString("LocConvExpMasterQry");
		String expCat = request.getParameter("expCat");
		String id = request.getParameter("id");
		String expType = request.getParameter("expType");
		String modTrans = request.getParameter("modTrans");
		String travelDt = request.getParameter("travelDt");
		String empGrd =(String)session.getAttribute("empGrd");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(LocConvExpMasterQry);
			//prepareStmt.setString(1, empGrd);
			prepareStmt.setString(1, expCat);
			prepareStmt.setString(2, expType);
			prepareStmt.setString(3, modTrans);			
			prepareStmt.setString(4, travelDt);
			

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<foodExpMstr>");
			while (resultSet.next()) {
				xml.append("<matchAmt>");
				xml.append("<Amount>");
				xml.append(resultSet.getString(1));
				xml.append("</Amount>");
				xml.append("<id>");
				xml.append(id);
				xml.append("</id>");
				xml.append("</matchAmt>");

			}
			xml.append("</foodExpMstr>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
	
	@RequestMapping(value = "/getInterExpContlFixed", method = { RequestMethod.GET, RequestMethod.POST })
	public String getInterExpContlFixed(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		Connection myConnection = null;
		String error_msg = null;
		HttpSession session = request.getSession();
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		String InterExpMasterControlQry = bundle.getString("InterExpMasterControlQry");
		String expCat = request.getParameter("expCat");
		String id = request.getParameter("id");
		String expType = request.getParameter("expType");
		String travelDt = request.getParameter("travelDt");
		String empGrd =(String)session.getAttribute("empGrd");
		String tripFor = request.getParameter("tripFor");
		String scenerio = request.getParameter("scenerio");
		String currency = request.getParameter("currency");
		
		StringBuffer xml = new StringBuffer(4096);
		PreparedStatement prepareStmt = null;
		ResultSet resultSet = null;

		try {
			myConnection = new Connectionc().getConnection();
			prepareStmt = myConnection.prepareStatement(InterExpMasterControlQry);
			prepareStmt.setString(1, expCat);
			prepareStmt.setString(2, expType);
			prepareStmt.setString(3, tripFor);			
			prepareStmt.setString(4, scenerio);
			prepareStmt.setString(5, currency);
			prepareStmt.setString(6, travelDt);
			

			resultSet = prepareStmt.executeQuery();
			xml.append("<?xml version='1.0' encoding='ISO-8859-1'?>");
			xml.append("<InterNExpMstr>");
			while (resultSet.next()) {
				xml.append("<matchAmt>");
				xml.append("<Amount>");
				xml.append(resultSet.getString(1));
				xml.append("</Amount>");
				xml.append("<id>");
				xml.append(id);
				xml.append("</id>");
				xml.append("</matchAmt>");

			}
			xml.append("</InterNExpMstr>");
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			out.println(xml);
			System.out.println(xml);
			out.flush();
		} catch (SQLException seq) {
			seq.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (prepareStmt != null) {
					prepareStmt.close();
				}
				myConnection.close();

			} catch (Exception e) {
				myConnection = null;
				error_msg = e.getMessage();
				return "failure";
			}

		}
		return null;
	}
}
