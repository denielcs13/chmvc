package commonController;

import java.sql.Connection;
import java.sql.ResultSet;

public class Logintes {

	
	Connection conn;
	Boolean status;
	//PreparedStatement psmt;
	ResultSet rs;
   
	public Boolean validate(String id,String pass) throws Exception
	{
 		conn=new Connectionc().getConnection();
 		System.out.println("test1");
 		//psmt=conn.prepareStatement("select * from login where userid=? and password=?");
 		System.out.println("test11"+conn);
 		
		
	return status;	
	}

}
