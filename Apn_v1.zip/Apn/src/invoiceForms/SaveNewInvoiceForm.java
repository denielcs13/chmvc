package invoiceForms;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;






public class SaveNewInvoiceForm  {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int prashidCounter;
    
    private int suppliernumber;
    private String suppliername;
    private String supplierSite;
    private String gstno;
    private String invno;
    private String hsn;
    private String sec;
    private String description;
    private String basicAmt;
    private String gstAmt;
    private String gross;
    private String tds;
    private String advance;
    private String other;
    private String net;
    private String othernote;
    private String totalinvAmt;
    private int orgId;
    public int siteid;
    public String invoiceDate;
    public String finYear;
    public String frmDate;
    public String toDate;
    
   public String invtype;
   public String currency;
   public String totalpreAmt;
   public String totaldedAmt;
   public String preinvId;
   public String dedinvId;
   public String rcmfuncflag;
    
	public int getPrashidCounter() {
		return prashidCounter;
	}
	public void setPrashidCounter(int prashidCounter) {
		this.prashidCounter = prashidCounter;
	}
	
	public String getGstno() {
		return gstno;
	}
	public void setGstno(String gstno) {
		this.gstno = gstno;
	}
	public String getInvno() {
		return invno;
	}
	public void setInvno(String invno) {
		this.invno = invno;
	}
	public String getHsn() {
		return hsn;
	}
	public void setHsn(String hsn) {
		this.hsn = hsn;
	}
	public String getSec() {
		return sec;
	}
	public void setSec(String sec) {
		this.sec = sec;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBasicAmt() {
		return basicAmt;
	}
	public void setBasicAmt(String basicAmt) {
		this.basicAmt = basicAmt;
	}
	public String getGstAmt() {
		return gstAmt;
	}
	public void setGstAmt(String gstAmt) {
		this.gstAmt = gstAmt;
	}
	public String getGross() {
		return gross;
	}
	public void setGross(String gross) {
		this.gross = gross;
	}
	public String getTds() {
		return tds;
	}
	public void setTds(String tds) {
		this.tds = tds;
	}
	public String getAdvance() {
		return advance;
	}
	public void setAdvance(String advance) {
		this.advance = advance;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public String getNet() {
		return net;
	}
	public void setNet(String net) {
		this.net = net;
	}
	public String getOthernote() {
		return othernote;
	}
	public void setOthernote(String othernote) {
		this.othernote = othernote;
	}
	public String getTotalinvAmt() {
		return totalinvAmt;
	}
	public void setTotalinvAmt(String totalinvAmt) {
		this.totalinvAmt = totalinvAmt;
	}
	public int getOrgId() {
		return orgId;
	}
	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}
	public String getSuppliername() {
		return suppliername;
	}
	public void setSuppliername(String suppliername) {
		this.suppliername = suppliername;
	}
	
	public String getSupplierSite() {
		return supplierSite;
	}
	public void setSupplierSite(String supplierSite) {
		this.supplierSite = supplierSite;
	}
	public int getSiteid() {
		return siteid;
	}
	public void setSiteid(int siteid) {
		this.siteid = siteid;
	}
	public int getSuppliernumber() {
		return suppliernumber;
	}
	public void setSuppliernumber(int suppliernumber) {
		this.suppliernumber = suppliernumber;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	
	public String getFinYear() {
		return finYear;
	}
	public void setFinYear(String finYear) {
		this.finYear = finYear;
	}
	public String getFrmDate() {
		return frmDate;
	}
	public void setFrmDate(String frmDate) {
		this.frmDate = frmDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getInvtype() {
		return invtype;
	}
	public void setInvtype(String invtype) {
		this.invtype = invtype;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getTotalpreAmt() {
		return totalpreAmt;
	}
	public void setTotalpreAmt(String totalpreAmt) {
		this.totalpreAmt = totalpreAmt;
	}
	public String getTotaldedAmt() {
		return totaldedAmt;
	}
	public void setTotaldedAmt(String totaldedAmt) {
		this.totaldedAmt = totaldedAmt;
	}
	public String getPreinvId() {
		return preinvId;
	}
	public void setPreinvId(String preinvId) {
		this.preinvId = preinvId;
	}
	public String getDedinvId() {
		return dedinvId;
	}
	public void setDedinvId(String dedinvId) {
		this.dedinvId = dedinvId;
	}
	public String getRcmfuncflag() {
		return rcmfuncflag;
	}
	public void setRcmfuncflag(String rcmfuncflag) {
		this.rcmfuncflag = rcmfuncflag;
	}
    
	
    
    
}
