package invoiceForms;

import java.io.Serializable;

public class SearchPrepaymentForm implements Serializable{


	private static final long serialVersionUID = 1L;

	
	private String invoiceId;
	private String prepayNum;
	private String prepayAmt;
	private String prepayBal;
	private String amountPaid;
	
///Fields for deductions
	private String dedInvId;
	private String creditMemNo;
	private String creditMemAmt;
	private String remAmt;
	
	
	
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public String getPrepayNum() {
		return prepayNum;
	}
	public void setPrepayNum(String prepayNum) {
		this.prepayNum = prepayNum;
	}
	public String getPrepayAmt() {
		return prepayAmt;
	}
	public void setPrepayAmt(String prepayAmt) {
		this.prepayAmt = prepayAmt;
	}
	public String getPrepayBal() {
		return prepayBal;
	}
	public void setPrepayBal(String prepayBal) {
		this.prepayBal = prepayBal;
	}
	public String getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(String amountPaid) {
		this.amountPaid = amountPaid;
	}
	public String getDedInvId() {
		return dedInvId;
	}
	public void setDedInvId(String dedInvId) {
		this.dedInvId = dedInvId;
	}
	public String getCreditMemNo() {
		return creditMemNo;
	}
	public void setCreditMemNo(String creditMemNo) {
		this.creditMemNo = creditMemNo;
	}
	public String getCreditMemAmt() {
		return creditMemAmt;
	}
	public void setCreditMemAmt(String creditMemAmt) {
		this.creditMemAmt = creditMemAmt;
	}
	public String getRemAmt() {
		return remAmt;
	}
	public void setRemAmt(String remAmt) {
		this.remAmt = remAmt;
	}
	
	
	
}
