package invoiceCreation;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.test.annotation.Rollback;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import invoiceForms.InvoiceApprovalForm;

@Controller
public class InvoiceApprovalController {
	
	@RequestMapping(value="/invoiceapproval",  method = {RequestMethod.POST,RequestMethod.GET}) 
    public String invApproval(ModelMap model, InvoiceApprovalForm invoiceApprForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
	
		Connection conn;
		HttpSession session=request.getSession();
		String userName=(String)session.getAttribute("name");
		String role=(String)session.getAttribute("role");
		String loginId=(String)session.getAttribute("loginID");
		String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
		String forward="";
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		String msg="";
		CallableStatement cs=null;
		conn=new Connectionc().getConnection();
		String[] invStatus=null;
		ArrayList invstArry=new ArrayList();
		try {
		
		msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
		request.setAttribute("msg", msg);

		String query=bundle.getString("getApprovalInvStat");
		ps=conn.prepareStatement(query);
		
		rs=ps.executeQuery();
		
		while(rs.next()) {
			invStatus=new String[2];
			invStatus[0]=rs.getString(1);
			invStatus[1]=rs.getString(2);
			
			invstArry.add(invStatus);
		}
		request.setAttribute("invstArry", invstArry);
		if(flag.equals("search")){	
		
			
			forward="approvalinv";
			ArrayList invoicehdrs=new ArrayList();
			String[] invdtls=null;
			String afpno=request.getParameter("afpno")!=null?request.getParameter("afpno"):"";
			String invoiceno=request.getParameter("invnumber")!=null?request.getParameter("invnumber"):"";
			ArrayList invoicelines=new ArrayList();
			String[] invlinesdtls=null;	
			String invHeaderQry=null;
			ArrayList filelines=new ArrayList();
			String[] filedtls=null;
			String getFileDetails= bundle.getString("getInvUploadedFiles");
			if(role.equals("3")) {
				
			 //invHeaderQry = bundle.getString("getsubmittedInvHeader");
				invHeaderQry = bundle.getString("getsubmittedInvHeader");
				
			 ps=conn.prepareStatement(invHeaderQry);
				System.out.println(invHeaderQry);
				ps.setString(1, afpno);
				
				rs=ps.executeQuery();
				
				/*while(rs.next()) {
					invdtls=new String[19];
					invdtls[0]=rs.getString(1);
					invdtls[1]=rs.getString(2);
					invdtls[2]=rs.getString(3);
					invdtls[3]=rs.getString(4);
					invdtls[4]=rs.getString(5);
					invdtls[5]=rs.getString(6);
					invdtls[6]=rs.getString(7);
					invdtls[7]=rs.getString(8);
					invdtls[8]=rs.getString(9);
					invdtls[9]=rs.getString(10);
					invdtls[10]=rs.getString(11);
					invdtls[11]=rs.getString(12)!=null?rs.getString(12):"";		//approverRemarks
					invdtls[12]=rs.getString(13)!=null?rs.getString(13):"";		//aprrover date
					invdtls[13]=rs.getString(14)!=null?rs.getString(14):"";		//finance remarks
					invdtls[14]=rs.getString(15)!=null?rs.getString(15):"";		//finance Date
					invdtls[15]=rs.getString(16)!=null?rs.getString(16):"";		//Invoice Date
					invdtls[16]=rs.getString(17)!=null?rs.getString(17):"";
					invdtls[17]=rs.getString(18)!=null?rs.getString(18):"";
					invdtls[18]=rs.getString(19)!=null?rs.getString(19):"";
					
					invoicehdrs.add(invdtls);
				}		*/
				while(rs.next()) {
					invdtls=new String[23];
					invdtls[0]=rs.getString(1)!=null?rs.getString(1):"";		//AfpNo
					invdtls[1]=rs.getString(2)!=null?rs.getString(2):"";		//InvoiceNo
					invdtls[2]=rs.getString(3)!=null?rs.getString(3):"";		//SupplierNO
					invdtls[3]=rs.getString(4)!=null?rs.getString(4):"";		//supplierName
					invdtls[4]=rs.getString(5)!=null?rs.getString(5):"";		//site Code
					invdtls[5]=rs.getString(6)!=null?rs.getString(6):"";		//site Id
					invdtls[6]=rs.getString(7)!=null?rs.getString(7):"";		//gstno
					invdtls[7]=rs.getString(8)!=null?rs.getString(8):"";		//totalInvAmt
					invdtls[8]=rs.getString(9)!=null?rs.getString(9):"";		//remarks
					invdtls[9]=rs.getString(10)!=null?rs.getString(10):"";		//invStatus
					invdtls[10]=rs.getString(11)!=null?rs.getString(11):"";		//status Code
					invdtls[11]=rs.getString(12)!=null?rs.getString(12):"";		//approverRemarks
					invdtls[12]=rs.getString(13)!=null?rs.getString(13):"";		//aprrover date
					invdtls[13]=rs.getString(14)!=null?rs.getString(14):"";		//finance remarks
					invdtls[14]=rs.getString(15)!=null?rs.getString(15):"";		//finance Date
					invdtls[15]=rs.getString(16)!=null?rs.getString(16):"";		//Invoice Date
					invdtls[16]=rs.getString(17)!=null?rs.getString(17):"";		//EXP From dt
					invdtls[17]=rs.getString(18)!=null?rs.getString(18):"";		//EXP to dt
					invdtls[18]=rs.getString(19)!=null?rs.getString(19):"";		//Financial year
					invdtls[19]=rs.getString(20)!=null?rs.getString(20):"";		//Currency
					invdtls[20]=rs.getString(21)!=null?rs.getString(21):"";		//inv type
					invdtls[21]=rs.getString(22)!=null?rs.getString(22):"";		//Prepay Amt
					invdtls[22]=rs.getString(23)!=null?rs.getString(23):"";		//Deduction Amt
					
					invoicehdrs.add(invdtls);
				}	
			}else {
				invHeaderQry = bundle.getString("getfinsubmittedInvHeader");
				ps=conn.prepareStatement(invHeaderQry);
				ps.setString(1, afpno);
			
			//invHeaderQry = invHeaderQry +"and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(voucher_number)like nvl(upper('%"+afpno+"%'),upper(voucher_number))";
			System.out.println(invHeaderQry);
		
		rs=ps.executeQuery();
		
/*		while(rs.next()) {
			invdtls=new String[19];
			invdtls[0]=rs.getString(1);
			invdtls[1]=rs.getString(2);
			invdtls[2]=rs.getString(3);
			invdtls[3]=rs.getString(4);
			invdtls[4]=rs.getString(5);
			invdtls[5]=rs.getString(6);
			invdtls[6]=rs.getString(7);
			invdtls[7]=rs.getString(8);
			invdtls[8]=rs.getString(9);
			invdtls[9]=rs.getString(10);
			invdtls[10]=rs.getString(11);
			invdtls[11]=rs.getString(12);
			invdtls[12]=rs.getString(13);
			invdtls[13]=rs.getString(14);
			invdtls[13]=rs.getString(14)!=null?rs.getString(14):"";		//finance remarks
			invdtls[14]=rs.getString(15)!=null?rs.getString(15):"";		//finance Date
			invdtls[15]=rs.getString(16)!=null?rs.getString(16):"";		//Invoice Date
			invdtls[16]=rs.getString(17)!=null?rs.getString(17):"";
			invdtls[17]=rs.getString(18)!=null?rs.getString(18):"";
			invdtls[18]=rs.getString(19)!=null?rs.getString(19):"";
			
			invoicehdrs.add(invdtls);
		}*/
		while(rs.next()) {
			invdtls=new String[23];
			invdtls[0]=rs.getString(1)!=null?rs.getString(1):"";		//AfpNo
			invdtls[1]=rs.getString(2)!=null?rs.getString(2):"";		//InvoiceNo
			invdtls[2]=rs.getString(3)!=null?rs.getString(3):"";		//SupplierNO
			invdtls[3]=rs.getString(4)!=null?rs.getString(4):"";		//supplierName
			invdtls[4]=rs.getString(5)!=null?rs.getString(5):"";		//site Code
			invdtls[5]=rs.getString(6)!=null?rs.getString(6):"";		//site Id
			invdtls[6]=rs.getString(7)!=null?rs.getString(7):"";		//gstno
			invdtls[7]=rs.getString(8)!=null?rs.getString(8):"";		//totalInvAmt
			invdtls[8]=rs.getString(9)!=null?rs.getString(9):"";		//remarks
			invdtls[9]=rs.getString(10)!=null?rs.getString(10):"";		//invStatus
			invdtls[10]=rs.getString(11)!=null?rs.getString(11):"";		//status Code
			invdtls[11]=rs.getString(12)!=null?rs.getString(12):"";		//approverRemarks
			invdtls[12]=rs.getString(13)!=null?rs.getString(13):"";		//aprrover date
			invdtls[13]=rs.getString(14)!=null?rs.getString(14):"";		//finance remarks
			invdtls[14]=rs.getString(15)!=null?rs.getString(15):"";		//finance Date
			invdtls[15]=rs.getString(16)!=null?rs.getString(16):"";		//Invoice Date
			invdtls[16]=rs.getString(17)!=null?rs.getString(17):"";		//EXP From dt
			invdtls[17]=rs.getString(18)!=null?rs.getString(18):"";		//EXP to dt
			invdtls[18]=rs.getString(19)!=null?rs.getString(19):"";		//Financial year
			invdtls[19]=rs.getString(20)!=null?rs.getString(20):"";		//Currency
			invdtls[20]=rs.getString(21)!=null?rs.getString(21):"";		//inv type
			invdtls[21]=rs.getString(22)!=null?rs.getString(22):"";		//Prepay Amt
			invdtls[22]=rs.getString(23)!=null?rs.getString(23):"";		//Deduction Amt
			
			invoicehdrs.add(invdtls);
		}
    }	
		request.setAttribute("invoicehdrs", invoicehdrs);
		request.setAttribute("invoicehdrsSize", invoicehdrs.size());
		
		rs=null;
		ps=null;
		String invLinesQry = bundle.getString("getsubmittedInvLines");
		ps=conn.prepareStatement(invLinesQry);
		System.out.println(invLinesQry);
		ps.setString(1, afpno);
		//ps.setString(1, "1/27-AUG-19");
		rs=ps.executeQuery();
		
		/*while(rs.next()) {
			invlinesdtls=new String[15];
			invlinesdtls[0]=rs.getString(1);	//line Id
			invlinesdtls[1]=rs.getString(2);	//HSN
			invlinesdtls[2]=rs.getString(3);	//sec
			invlinesdtls[3]=rs.getString(4);	//nature of Exp
			invlinesdtls[4]=rs.getString(5);	//basic
			invlinesdtls[5]=rs.getString(6);	//gross
			invlinesdtls[6]=rs.getString(7);	//tds
			invlinesdtls[7]=rs.getString(8);	//advance
			invlinesdtls[8]=rs.getString(9);	//other
			invlinesdtls[9]=rs.getString(10);	//total_amt
			invlinesdtls[10]=rs.getString(11);	//department
			invlinesdtls[11]=rs.getString(12);	//product
			invlinesdtls[12]=rs.getString(13);	//cgst
			invlinesdtls[13]=rs.getString(14);	//sgst
			invlinesdtls[14]=rs.getString(15);	//igst
			
			invoicelines.add(invlinesdtls);
		}		*/
		while(rs.next()) {
			invlinesdtls=new String[17];
			invlinesdtls[0]=rs.getString(1);	//line Id
			invlinesdtls[1]=rs.getString(2);	//HSN
			invlinesdtls[2]=rs.getString(3);	//sec
			invlinesdtls[3]=rs.getString(4);	//nature of Exp
			invlinesdtls[4]=rs.getString(5);	//basic
			invlinesdtls[5]=rs.getString(6);	//gross
			invlinesdtls[6]=rs.getString(7);	//tds
			//invlinesdtls[7]=rs.getString(8);	//advance
			//invlinesdtls[8]=rs.getString(9);	//other
			invlinesdtls[7]=rs.getString(16);	//line location
			invlinesdtls[8]=rs.getString(17);	//tax type
			invlinesdtls[9]=rs.getString(10);	//total_amt
			invlinesdtls[10]=rs.getString(11);	//department
			invlinesdtls[11]=rs.getString(12);	//product
			invlinesdtls[12]=rs.getString(13);	//cgst
			invlinesdtls[13]=rs.getString(14);	//sgst
			invlinesdtls[14]=rs.getString(15);	//igst
			invlinesdtls[15]=rs.getString(18);	//text descr
			invlinesdtls[16]=rs.getString(19);	//inv No
			
			invoicelines.add(invlinesdtls);
		}
		
		rs=null;	ps=null;
		
		ps=conn.prepareStatement(getFileDetails);
		System.out.println(getFileDetails);
		ps.setString(1, afpno);
		rs=ps.executeQuery();
		
		while(rs.next()) {
			filedtls=new String[3];
			filedtls[0]=rs.getString(1);
			filedtls[1]=rs.getString(2)!=null?rs.getString(2):"";
			filedtls[2]=rs.getString(3);
			
			filelines.add(filedtls);
		}	
		
		request.setAttribute("invoicelines", invoicelines);		
		request.setAttribute("afpno",afpno);
		request.setAttribute("filelines", filelines);
		request.setAttribute("filelinesSize", filelines.size());
		
		
	}
///////Invoice Approval By Super User		
		else if(flag.equals("apprInv")){
		//forward="redirect:/invoiceapproval?flag=search";
		forward="invoiceapproval";
					
		String afpno=request.getParameter("apfnumber")!=null?request.getParameter("apfnumber"):"";
		String approveRejInv = bundle.getString("approveRejInv");
		String apprRemarks=request.getParameter("apprRemarks")!=null?request.getParameter("apprRemarks"):"";
		String status= request.getParameter("status")!=null?request.getParameter("status"):"";
			
		ps=conn.prepareStatement(approveRejInv);
		System.out.println(approveRejInv);
		
		ps.setString(1, apprRemarks);
		ps.setString(2, userName);
		ps.setString(3, status);
		ps.setString(4, afpno);
	
	
	int check=ps.executeUpdate();
	if(check==1) {
		cs=conn.prepareCall("{call sendInvMail(?,?)}");
		cs.setString(1,afpno);
		cs.setString(2,status);
        cs.execute();
		msg="Invoice Approved";
	}else {
		msg="Some error Occurred.Please check with Administrator";
	}
	request.setAttribute("msg",msg);
	
	}
	else if(flag.equals("searchapprInv")){
		forward="invoiceapproval";
		ArrayList viewinvoicehdrs=new ArrayList();
		String[] invdtls=null;
		String afpno=request.getParameter("afpno")!=null?request.getParameter("afpno"):"";
		String invoiceno=request.getParameter("invoiceno")!=null?request.getParameter("invoiceno"):"";
		//String viewinvHeaderQry = bundle.getString("viewinvheader");
		String viewinvHeaderQry = bundle.getString("viewExpAFPheader");
		System.out.println("query check:"+viewinvHeaderQry); 
		String queryPart=" and status='P' and exp.supervisor = '"+loginId+"' GROUP BY expno,exp.SUBMITTED_BY,exp.expense_category,exp.status,st.name ";
		//String queryPart=" and status='P' GROUP BY expno,exp.SUBMITTED_BY,exp.expense_category,exp.status,st.name ";
		String queryPart1=" and status not in('P','I','A','R') GROUP BY expno,exp.SUBMITTED_BY,exp.expense_category,exp.status,st.name ";
		if(role.equals("3")) {		
			//viewinvHeaderQry=viewinvHeaderQry+" and status='P' and mstr.attribute1=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(afpno)like nvl(upper('%"+afpno+"%'),upper(afpno)) order by afpno desc";
			viewinvHeaderQry=viewinvHeaderQry+" and status='P' and mstr.attribute1=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(afpno)like nvl(upper('%"+afpno+"%'),upper(afpno)) union ";
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("expInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("entertainInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("foodExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("localConvExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("miscllExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("interNExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("combineExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			
			System.out.println("query for role id: 3 "+viewinvHeaderQry);
			ps=conn.prepareStatement(viewinvHeaderQry);
			
			ps.setString(1, loginId);
			}
		else {		
			//viewinvHeaderQry=viewinvHeaderQry+" and status='S' and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(afpno)like nvl(upper('%"+afpno+"%'),upper(afpno)) order by afpno desc";
			viewinvHeaderQry=viewinvHeaderQry+" and status not in('P','I','A','R') and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(afpno)like nvl(upper('%"+afpno+"%'),upper(afpno)) union ";
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("expInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("entertainInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("foodExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("localConvExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("miscllExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("interNExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("combineExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart1;
			System.out.println("query for other than role id: 3 "+viewinvHeaderQry);
			ps=conn.prepareStatement(viewinvHeaderQry);
			
			}
	
		//System.out.println(viewinvHeaderQry);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		invdtls=new String[11];
		invdtls[0]=rs.getString(1);
		invdtls[1]=rs.getString(2);
		invdtls[2]=rs.getString(3);
		invdtls[3]=rs.getString(4);
		invdtls[4]=rs.getString(5);
		invdtls[5]=rs.getString(6);
		invdtls[6]=rs.getString(7);
		invdtls[7]=rs.getString(8);
		invdtls[8]=rs.getString(9);
		invdtls[9]=rs.getString(10);
		invdtls[10]=rs.getString(11);
		//System.out.println("bypass: "+rs.getString(11));
		
		viewinvoicehdrs.add(invdtls);
	}	
	//System.out.println("all hearders data: "+viewinvoicehdrs);
	request.setAttribute("invoicehdrs", viewinvoicehdrs);
	//System.out.println("all hearders data: "+viewinvoicehdrs);
	
	request.setAttribute("invoicehdrsSize", viewinvoicehdrs.size());
	}
///////Invoice Appproval by Finance	
	else if(flag.equals("finapprInv")){
		forward="invoiceapproval";
		int seq=0;
		String voucherNm=null;
		String afpno=request.getParameter("apfnumber")!=null?request.getParameter("apfnumber"):"";
		String finRemarks=request.getParameter("finRemarks")!=null?request.getParameter("finRemarks"):"";
		String status= request.getParameter("status")!=null?request.getParameter("status"):"";
		String glDate= request.getParameter("gldate")!=null?request.getParameter("gldate"):"";
		
		/*SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		DateFormat df2 = new SimpleDateFormat("dd/MM/yyyy");
		Date date = formatter.parse(glDate);
		String glDate1=df2.format(date);
		
		String query="select nvl(max(VOUCHER_SEQ)+1,'1001') seq from XXBAF_INVOICE_MSTR where gl_date=?";
		ps=conn.prepareStatement(query);
		ps.setString(1, glDate);
		rs=ps.executeQuery();
		while(rs.next()) {
			seq=rs.getInt(1);
		}
		
		String query1="select 'AFP/AP/'||'"+seq+"'||'/'||? voucher from dual";
		ps=conn.prepareStatement(query1);
		ps.setString(1, glDate1.replace("/", ""));
		rs=ps.executeQuery();
		
		while(rs.next()) {
			voucherNm=rs.getString(1);
		}*/
		
		String finapproveRejInv = bundle.getString("finapproveInv");			
		ps=conn.prepareStatement(finapproveRejInv);
		System.out.println(finapproveRejInv);
		
		ps.setString(1, finRemarks);
		ps.setString(2, userName);
		ps.setString(3, status);
		ps.setString(4, glDate);
		/*ps.setString(5, voucherNm);
		ps.setInt(6, seq);*/
		ps.setString(5, afpno);
	
	
	int check=ps.executeUpdate();
	if(check==1) {	
		cs=conn.prepareCall("{call sendInvMail(?,?)}");
		cs.setString(1,afpno);
		cs.setString(2,status);
        cs.execute();
		
		msg="Invoice Approved with Voucher Number "+voucherNm;
	}else {
		msg="Some error Occurred.Please check with Administrator";
	}
	request.setAttribute("msg",msg);
	
	}
/////Invoice Rejection By Finance		
	else if(flag.equals("finRejectInv")){
		forward="invoiceapproval";
				
		String afpno=request.getParameter("apfnumber")!=null?request.getParameter("apfnumber"):"";
		String finRemarks=request.getParameter("finRemarks")!=null?request.getParameter("finRemarks"):"";
		String status= request.getParameter("status")!=null?request.getParameter("status"):"";
		
		String finapproveRejInv = bundle.getString("finRejInv");			
		ps=conn.prepareStatement(finapproveRejInv);
		System.out.println(finapproveRejInv);
		
		ps.setString(1, finRemarks);
		ps.setString(2, userName);
		ps.setString(3, status);
		ps.setString(4, afpno);
	
	
	int check=ps.executeUpdate();
	if(check==1) {
		cs=conn.prepareCall("{call sendInvMail(?,?)}");
		cs.setString(1,afpno);
		cs.setString(2,status);
        cs.execute();
		msg="Invoice Rejected";
	}else {
		msg="Some error Occurred.Please check with Administrator";
	}
	request.setAttribute("msg",msg);
	
	}	
//////Invoice Rejection by Super User
	else if(flag.equals("rejInv")){
		
		forward="invoiceapproval";
				
		String afpno=request.getParameter("apfnumber")!=null?request.getParameter("apfnumber"):"";
		String approveRejInv = bundle.getString("approveRejInv");
		String apprRemarks=request.getParameter("apprRemarks")!=null?request.getParameter("apprRemarks"):"";
		String status= request.getParameter("status")!=null?request.getParameter("status"):"";
			
		ps=conn.prepareStatement(approveRejInv);
		System.out.println(approveRejInv);
		
		ps.setString(1, apprRemarks);
		ps.setString(2, userName);
		ps.setString(3, status);
		ps.setString(4, afpno);
	
	
	int check=ps.executeUpdate();
	if(check==1) {
		cs=conn.prepareCall("{call sendInvMail(?,?)}");
		cs.setString(1,afpno);
		cs.setString(2,status);
        cs.execute();
		msg="Invoice Rejected";
	}else {
		msg="Some error Occurred.Please check with Administrator";
	}
	request.setAttribute("msg",msg);
	}
	else if(flag.equals("multiInv")){
		
		forward="invoiceapproval";
		int check=0;		
		String afpno=request.getParameter("afpno");
		String apf[]=afpno.split(",");
		
 		int count=Integer.parseInt(request.getParameter("chkcnt"));
		String approveRejInv = bundle.getString("approveRejInv");
		String approveRejEXPInv = bundle.getString("approveRejEXPInv");
		String approveRejEnterInv = bundle.getString("approveRejEnterInv");
		String approveRejFoodInv = bundle.getString("approveRejFoodInv");
		String approveRejLocalInv = bundle.getString("approveRejLocalInv");
		String approveRejMisceInv = bundle.getString("approveRejMisceInv");
		String approveRejInterInv = bundle.getString("approveRejInterInv");
		String approveRejCombineInv = bundle.getString("approveRejCombineInv");
		String apprRemarks=request.getParameter("apprRemarks")!=null?request.getParameter("apprRemarks"):"";
		String status= request.getParameter("status")!=null?request.getParameter("status"):"";
			
		
		System.out.println(approveRejInv);
		
		for(int i=0;i<count;i++) {
		String afpExp[]=apf[i].split("~");
		if(afpExp[2].equals("AFP"))
		ps=conn.prepareStatement(approveRejInv);
		else if(afpExp[1].equals("OutStation Travel"))
		ps=conn.prepareStatement(approveRejEXPInv);
		else if(afpExp[1].equals("Entertainment"))
			ps=conn.prepareStatement(approveRejEnterInv);
		else if(afpExp[1].equals("Food Expense"))
			ps=conn.prepareStatement(approveRejFoodInv);
		else if(afpExp[1].equals("Local Conveyance"))
			ps=conn.prepareStatement(approveRejLocalInv);
		else if(afpExp[1].equals("Miscellaneous"))
			ps=conn.prepareStatement(approveRejMisceInv);
		else if(afpExp[1].equals("International Travel"))
			ps=conn.prepareStatement(approveRejInterInv);
		else if(afpExp[1].equals("Combined - Food and conveyance"))
			ps=conn.prepareStatement(approveRejCombineInv);
		
		ps.setString(1, apprRemarks);
		ps.setString(2, userName);
		ps.setString(3, status);
		ps.setString(4, afpExp[0]);
	
		check=ps.executeUpdate();
		/*cs=conn.prepareCall("{call sendInvMail(?,?)}");
		cs.setString(1,apf[i]);
		cs.setString(2,status);
        cs.execute();*/
		}	
	if(check>=1) {
		msg="Invoice Approved";
	}else {
		conn.rollback();
		msg="Some error Occurred.Please check with Administrator";
	}
	request.setAttribute("msg",msg);
	}
	else if(flag.equals("multiFinInv")) {
		forward="invoiceapproval";
		int check=0;		
		//String afpno=request.getParameter("afpno");
		//String apf[]=afpno.split(",");
		//String gldt=request.getParameter("glDate");
		//String gldate[]=gldt.split(",");
 		int count=Integer.parseInt(request.getParameter("chkcnt"));
 		String afpStr=request.getParameter("afpstr");
		String multiapproveFinInv = bundle.getString("multiapproveFinInv");
		String multiapproveFinExpInv = bundle.getString("multiapproveFinExpInv");
		String multiapproveFinEnterInv = bundle.getString("multiapproveFinEnterInv");
		String multiapproveFinFoodInv = bundle.getString("multiapproveFinFoodInv");
		String multiapproveFinLocalInv = bundle.getString("multiapproveFinLocalInv");
		String multiapproveFinMisceInv = bundle.getString("multiapproveFinMisceInv");
		String multiapproveFinInterInv = bundle.getString("multiapproveFinInterInv");
		
		String apprRemarks=request.getParameter("apprRemarks")!=null?request.getParameter("apprRemarks"):"";
		//String status= request.getParameter("status")!=null?request.getParameter("status"):"";
		cs=null;
		String seprator="@@";
		String apf[]=afpStr.split("@@");
		String afpTotalStr="";
		String expTotalStr="";
		String apprFlag="";
		for(int i=0;i<count;i++) {
			String afpExp[]=apf[i].split("~");
			if(afpExp[2].equals("AFP")) {
				//ps=conn.prepareStatement(multiapproveFinInv);
				afpTotalStr+=afpExp[0]+'~'+afpExp[3]+'~'+afpExp[4]+seprator;			
			}else {
				expTotalStr+=afpExp[0]+'~'+afpExp[3]+'~'+afpExp[4]+seprator;	
				
				if(afpExp[4].equals("A")) {
					apprFlag="C";
				}
				
				if(afpExp[1].equals("OutStation Travel")) {
					//ps=conn.prepareStatement(multiapproveFinExpInv);
					 cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_OUT(?,?,?,?)}");
					cs.setString(1,expTotalStr);
					cs.setString(2,userName);
					cs.setString(3,apprRemarks);
					cs.registerOutParameter(4, Types.VARCHAR);  //afpno
			        	
				 }
					else if(afpExp[1].equals("Entertainment")) {
						//ps=conn.prepareStatement(multiapproveFinEnterInv);
						 cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_ENTER(?,?,?,?)}");
							cs.setString(1,expTotalStr);
							cs.setString(2,userName);
							cs.setString(3,apprRemarks);
							cs.registerOutParameter(4, Types.VARCHAR);  //afpno
					       
					}
					else if(afpExp[1].equals("Food Expense")) {
						//ps=conn.prepareStatement(multiapproveFinFoodInv);
						cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_FOOD(?,?,?,?)}");
						cs.setString(1,expTotalStr);
						cs.setString(2,userName);
						cs.setString(3,apprRemarks);
						cs.registerOutParameter(4, Types.VARCHAR);  //afpno
						
					}
					else if(afpExp[1].equals("Local Conveyance")) {
						//ps=conn.prepareStatement(multiapproveFinLocalInv);
						cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_LOC_CON(?,?,?,?)}");
						cs.setString(1,expTotalStr);
						cs.setString(2,userName);
						cs.setString(3,apprRemarks);
						cs.registerOutParameter(4, Types.VARCHAR);  //afpno
					}
					else if(afpExp[1].equals("Miscellaneous")) {
						//ps=conn.prepareStatement(multiapproveFinMisceInv);
						cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_MISC(?,?,?,?)}");
						cs.setString(1,expTotalStr);
						cs.setString(2,userName);
						cs.setString(3,apprRemarks);
						cs.registerOutParameter(4, Types.VARCHAR);  //afpno
					}
					else if(afpExp[1].equals("International Travel")) {
						//ps=conn.prepareStatement(multiapproveFinInterInv);
						cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_INTL(?,?,?,?)}");
						cs.setString(1,expTotalStr);
						cs.setString(2,userName);
						cs.setString(3,apprRemarks);
						cs.registerOutParameter(4, Types.VARCHAR);  //afpno
					}
					else if(afpExp[1].equals("Combined - Food and conveyance")) {
						//ps=conn.prepareStatement(multiapproveFinInterInv);
						cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EMP_EXP_COMBINE(?,?,?,?)}");
						cs.setString(1,expTotalStr);
						cs.setString(2,userName);
						cs.setString(3,apprRemarks);
						cs.registerOutParameter(4, Types.VARCHAR);  //afpno
					}
				 cs.execute();
						
			/*ps.setString(1, apprRemarks);
			ps.setString(2, userName);
			ps.setString(3, afpExp[4]);
			ps.setString(4, afpExp[3]);
			ps.setString(5, afpExp[0]);
		
			check=ps.executeUpdate();*/
				 
			}
			/*cs=conn.prepareCall("{call sendInvMail(?,?)}");
			cs.setString(1,apf[i]);
			cs.setString(2,status);
	        cs.execute();*/
			}
		
		if(!(("".equals(expTotalStr)) && ("".equals(apprFlag)))) {
			
			cs=conn.prepareCall("{call apps.XXBAF_EMP_EXP_PKG.XXBAF_EXPENSE_IMPORT()}");
			cs.execute();
	}
		
		if(!("".equals(afpTotalStr))) {
		cs=conn.prepareCall("{call apps.XXBAF_AP_INV_LOAD(?,?,?,?)}");
		cs.setString(1,afpTotalStr);
		cs.setString(2,userName);
		cs.setString(3,apprRemarks);
		cs.registerOutParameter(4, Types.VARCHAR);  //afpno
        
        cs.execute();	
        check=1;
		}
		
   if(check>=1) {
		msg="Invoice Approved";
	}else {
		conn.rollback();
		msg="Some error Occurred.Please check with Administrator";
	}
	//request.setAttribute("msg",msg);
	}
		
	else {
		forward="invoiceapproval";
		System.out.println("In Search Invoice");
	}
		}catch(Exception e) {
			try{conn.rollback();
			
			}catch(Exception e1){
				
			}
			forward="welcome";
			msg="Some error Occurred.Please check with Administrator";
			request.setAttribute("msg",msg);
			e.printStackTrace();
		}
		return forward;
    }

}
