package invoiceCreation;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import commonController.Md5;

@Controller

public class CreateNewInvoiceController {
	@RequestMapping(value = "/createnewInvoice", method= {RequestMethod.GET,RequestMethod.POST})
	public String createInvoice(Model model,HttpServletRequest request,HttpServletResponse response) {
	
	
	Connection conn;
	HttpSession session=request.getSession();
	String userName=(String)session.getAttribute("userName");
	ResultSet rs=null;
	PreparedStatement ps=null;
	String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
	request.setAttribute("msg",msg);
	ArrayList yearList=new ArrayList();
	String[] finYears=null;
	ArrayList descList=new ArrayList();
	String[] description=null;
	ArrayList productList=new ArrayList();
	String[] product=null;
	ArrayList departmentList=new ArrayList();
	String[] department=null;
	ArrayList CurrencyList=new ArrayList();
	String[] currency=null;
	String[] invtype=null;
	ArrayList InvoiceList=new ArrayList();
	String[] location=null;
	ArrayList LocationList=new ArrayList();
	String[] taxtype=null;
	ArrayList TaxTypeList=new ArrayList();
	ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
	try {
		
	conn=new Connectionc().getConnection();
	String query=bundle.getString("getfinancialYears");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		finYears=new String[1];
		finYears[0]=rs.getString(1);
		
		yearList.add(finYears);
	}		
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getLineDesc");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		description=new String[2];
		description[0]=rs.getString(1);
		description[1]=rs.getString(2);
		
		descList.add(description);
	}		
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getProduct");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		product=new String[2];
		product[0]=rs.getString(1);
		product[1]=rs.getString(2);
		
		productList.add(product);
	}	
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getDepartment");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		department=new String[2];
		department[0]=rs.getString(1);
		department[1]=rs.getString(2);
		
		departmentList.add(department);
	}
	
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getCurrency");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		currency=new String[1];
		currency[0]=rs.getString(1);
				
		CurrencyList.add(currency);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getinvoiceType");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		invtype=new String[1];
		invtype[0]=rs.getString(1);
				
		InvoiceList.add(invtype);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query="select LOOKUP_CODE, DESCRIPTION STATE_CODE,TAG  from apps.fnd_lookup_VALUES  where lookup_type = 'AFP_STATE_CODE'  AND ENABLED_FLAG = 'Y'  AND END_DATE_ACTIVE IS NULL";
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		location=new String[3];
		location[0]=rs.getString(1);
		location[1]=rs.getString(2);
		location[2]=rs.getString(3);
				
		LocationList.add(location);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getTaxtype");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		taxtype=new String[2];
		taxtype[0]=rs.getString(1);
		taxtype[1]=rs.getString(2);
				
		TaxTypeList.add(taxtype);
	}
	
	request.setAttribute("yearList", yearList);
	request.setAttribute("descList", descList);
	request.setAttribute("productList", productList);
	request.setAttribute("departmentList", departmentList);
	request.setAttribute("CurrencyList",CurrencyList);
	request.setAttribute("InvoiceList",InvoiceList);
	request.setAttribute("LocationList",LocationList);
	request.setAttribute("TaxTypeList",TaxTypeList);
		
	
	}catch(Exception e) {
		e.printStackTrace();
	}
	return "newcreatenewinvoice";
}

	/*
	 * @RequestMapping(value="/existInvoice", method =
	 * {RequestMethod.POST,RequestMethod.GET}) public String existInvoice(Model
	 * model,HttpServletRequest request,HttpServletResponse response){
	 * System.out.println("+++++++++existInvoice++++++++++");
	 * 
	 * Connection myConnection = null; PreparedStatement preparedStatement = null;
	 * ResultSet resultSet = null; final String METHODNAME = "existInvoice"; String
	 * loggedUserLoginId = null; HttpSession session = request.getSession();
	 * ResourceBundle sqlBundle = ResourceBundle.getBundle("view/sql");
	 * 
	 * try{ loggedUserLoginId = (String)session.getAttribute("loginID");
	 * myConnection = new Connectionc().getConnection(); String
	 * vendorId=request.getParameter("userVID"); String
	 * invoiceNo=request.getParameter("invoiceNo"); String
	 * vendorSite=request.getParameter("vsite");
	 * System.out.println("invoiceNo"+invoiceNo); preparedStatement = null;
	 * resultSet = null; String invoiceNoQry = null; String count = null; int
	 * count_num = 0; String role = null; String canonDocNo =
	 * request.getParameter("canonDocNo");
	 * 
	 * role=(String)session.getAttribute("role");
	 * 
	 * String
	 * query="SELECT count(invoice_no) FROM XXBAF_INVOICE_MSTR  where invoice_no = ?  and supplier_no = ? and supplier_site = ?"
	 * ; preparedStatement=myConnection.prepareStatement(query);
	 * 
	 * preparedStatement.setString(1, invoiceNo); preparedStatement.setString(2,
	 * vendorId); preparedStatement.setString(3, vendorSite);
	 * 
	 * resultSet=preparedStatement.executeQuery();
	 * 
	 * while(resultSet.next()) { count_num=resultSet.getInt(1); }
	 * 
	 * PrintWriter out = response.getWriter(); out.println(count_num);
	 * }catch(Exception epoEx){
	 * 
	 * epoEx.printStackTrace(); }finally{ try{ if(resultSet!=null){
	 * resultSet.close(); } if(preparedStatement!=null){ preparedStatement.close();
	 * } if(myConnection!=null){ myConnection.close(); } }catch(Exception ex){
	 * myConnection=null;
	 * 
	 * ex.printStackTrace(); } } return null; }
	 */
}
