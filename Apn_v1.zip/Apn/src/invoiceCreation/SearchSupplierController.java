package invoiceCreation;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import invoiceForms.SearchsuppliersForm;

@Controller
public class SearchSupplierController {

	@RequestMapping(value="/searchsupplier",  method = {RequestMethod.POST,RequestMethod.GET})
	public String getSupplierName(ModelMap model, SearchsuppliersForm searchForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		Connection conn;
		HttpSession session=request.getSession();
		String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		String msg="";
		conn=new Connectionc().getConnection();
		String[]supplierdtls=null;
		ArrayList supplier=new ArrayList<>();
		try {
			
			if(flag.equals("search")) {
				String supplierName=request.getParameter("supplierName");
				String query=bundle.getString("getsuppliers");
				query=query+" and upper(VENDOR_NAME) like nvl(upper('%"+supplierName+"%'),upper(VENDOR_NAME)) ";
				ps=conn.prepareStatement(query);
				System.out.println(query);
				//ps.setString(1, supplierName);
				
				rs=ps.executeQuery();
				
				while(rs.next()) {
					searchForm=new SearchsuppliersForm();
					searchForm.setVendorId(rs.getString("VENDOR_ID")!=null?rs.getString("VENDOR_ID"):"-");
					searchForm.setVendorName(rs.getString("VENDOR_NAME")!=null?rs.getString("VENDOR_NAME"):"-");
					searchForm.setVendorNumber(rs.getString("VENDOR_NUMBER")!=null?rs.getString("VENDOR_NUMBER"):"-");
					searchForm.setVendortype(rs.getString("VENDOR_TYPE_LOOKUP_CODE")!=null?rs.getString("VENDOR_TYPE_LOOKUP_CODE"):"");
					
					supplier.add(searchForm);		
					
				}
				request.setAttribute("supplier", supplier);
				request.setAttribute("supplierSize", supplier.size());
				request.setAttribute("supplierName", supplierName);
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		return "searchsuppliers";
	}
	
	@RequestMapping(value="/searchsuppliersite",  method = {RequestMethod.POST,RequestMethod.GET})
	public String getSupplierSite(ModelMap model, SearchsuppliersForm searchForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		Connection conn;
		HttpSession session=request.getSession();
		String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		String msg="";
		conn=new Connectionc().getConnection();
		String[]supplierdtls=null;
		ArrayList supplier=new ArrayList<>();
		try {
			
			if(flag.equals("search")) {
				String supplierid=request.getParameter("supplierid");
				
				String suppliersiteName=request.getParameter("suppliersiteName");
				String query=bundle.getString("getsuppliersite");
				query=query+" and upper(vendor_site_code) like nvl(upper('%"+suppliersiteName+"%'),uppeR(vendor_site_code)) ";
				ps=conn.prepareStatement(query);
				System.out.println(query);
				ps.setString(1, supplierid);
				//ps.setString(2, suppliersiteName);
				
				
				rs=ps.executeQuery();
				
				while(rs.next()) {
					searchForm=new SearchsuppliersForm();
					searchForm.setSiteId(rs.getString("VENDOR_SITE_ID")!=null?rs.getString("VENDOR_SITE_ID"):"-");
					searchForm.setSitecode(rs.getString("VENDOR_SITE_CODE")!=null?rs.getString("VENDOR_SITE_CODE"):"-");
					searchForm.setAddress1(rs.getString("ADDRESS_LINE1")!=null?rs.getString("ADDRESS_LINE1"):"-");
					searchForm.setAddress2(rs.getString("ADDRESS_LINE2")!=null?rs.getString("ADDRESS_LINE2"):"");
					searchForm.setCity(rs.getString("CITY")!=null?rs.getString("CITY"):"");
					searchForm.setState(rs.getString("STATE")!=null?rs.getString("STATE"):"");
					searchForm.setOrgId(rs.getString("ORG_ID")!=null?rs.getString("ORG_ID"):"");
					
					supplier.add(searchForm);		
					
				}
				request.setAttribute("suppliersite", supplier);
				request.setAttribute("supplierSize", supplier.size());
				request.setAttribute("suppliersiteName", suppliersiteName);
				request.setAttribute("supplierid", supplierid);
			}else {
				String supplierid=request.getParameter("supplierid");
				System.out.println(supplierid);
				request.setAttribute("supplierid", supplierid);
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		return "searchsupplierssites";
	}
}
