package invoiceCreation;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import commonController.Connectionc;
import invoiceForms.SaveNewInvoiceForm;
import invoiceForms.UploadFileForm;

@Controller
public class EditInvoiceController {

	
@RequestMapping(value="/editinvoice",  method = {RequestMethod.POST,RequestMethod.GET} )
public String editInvoice(ModelMap model, SaveNewInvoiceForm saveInvoiceForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
{

	Connection conn;
	HttpSession session=request.getSession();
	String userName=(String)session.getAttribute("userName");
	String role=(String)session.getAttribute("role");
	String loginID=(String)session.getAttribute("loginID");
	String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
	String forward="";
	ResultSet rs=null;
	ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
	PreparedStatement ps=null;
	conn=new Connectionc().getConnection();
	try {
		
		String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
		request.setAttribute("msg",msg);
	if(flag.equals("viewInv")){	
	
		forward="editUserInv";
		
		ArrayList invoicehdrs=new ArrayList();
		String[] invdtls=null;
		String afpno=request.getParameter("afpno");
		ArrayList invoicelines=new ArrayList();
		String[] invlinesdtls=null;	
		ArrayList yearList=new ArrayList();
		String[] finYears=null;
		ArrayList descList=new ArrayList();
		String[] description=null;
		ArrayList productList=new ArrayList();
		String[] product=null;
		ArrayList departmentList=new ArrayList();
		String[] department=null;
		ArrayList filelines=new ArrayList();
		String[] filedtls=null;
		ArrayList CurrencyList=new ArrayList();
		String[] currency=null;
		String[] invtype=null;
		ArrayList InvoiceList=new ArrayList();
		String[] location=null;
		ArrayList LocationList=new ArrayList();
		String[] taxtype=null;
		ArrayList TaxTypeList=new ArrayList();
		
		String invHeaderQry = bundle.getString("getInvHeader");
		String invLinesQry = bundle.getString("getsubmittedInvLines");
		String getFileDetails= bundle.getString("getInvUploadedFiles");
	
	ps=conn.prepareStatement(invHeaderQry);
	System.out.println(invHeaderQry);
	ps.setString(1, afpno);
	//ps.setString(1, "1/27-AUG-19");
	rs=ps.executeQuery();
	
	while(rs.next()) {
		invdtls=new String[23];
		invdtls[0]=rs.getString(1)!=null?rs.getString(1):"";		//AfpNo
		invdtls[1]=rs.getString(2)!=null?rs.getString(2):"";		//InvoiceNo
		invdtls[2]=rs.getString(3)!=null?rs.getString(3):"";		//SupplierNO
		invdtls[3]=rs.getString(4)!=null?rs.getString(4):"";		//supplierName
		invdtls[4]=rs.getString(5)!=null?rs.getString(5):"";		//site Code
		invdtls[5]=rs.getString(6)!=null?rs.getString(6):"";		//site Id
		invdtls[6]=rs.getString(7)!=null?rs.getString(7):"";		//gstno
		invdtls[7]=rs.getString(8)!=null?rs.getString(8):"";		//totalInvAmt
		invdtls[8]=rs.getString(9)!=null?rs.getString(9):"";		//remarks
		invdtls[9]=rs.getString(10)!=null?rs.getString(10):"";		//invStatus
		invdtls[10]=rs.getString(11)!=null?rs.getString(11):"";		//status Code
		invdtls[11]=rs.getString(12)!=null?rs.getString(12):"";		//approverRemarks
		invdtls[12]=rs.getString(13)!=null?rs.getString(13):"";		//aprrover date
		invdtls[13]=rs.getString(14)!=null?rs.getString(14):"";		//finance remarks
		invdtls[14]=rs.getString(15)!=null?rs.getString(15):"";		//finance Date
		invdtls[15]=rs.getString(16)!=null?rs.getString(16):"";		//Invoice Date
		invdtls[16]=rs.getString(17)!=null?rs.getString(17):"";		//EXP From dt
		invdtls[17]=rs.getString(18)!=null?rs.getString(18):"";		//EXP to dt
		invdtls[18]=rs.getString(19)!=null?rs.getString(19):"";		//Financial year
		invdtls[19]=rs.getString(20)!=null?rs.getString(20):"";		//Currency
		invdtls[20]=rs.getString(21)!=null?rs.getString(21):"";		//inv type
		invdtls[21]=rs.getString(22)!=null?rs.getString(22):"";		//Prepay Amt
		invdtls[22]=rs.getString(23)!=null?rs.getString(23):"";		//Deduction Amt
		
		invoicehdrs.add(invdtls);
	}	
	request.setAttribute("invoicehdrs", invoicehdrs);
	request.setAttribute("invoicehdrsSize", invoicehdrs.size());
	
	rs=null;	ps=null;
	
	ps=conn.prepareStatement(invLinesQry);
	System.out.println(invLinesQry);
	ps.setString(1, afpno);
	//ps.setString(1, "1/27-AUG-19");
	rs=ps.executeQuery();
	
	while(rs.next()) {
		invlinesdtls=new String[17];
		invlinesdtls[0]=rs.getString(1);	//line Id
		invlinesdtls[1]=rs.getString(2);	//HSN
		invlinesdtls[2]=rs.getString(3);	//sec
		invlinesdtls[3]=rs.getString(4);	//nature of Exp
		invlinesdtls[4]=rs.getString(5);	//basic
		invlinesdtls[5]=rs.getString(6);	//gross
		invlinesdtls[6]=rs.getString(7);	//tds
		//invlinesdtls[7]=rs.getString(8);	//advance
		//invlinesdtls[8]=rs.getString(9);	//other
		invlinesdtls[7]=rs.getString(16);	//line location
		invlinesdtls[8]=rs.getString(17);	//tax type
		invlinesdtls[9]=rs.getString(10);	//total_amt
		invlinesdtls[10]=rs.getString(11);	//department
		invlinesdtls[11]=rs.getString(12);	//product
		invlinesdtls[12]=rs.getString(13);	//cgst
		invlinesdtls[13]=rs.getString(14);	//sgst
		invlinesdtls[14]=rs.getString(15);	//igst
		invlinesdtls[15]=rs.getString(18);	//text descr
		invlinesdtls[16]=rs.getString(19);	//inv No
		
		invoicelines.add(invlinesdtls);
	}	
	
	
	String query=bundle.getString("getfinancialYears");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		finYears=new String[1];
		finYears[0]=rs.getString(1);
		
		yearList.add(finYears);
	}		
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getLineDesc");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		description=new String[2];
		description[0]=rs.getString(1);
		description[1]=rs.getString(2);
		
		descList.add(description);
	}		
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getProduct");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		product=new String[2];
		product[0]=rs.getString(1);
		product[1]=rs.getString(2);
		
		productList.add(product);
	}	
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getDepartment");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		department=new String[2];
		department[0]=rs.getString(1);
		department[1]=rs.getString(2);
		
		departmentList.add(department);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	ps=conn.prepareStatement(getFileDetails);
	System.out.println(getFileDetails);
	ps.setString(1, afpno);
	rs=ps.executeQuery();
	
	while(rs.next()) {
		filedtls=new String[2];
		filedtls[0]=rs.getString(1);
		filedtls[1]=rs.getString(2);
		
		filelines.add(filedtls);
	}	
	
	
	query=bundle.getString("getCurrency");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		currency=new String[1];
		currency[0]=rs.getString(1);
				
		CurrencyList.add(currency);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getinvoiceType");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		invtype=new String[1];
		invtype[0]=rs.getString(1);
				
		InvoiceList.add(invtype);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query="select LOOKUP_CODE, DESCRIPTION STATE_CODE,TAG  from apps.fnd_lookup_VALUES  where lookup_type = 'AFP_STATE_CODE'  AND ENABLED_FLAG = 'Y'  AND END_DATE_ACTIVE IS NULL";
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		location=new String[3];
		location[0]=rs.getString(1);
		location[1]=rs.getString(2);
		location[2]=rs.getString(3);
				
		LocationList.add(location);
	}
	
	if(rs!=null) {rs=null;}
	if(ps!=null) {ps=null;}
	if(query!=null) {query=null;}
	
	query=bundle.getString("getTaxtype");
	ps=conn.prepareStatement(query);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		taxtype=new String[2];
		taxtype[0]=rs.getString(1);
		taxtype[1]=rs.getString(2);
				
		TaxTypeList.add(taxtype);
	}
	request.setAttribute("yearList", yearList);
	request.setAttribute("descList", descList);
	request.setAttribute("productList", productList);
	request.setAttribute("departmentList", departmentList);
	request.setAttribute("CurrencyList",CurrencyList);
	request.setAttribute("InvoiceList",InvoiceList);
	request.setAttribute("LocationList",LocationList);
	request.setAttribute("TaxTypeList",TaxTypeList);
			
	
	request.setAttribute("invoicelines", invoicelines);	
	request.setAttribute("invoicelinesSize", invoicelines.size());	
	request.setAttribute("afpno",afpno);
	request.setAttribute("filelines", filelines);
	request.setAttribute("filelinesSize", filelines.size());
	
	
}else if(flag.equals("search")){
	forward="viewnewInvoice";
	
	ArrayList viewinvoicehdrs=new ArrayList();
	String[] invdtls=null;
	String afpno=request.getParameter("afpno")!=null?request.getParameter("afpno"):"";
	String invoiceno=request.getParameter("invoiceno")!=null?request.getParameter("invoiceno"):"";
	String viewinvHeaderQry = bundle.getString("viewinvheader");
	System.out.println();
	
	if(role.equals("2")) {		
		viewinvHeaderQry=viewinvHeaderQry+" and mstr.submitted_by=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(voucher_number)like nvl(upper('%"+afpno+"%'),upper(voucher_number)) order by afpno desc";
			ps=conn.prepareStatement(viewinvHeaderQry);
		
			ps.setString(1, loginID);
	}
	else if(role.equals("3")) {		
		viewinvHeaderQry=viewinvHeaderQry+" and mstr.attribute1=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(voucher_number)like nvl(upper('%"+afpno+"%'),upper(voucher_number)) order by afpno desc";
		ps=conn.prepareStatement(viewinvHeaderQry);
		
		ps.setString(1, loginID);
		}
	else {		
		viewinvHeaderQry=viewinvHeaderQry+" and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(voucher_number)like nvl(upper('%"+afpno+"%'),upper(voucher_number)) order by afpno desc";
		ps=conn.prepareStatement(viewinvHeaderQry);
		
		}

	System.out.println(viewinvHeaderQry);

rs=ps.executeQuery();

while(rs.next()) {
	invdtls=new String[5];
	invdtls[0]=rs.getString(1);
	invdtls[1]=rs.getString(2);
	invdtls[2]=rs.getString(3);
	invdtls[3]=rs.getString(4);
	invdtls[4]=rs.getString(5);
	
	
	viewinvoicehdrs.add(invdtls);
}		
request.setAttribute("invoicehdrs", viewinvoicehdrs);
request.setAttribute("invoicehdrsSize", viewinvoicehdrs.size());
}

else {
	forward="viewnewInvoice";
	System.out.println("In Search Invoice");
}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return forward;
}

@RequestMapping(value="/submitForApprovalInv",  method = {RequestMethod.POST,RequestMethod.GET} )
public String submitForApprovalInv(@ModelAttribute UploadFileForm filef,ModelMap model, SaveNewInvoiceForm saveInvoiceForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
{

	Connection conn;
	HttpSession session=request.getSession();
	String userName=(String)session.getAttribute("userName");
	String role=(String)session.getAttribute("role");
	String loginID=(String)session.getAttribute("loginID");
	String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
	String forward="";
	ResultSet rs=null;
	ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
	PreparedStatement ps=null;
	conn=new Connectionc().getConnection();
	String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
	try {
		
		List<MultipartFile> files = filef.getInvFile();
    	ArrayList fileNames = new ArrayList();
        
    //&& ( (!(files.get(0).isEmpty())) || (!(files.get(1).isEmpty())) || (!(files.get(2).isEmpty())) )   
        
        if (null != files && files.size() > 0 )
        {
            for (MultipartFile multipartFile : files) {
 
                String fileName = multipartFile.getOriginalFilename();
                //if(!("".equals(fileName))){
                fileNames.add(fileName);
                
              //  File imageFile = new File(context.getRealPath("") + File.separator + "uploadimage" + File.separator, fileName);
                File imageFile = new File(System.getProperty("user.home") + "/Desktop/uploadimage/", fileName);
                System.out.println(imageFile);
                if(!(imageFile.exists())) {
                	boolean a=imageFile.mkdir();
                	if(a) {
                 	System.out.println(a);
                	}else {
                		System.out.println("Fail");
                	}
                }
                try
                {
               
                    multipartFile.transferTo(imageFile);
                } catch (IOException e)
                {
                   // e.printStackTrace();
                }
              // } 
            }
        }
    	
        System.out.println(Arrays.toString(fileNames.toArray()));
        System.out.println(fileNames.size());
		
		
	String afpno=request.getParameter("apfno")!=null?request.getParameter("apfno"):"";
	
	if (null != files && fileNames.size() > 0)
    {
	for(int i=1;i<=fileNames.size();i++) {
	 String query="update xxbaf_uploaded_file set FILE_NAME=?,UPLOADED_DT=sysdate,UPLAODED_BY=? where afp_no=? and file_seq=?";
	 ps=conn.prepareStatement(query);
	 if(!("".equals((String)fileNames.get(i-1)))) {
		 ps.setString(1, (String) fileNames.get(i-1)!=null?(String) fileNames.get(i-1):"");
		 ps.setString(2, loginID);
		 ps.setString(3, afpno);
		 ps.setInt(4, i);
		 
		 
		 ps.executeUpdate();	 
	 }	 
	 
	} 
	
    }
	
	String query="update XXBAF_INVOICE_MSTR set status='P' where afpno=?";
	
		ps=conn.prepareStatement(query);
		ps.setString(1, afpno);
	 
		int a=ps.executeUpdate();
if(a==1) {
	msg="Invoice Submitted For Approval";
	forward="redirect:/viewnewinvoice?msg="+msg+"&flag=viewInv&afpno="+afpno;
}else {
	forward="redirect:/viewnewinvoice?msg="+msg+"&flag=viewInv&afpno="+afpno;
	msg="Some Error Occurred While Submitting";
}

request.setAttribute("msg",msg);
	}catch(Exception e) {
		msg="Some Error Occurred";
		request.setAttribute("msg",msg);
		e.printStackTrace();
	}
	return forward;
}


}
