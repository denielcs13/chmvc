package invoiceCreation;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import invoiceForms.SaveNewInvoiceForm;
import invoiceForms.SearchsuppliersForm;

@Controller
public class ViewNewInvController {

	@RequestMapping(value="/viewnewinvoice",  method = {RequestMethod.POST,RequestMethod.GET}) 
    public String execute(ModelMap model, SaveNewInvoiceForm saveInvoiceForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
	
		Connection conn;
		HttpSession session=request.getSession();
		String userName=(String)session.getAttribute("userName");
		String role=(String)session.getAttribute("role");
		String loginID=(String)session.getAttribute("loginID");
		String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
		String forward="";
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		conn=new Connectionc().getConnection();
		try {
			String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
			request.setAttribute("msg",msg);
		if(flag.equals("viewInv")){	
		
			if(msg.contains("successfully")) {
				forward="viewnewsubmitInv";
			}else {
			forward="viewsubmittedinvoice";
			}
			ArrayList invoicehdrs=new ArrayList();
			String[] invdtls=null;
			String afpno=request.getParameter("afpno");
			ArrayList invoicelines=new ArrayList();
			String[] invlinesdtls=null;
			ArrayList filelines=new ArrayList();
			String[] filedtls=null;
			
			String invHeaderQry = bundle.getString("getInvHeader");
			String invLinesQry = bundle.getString("getsubmittedInvLines");
			String getFileDetails= bundle.getString("getInvUploadedFiles");
		
		ps=conn.prepareStatement(invHeaderQry);
		System.out.println(invHeaderQry);
		ps.setString(1, afpno);
		//ps.setString(1, "1/27-AUG-19");
		rs=ps.executeQuery();
		
		while(rs.next()) {
			invdtls=new String[23];
			invdtls[0]=rs.getString(1)!=null?rs.getString(1):"";		//AfpNo
			invdtls[1]=rs.getString(2)!=null?rs.getString(2):"";		//InvoiceNo
			invdtls[2]=rs.getString(3)!=null?rs.getString(3):"";		//SupplierNO
			invdtls[3]=rs.getString(4)!=null?rs.getString(4):"";		//supplierName
			invdtls[4]=rs.getString(5)!=null?rs.getString(5):"";		//site Code
			invdtls[5]=rs.getString(6)!=null?rs.getString(6):"";		//site Id
			invdtls[6]=rs.getString(7)!=null?rs.getString(7):"";		//gstno
			invdtls[7]=rs.getString(8)!=null?rs.getString(8):"";		//totalInvAmt
			invdtls[8]=rs.getString(9)!=null?rs.getString(9):"";		//remarks
			invdtls[9]=rs.getString(10)!=null?rs.getString(10):"";		//invStatus
			invdtls[10]=rs.getString(11)!=null?rs.getString(11):"";		//status Code
			invdtls[11]=rs.getString(12)!=null?rs.getString(12):"";		//approverRemarks
			invdtls[12]=rs.getString(13)!=null?rs.getString(13):"";		//aprrover date
			invdtls[13]=rs.getString(14)!=null?rs.getString(14):"";		//finance remarks
			invdtls[14]=rs.getString(15)!=null?rs.getString(15):"";		//finance Date
			invdtls[15]=rs.getString(16)!=null?rs.getString(16):"";		//Invoice Date
			invdtls[16]=rs.getString(17)!=null?rs.getString(17):"";		//EXP From dt
			invdtls[17]=rs.getString(18)!=null?rs.getString(18):"";		//EXP to dt
			invdtls[18]=rs.getString(19)!=null?rs.getString(19):"";		//Financial year
			invdtls[19]=rs.getString(20)!=null?rs.getString(20):"";		//Currency
			invdtls[20]=rs.getString(21)!=null?rs.getString(21):"";		//inv type
			invdtls[21]=rs.getString(22)!=null?rs.getString(22):"";		//Prepay Amt
			invdtls[22]=rs.getString(23)!=null?rs.getString(23):"";		//Deduction Amt
			
			invoicehdrs.add(invdtls);
		}		
		request.setAttribute("invoicehdrs", invoicehdrs);
		request.setAttribute("invoicehdrsSize", invoicehdrs.size());
		
		rs=null;	ps=null;
		
		ps=conn.prepareStatement(invLinesQry);
		System.out.println(invLinesQry);
		ps.setString(1, afpno);
		//ps.setString(1, "1/27-AUG-19");
		rs=ps.executeQuery();
		
		while(rs.next()) {
			invlinesdtls=new String[17];
			invlinesdtls[0]=rs.getString(1);	//line Id
			invlinesdtls[1]=rs.getString(2);	//HSN
			invlinesdtls[2]=rs.getString(3);	//sec
			invlinesdtls[3]=rs.getString(4);	//nature of Exp
			invlinesdtls[4]=rs.getString(5);	//basic
			invlinesdtls[5]=rs.getString(6);	//gross
			invlinesdtls[6]=rs.getString(7);	//tds
			//invlinesdtls[7]=rs.getString(8);	//advance
			//invlinesdtls[8]=rs.getString(9);	//other
			invlinesdtls[7]=rs.getString(16);	//line location
			invlinesdtls[8]=rs.getString(17);	//tax type
			invlinesdtls[9]=rs.getString(10);	//total_amt
			invlinesdtls[10]=rs.getString(11);	//department
			invlinesdtls[11]=rs.getString(12);	//product
			invlinesdtls[12]=rs.getString(13);	//cgst
			invlinesdtls[13]=rs.getString(14);	//sgst
			invlinesdtls[14]=rs.getString(15);	//igst
			invlinesdtls[15]=rs.getString(18);	//text descr
			invlinesdtls[16]=rs.getString(19);	//inv No
			
			invoicelines.add(invlinesdtls);
		}	
		
		rs=null;	ps=null;
		
		ps=conn.prepareStatement(getFileDetails);
		System.out.println(getFileDetails);
		ps.setString(1, afpno);
		rs=ps.executeQuery();
		
		while(rs.next()) {
			filedtls=new String[3];
			filedtls[0]=rs.getString(1);
			filedtls[1]=rs.getString(2)!=null?rs.getString(2):"";
			filedtls[2]=rs.getString(3);
			System.out.println(filedtls[2]);
			filelines.add(filedtls);
		}	
		
		request.setAttribute("invoicelines", invoicelines);		
		request.setAttribute("afpno",afpno);
		request.setAttribute("filelines", filelines);
		request.setAttribute("filelinesSize", filelines.size());
		
		
	}else if(flag.equals("search")){
		forward="viewnewInvoice";
		
		ArrayList viewinvoicehdrs=new ArrayList();
		String[] invdtls=null;
		String afpno=request.getParameter("afpno")!=null?request.getParameter("afpno"):"";
		String invoiceno=request.getParameter("invoiceno")!=null?request.getParameter("invoiceno"):"";
		//String viewinvHeaderQry = bundle.getString("viewinvheader");
		String viewinvHeaderQry = bundle.getString("viewExpinvheader");
		String queryPart=" AND exp.submitted_by = '"+loginID+"' and EXP.expno = nvl('"+afpno+"',EXP.expno) GROUP BY expno,exp.SUBMITTED_BY,exp.expense_category,exp.status,st.name ";
		//System.out.println("part query testing: "+queryPart);
		if(role.equals("2")) {		
			//viewinvHeaderQry=viewinvHeaderQry+" and mstr.submitted_by=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(afpno)like nvl(upper('%"+afpno+"%'),upper(afpno)) union ";
			viewinvHeaderQry=viewinvHeaderQry+" and mstr.submitted_by=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and mstr.afpno = NVL('"+afpno+"', mstr.afpno) union ";
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("expInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("entertainInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("foodExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("localConvExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("miscllExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("interNExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("combineExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			
			ps=conn.prepareStatement(viewinvHeaderQry);
			
				ps.setString(1, loginID);
		}
		else if(role.equals("3")) {		
			viewinvHeaderQry=viewinvHeaderQry+" and mstr.submitted_by=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and mstr.afpno=nvl('"+afpno+"',mstr.afpno) union ";
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("expInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("entertainInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("foodExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("localConvExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("miscllExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("interNExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("combineExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			
			ps=conn.prepareStatement(viewinvHeaderQry);
			
			ps.setString(1, loginID);
			}
		else {		
			//viewinvHeaderQry=viewinvHeaderQry+" and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and uppeR(afpno)like nvl(upper('%"+afpno+"%'),upper(afpno)) union ";
			viewinvHeaderQry=viewinvHeaderQry+" and mstr.submitted_by=? and upper(invoice_no) like nvl(upper('%"+invoiceno+"%'),upper(invoice_no)) and mstr.afpno=nvl('"+afpno+"',mstr.afpno) union ";
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("expInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("entertainInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("foodExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("localConvExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("miscllExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("interNExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			viewinvHeaderQry=viewinvHeaderQry+bundle.getString("combineExpInvQuery");
			viewinvHeaderQry=viewinvHeaderQry+queryPart;
			
			ps=conn.prepareStatement(viewinvHeaderQry);
			ps.setString(1, loginID);
			
			}
	
		System.out.println(viewinvHeaderQry);
	
	rs=ps.executeQuery();
	
	while(rs.next()) {
		invdtls=new String[11];
		invdtls[0]=rs.getString(1);
		invdtls[1]=rs.getString(2);
		invdtls[2]=rs.getString(3);
		invdtls[3]=rs.getString(4);
		invdtls[4]=rs.getString(5);
		invdtls[5]=rs.getString(6);
		invdtls[6]=rs.getString(7);
		invdtls[7]=rs.getString(8);
		invdtls[8]=rs.getString(9);
		invdtls[9]=rs.getString(10);
		invdtls[10]=rs.getString(11);
		viewinvoicehdrs.add(invdtls);
	}		
	request.setAttribute("invoicehdrs", viewinvoicehdrs);
	request.setAttribute("invoicehdrsSize", viewinvoicehdrs.size());
	}
	
	else {
		String[] invStatus=null;
		ArrayList invStatusList=new ArrayList();
		String[] suppliers=null;
		ArrayList suppliersList=new ArrayList();
		String[] product=null;
		ArrayList productList=new ArrayList();
		String[] department=null;
		ArrayList departmentList=new ArrayList();
		String[] natrueOfExpe=null;
		ArrayList natrueOfExpeList=new ArrayList();
		
		
		String query=bundle.getString("getInvoiceStatus");
		ps=conn.prepareStatement(query);
		
		rs=ps.executeQuery();
		
		while(rs.next()) {
			invStatus=new String[2];
			invStatus[0]=rs.getString(1);
			invStatus[1]=rs.getString(2);
			
			invStatusList.add(invStatus);
		}
		
		query=bundle.getString("getsuppliers");
		ps=conn.prepareStatement(query);
		System.out.println(query);
				
		rs=ps.executeQuery();
		
		while(rs.next()) {
			suppliers=new String[4];
			suppliers[0]=(rs.getString("VENDOR_ID")!=null?rs.getString("VENDOR_ID"):"-");
			suppliers[1]=(rs.getString("VENDOR_NAME")!=null?rs.getString("VENDOR_NAME"):"-");
			suppliers[2]=(rs.getString("VENDOR_NUMBER")!=null?rs.getString("VENDOR_NUMBER"):"-");
			suppliers[3]=(rs.getString("VENDOR_TYPE_LOOKUP_CODE")!=null?rs.getString("VENDOR_TYPE_LOOKUP_CODE"):"");
			
			suppliersList.add(suppliers);		
			
		}
		
		query=bundle.getString("getProduct");
		ps=conn.prepareStatement(query);
		System.out.println(query);
				
		rs=ps.executeQuery();
		
		while(rs.next()) {
			product=new String[2];
			product[0]=(rs.getString(1)!=null?rs.getString(1):"-");
			product[1]=(rs.getString(2)!=null?rs.getString(2):"-");
						
			productList.add(product);		
			
		}
		
		query=bundle.getString("getLineDesc");
		ps=conn.prepareStatement(query);
		System.out.println(query);
				
		rs=ps.executeQuery();
		
		while(rs.next()) {
			natrueOfExpe=new String[2];
			natrueOfExpe[0]=(rs.getString(1)!=null?rs.getString(1):"-");
			natrueOfExpe[1]=(rs.getString(2)!=null?rs.getString(2):"-");
						
			natrueOfExpeList.add(natrueOfExpe);		
			
		}
		
		query=bundle.getString("getDepartment");
		ps=conn.prepareStatement(query);
		System.out.println(query);
				
		rs=ps.executeQuery();
		
		while(rs.next()) {
			department=new String[2];
			department[0]=(rs.getString(1)!=null?rs.getString(1):"-");
			department[1]=(rs.getString(2)!=null?rs.getString(2):"-");
						
			departmentList.add(department);		
			
		}
		
		request.setAttribute("suppliersList", suppliersList);
		request.setAttribute("supplierSize", suppliersList.size());
		request.setAttribute("invStatusList", invStatusList);
		request.setAttribute("natrueOfExpeList", natrueOfExpeList);
		request.setAttribute("departmentList", departmentList);
		request.setAttribute("productList", productList);
		
		forward="viewnewInvoice";
		System.out.println("In Search Invoice");
	}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return forward;
    }
}
