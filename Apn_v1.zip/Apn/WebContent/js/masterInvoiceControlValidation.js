function matchHotelMasterData(val){
	
		var ido=val.id;
		ido=ido.substring(11);
		//if(ido=='' || ido==undefined) ido=ido.substring(9);
		//alert(val.value);
		//if(val.value=='CONVEYNACE_AMOUNT'){
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 
		 var expCat=document.masterInvExp.expCat.value;
		 var expTypeSelect = document.getElementById("att1se"+ido);
		 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
		 var cityClass=document.getElementById("cityClass"+ido).value;
		 var travelDt=document.getElementById("dotravel"+ido).value;
		 var byPassVla=document.getElementById("byPass"+ido).value;
		 
		 if(expType!='' && cityClass!='' && travelDt!='' && byPassVla=='N'){		 
		    var url="getHotelChargesContl?expCat="+expCat+"&id="+ido+"&expType="+expType+"&cityClass="+cityClass+"&travelDt="+travelDt;	    
		    xmlHttp.onreadystatechange=stateChangedgetHotelAmt
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		 }else{
			 getTotal();
		 }
	}	 
		function stateChangedgetHotelAmt() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
		           
		            var amt=matchAmt[0].getElementsByTagName("Amount");
		           	var attid=matchAmt[0].getElementsByTagName("id");
		            	
		           	var attidval=attid[0].firstChild.data;
		           	amt=amt[0].firstChild.data;
		           //	alert('id-'+attidval+'=amt='+amt);
		            var AmtEnter=document.getElementById('hotelchramt'+attidval).value;
		            if(parseInt(AmtEnter)>parseInt(amt)){
		            	alert("Hotel Charges Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+amt);
		            	document.getElementById('hotelchramt'+attidval).value='';
		            	document.getElementById('total'+attidval).value='';
		            	document.getElementById('gtotal').value='';		            	
		            	return false;
		            }
		             
		    }
		    
	}

function matchFoodMasterData(val){
			
			var ido=val.id;
			ido=ido.substring(9);
			if(ido=='' || ido==undefined) ido=val.id.substring(6);
			if(ido=='' || ido==undefined) ido=val.id.substring(5);
			//alert(val.value);
			//if(val.value=='CONVEYNACE_AMOUNT'){
			
			 xmlHttp=GetXmlHttpObject()
			    if (xmlHttp==null)
			    {
			      alert ("Browser does not support HTTP Request");
			      return;
			    }
			 
			 var expCat=document.masterInvExp.expCat.value;
			 var expTypeSelect = document.getElementById("att1se"+ido);
			 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
			 var cityClass=document.getElementById("cityClass"+ido).value;
			 var travelDt=document.getElementById("dotravel"+ido).value;
			 var byPassVla=document.getElementById("byPass"+ido).value;
			 
			 if(expType!='' && cityClass!='' && travelDt!='' && byPassVla=='N'){		 
			    var url="getFoodChargesContl?expCat="+expCat+"&id="+ido+"&expType="+expType+"&cityClass="+cityClass+"&travelDt="+travelDt;	    
			    xmlHttp.onreadystatechange=stateChangedgetFoodAmt
			    xmlHttp.open("GET",url,true);
			    xmlHttp.send(null);
			 }else{
				 getTotal();
			 }
		}	 
			function stateChangedgetFoodAmt() 
			{ 
				
			    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
			    { 
			    	 var xmlDoc = xmlHttp.responseXML.documentElement;
			           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
			           var brfamt=0;
			           var lnchamt=0;
			           var dnnramt=0;
			           
			            for (i = 0; i < matchAmt.length ; i++)
			            {
			            var attid=matchAmt[i].getElementsByTagName("id");
			            var attidval=attid[0].firstChild.data;
			            var attbVal=matchAmt[i].getElementsByTagName("attb");
			            attbVal=attbVal[0].firstChild.data;
			            if(attbVal=='BREAKFAST'){
			            	brfamt =matchAmt[i].getElementsByTagName("Amount");
			            	brfamt=brfamt[0].firstChild.data;
			            }
			            if(attbVal=='LUNCH'){
			             lnchamt=matchAmt[i].getElementsByTagName("Amount");
			             lnchamt=lnchamt[0].firstChild.data;
			            }
			            if(attbVal=='DINNER'){
			             dnnramt=matchAmt[i].getElementsByTagName("Amount");
			             dnnramt=dnnramt[0].firstChild.data;
			            }	
			           }
			           	//alert('brf='+brfamt+'lnch='+lnchamt+'dnr='+dnnramt);
			            var brfAmtEnter=document.getElementById('breakFast'+attidval).value;
			            var lncAmtEnter=document.getElementById('lunch'+attidval).value;
			            var dnrAmtEnter=document.getElementById('dinner'+attidval).value;
			            
			            if(parseInt(brfAmtEnter)>parseInt(brfamt)){
			            	alert("BreakFast Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+brfamt);
			            	document.getElementById('breakFast'+attidval).value='';
			            	document.getElementById('total'+attidval).value='';
			            	document.getElementById('gtotal').value='';		            	
			            	return false;
			            }else if(parseInt(lncAmtEnter)>parseInt(lnchamt)){
			            	alert("Lunch Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+lnchamt);
			            	document.getElementById('lunch'+attidval).value='';
			            	document.getElementById('total'+attidval).value='';
			            	document.getElementById('gtotal').value='';		            	
			            	return false;
			            }else if(parseInt(dnrAmtEnter)>parseInt(dnnramt)){
			            	alert("Dinner Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+dnnramt);
			            	document.getElementById('dinner'+attidval).value='';
			            	document.getElementById('total'+attidval).value='';
			            	document.getElementById('gtotal').value='';		            	
			            	return false;
			            }else{
			            	
			            }
			             
			    }
			    
		}
	
function matchConvMasterData(val){
				
				var ido=val.id;
				ido=ido.substring(7);
				if(ido=='' || ido==undefined)ido=val.substring(6);
				 xmlHttp=GetXmlHttpObject()
				    if (xmlHttp==null)
				    {
				      alert ("Browser does not support HTTP Request");
				      return;
				    }
				 
				 var expCat=document.masterInvExp.expCat.value;
				 var expTypeSelect = document.getElementById("att1se"+ido);
				 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
				 var transMode=document.getElementById("motrans"+ido).value;
				 var travelDt=document.getElementById("dotravel"+ido).value;
				 var byPassVla=document.getElementById("byPass"+ido).value;
				 
				 if(expType!='' && transMode!='' && travelDt!='' && byPassVla=='N' && transMode!='Metro'){
					 document.getElementById('convAmt'+ido).readOnly = true;
				    var url="getConvChargesContl?expCat="+expCat+"&id="+ido+"&expType="+expType+"&transMode="+transMode+"&travelDt="+travelDt;	    
				    xmlHttp.onreadystatechange=stateChangedgetConvAmt
				    xmlHttp.open("GET",url,true);
				    xmlHttp.send(null);
				 }if(transMode=='Metro'){
					 document.getElementById('convAmt'+ido).readOnly = false;
					 document.getElementById('rpk'+ido).value=0;
					 document.getElementById('totalkm'+ido).value=0;
					 document.getElementById('convAmt'+ido).value=0;
					 getTotal();
				 }else{
					 getTotal();
				 }
			}	 
				function stateChangedgetConvAmt() 
				{ 
					
					if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
				    { 
				    	 var xmlDoc = xmlHttp.responseXML.documentElement;
				           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
				           
				            var amt=matchAmt[0].getElementsByTagName("Amount");
				           	var attid=matchAmt[0].getElementsByTagName("id");
				            	
				           	var attidval=attid[0].firstChild.data;
				           	amt=amt[0].firstChild.data;
				           	//alert('id-'+attidval+'=amt='+amt);
				            var rpkEnter=document.getElementById('rpk'+attidval).value;
				            if(parseInt(rpkEnter)>parseInt(amt)){
				            	alert("Rate Per KM Cannot Be Greater Than Eligible KM as per policy at Row "+attidval+" Defined KM-"+amt);
				            	document.getElementById('rpk'+attidval).value=amt;
				           	getTotal();
				          }
				    }
				    
			}			

function matchFixedAllMasterData(val){
					
					var ido=val.id;
					ido=ido.substring(7);
					
					 xmlHttp=GetXmlHttpObject()
					    if (xmlHttp==null)
					    {
					      alert ("Browser does not support HTTP Request");
					      return;
					    }
					 
					 var expCat=document.masterInvExp.expCat.value;
					 var expTypeSelect = document.getElementById("att1se"+ido);
					 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
					 var transMode=document.getElementById("transMode"+ido).value;
					 var travelDt=document.getElementById("dotravel"+ido).value;
					 var byPassVla=document.getElementById("byPass"+ido).value;
					 
					 if(expType!='' && transMode!='' && travelDt!='' && byPassVla=='N'){		 
					    var url="getConvChargesContl?expCat="+expCat+"&id="+ido+"&expType="+expType+"&transMode="+transMode+"&travelDt="+travelDt;	    
					    xmlHttp.onreadystatechange=stateChangedgetFixAllAmt
					    xmlHttp.open("GET",url,true);
					    xmlHttp.send(null);
					 }else{
						 getTotal();
					 }
				}	 
					function stateChangedgetFixAllAmt() 
					{ 
						
						if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
					    { 
					    	 var xmlDoc = xmlHttp.responseXML.documentElement;
					           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
					           
					            var amt=matchAmt[0].getElementsByTagName("Amount");
					           	var attid=matchAmt[0].getElementsByTagName("id");
					            	
					           	var attidval=attid[0].firstChild.data;
					           	amt=amt[0].firstChild.data;
					           	//alert('id-'+attidval+'=amt='+amt);
					            var AmtEnter=document.getElementById('convAmt'+attidval).value;
					            if(parseInt(AmtEnter)>parseInt(amt)){
					            	alert("Conveyance Amount Cannot Be Greater Than Master Amount at Row"+attidval);
					            	document.getElementById('convAmt'+attidval).value='';
					            	document.getElementById('total'+attidval).value='';
					            	document.getElementById('gtotal').value='';		            	
					            	return false;
					            }
					             
					    }
					    
				}

function matchFoodExpMaster(val){
	
	var ido=val.id;
	ido=ido.substring(13);
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 
	 var expCat=document.masterInvExp.expCat.value;
	 var expTypeSelect = document.getElementById("att1Food"+ido);
	 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
	 var foodType=document.getElementById("typefoodexpFood"+ido).value;
	 var travelDt=document.getElementById("doeFood"+ido).value;
	 var byPassVla=document.getElementById("byPassFood"+ido).value;
	 
	 if(expType!='' && foodType!='' && travelDt!='' && byPassVla=='N' && (foodType=='Dinner' || foodType=='Lunch' || foodType=='Evening Snacks') ){		 
	    var url="getFoodExpContl?expCat="+expCat+"&id="+ido+"&expType="+expType+"&foodType="+foodType+"&travelDt="+travelDt;
	    xmlHttp.onreadystatechange=stateChangedgetFoodExpAmt
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	 }else{
		 getTotal();
	 }

	
}

function stateChangedgetFoodExpAmt() 
{ 
	
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
           
            var amt=matchAmt[0].getElementsByTagName("Amount");
           	var attid=matchAmt[0].getElementsByTagName("id");
            	
           	var attidval=attid[0].firstChild.data;
           	amt=amt[0].firstChild.data;
           	
           	var AmtEnter=document.getElementById('expamountFood'+attidval).value;
            if(parseInt(AmtEnter)>parseInt(amt)){
            	alert("Expense Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+amt);
            	document.getElementById('expamountFood'+attidval).value='';
            	document.getElementById('totalFood'+attidval).value='';
            	document.getElementById('gtotal').value='';		            	
            	return false;
            }else{
            	getTotal();
            }
    }
    
}	

function matchLocConvExpMaster(val){
	
	var ido=val.id;
	ido=ido.substring(14);
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 document.getElementById('ratePKlocalC'+ido).value='';
	 document.getElementById('totKMlocalC'+ido).value='';
	 document.getElementById('ParkTolllocalC'+ido).value='';
	 document.getElementById('ConvTotlocalC'+ido).value='';
	 document.getElementById('TotAmtlocalC'+ido).value='';
	 document.getElementById('gtotal').value='';
	 var expCat=document.masterInvExp.expCat.value;
	 var expTypeSelect = document.getElementById("att1localC"+ido);
	 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
	 var modTrans=document.getElementById("modeTranlocalC"+ido).value;
	 var travelDt=document.getElementById("dotlocalC"+ido).value;
	 var byPassVla=document.getElementById("byPasslocC"+ido).value;
	 
	 if(expType!='' && modTrans!='' && travelDt!='' && byPassVla=='N'){
		 if(modTrans!='Metro'){
			 document.getElementById('ConvTotlocalC'+ido).readOnly=true;
	    var url="getLocConvExpContl?expCat="+expCat+"&id="+ido+"&expType="+expType+"&modTrans="+modTrans+"&travelDt="+travelDt;
	    xmlHttp.onreadystatechange=stateChangedgetlocConvExpAmt
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
		 }else{
			 document.getElementById('ConvTotlocalC'+ido).readOnly=false;
		 }
	 }

	
}

function stateChangedgetlocConvExpAmt() 
{ 
	
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
           
            var amt=matchAmt[0].getElementsByTagName("Amount");
           	var attid=matchAmt[0].getElementsByTagName("id");
            	
           	var attidval=attid[0].firstChild.data;
           	amt=amt[0].firstChild.data;
           	
           	document.getElementById('ratePKlocalC'+attidval).value=amt;
           	getTotal();
           	
    }
    
}	

function getCombMatchLocl(val){
	
	var ido=val.id;
	ido=ido.substring(12);
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 
	 var expTypeSelect = document.getElementById("att1Comb"+ido);
	 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
	 
	 document.getElementById('ratePKComb'+ido).value='';
	 document.getElementById('totKMComb'+ido).value='';
	 document.getElementById('ParkTollComb'+ido).value='';
	 document.getElementById('expamountComb'+ido).value='';
	 document.getElementById('TotAmtComb'+ido).value='';
	 document.getElementById('gtotal').value='';
	 //var expCat=document.masterInvExp.expCat.value;
	
	 var modTrans=document.getElementById("modeTranComb"+ido).value;
	 var travelDt=document.getElementById("dotComb"+ido).value;
	 var byPassVla=document.getElementById("byPassComb"+ido).value;
	 
	 if(expType!='' && modTrans!='' && travelDt!='' && byPassVla=='N'){
		 if(modTrans!='Metro'){
			 document.getElementById('expamountComb'+ido).readOnly=true;
	    var url="getLocConvExpContl?expCat="+expType+"&id="+ido+"&expType="+expType+"&modTrans="+modTrans+"&travelDt="+travelDt;
	    xmlHttp.onreadystatechange=stateChangedgetCombConvExpAmt
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
		 }else{
			 document.getElementById('expamountComb'+ido).readOnly=false;
		 }
	 }

	
}

function stateChangedgetCombConvExpAmt() 
{ 
	
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
           
            var amt=matchAmt[0].getElementsByTagName("Amount");
           	var attid=matchAmt[0].getElementsByTagName("id");
            	
           	var attidval=attid[0].firstChild.data;
           	amt=amt[0].firstChild.data;
           	
           	document.getElementById('ratePKComb'+attidval).value=amt;
           	getTotal();
           	
    }
    
}

function getCombMatchFood(val){
	
	var ido=val.id;
	ido=ido.substring(13);
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 
	// var expCat=document.masterInvExp.expCat.value;
	 var expTypeSelect = document.getElementById("att1Comb"+ido);
	 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
	 var foodType=document.getElementById("typefoodexpComb"+ido).value;
	 var travelDt=document.getElementById("dotComb"+ido).value;
	 var byPassVla=document.getElementById("byPassComb"+ido).value;
	 
	 if(expType!='' && foodType!='' && travelDt!='' && byPassVla=='N' && (foodType=='Dinner' || foodType=='Lunch' || foodType=='Evening Snacks') ){		 
	    var url="getFoodExpContl?expCat="+expType+"&id="+ido+"&expType="+expType+"&foodType="+foodType+"&travelDt="+travelDt;
	    xmlHttp.onreadystatechange=stateChangedgetCombFoodExpAmt
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	 }else{
		 getTotal();
	 }

	
}

function stateChangedgetCombFoodExpAmt() 
{ 
	
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
           
            var amt=matchAmt[0].getElementsByTagName("Amount");
           	var attid=matchAmt[0].getElementsByTagName("id");
            	
           	var attidval=attid[0].firstChild.data;
           	amt=amt[0].firstChild.data;
           	
           	var AmtEnter=document.getElementById('expamountComb'+attidval).value;
            if(parseInt(AmtEnter)>parseInt(amt)){
            	alert("Expense Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+amt);
            	document.getElementById('expamountComb'+attidval).value='';
            	document.getElementById('TotAmtComb'+attidval).value='';
            	document.getElementById('gtotal').value='';		            	
            	return false;
            }else{
            	getTotal();
            }
    }
    
}

function getInterMatchFixed(val){
	
	var ido=val.id;
	ido=ido.substring(13);
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 
	 var expCat=document.masterInvExp.expCat.value;
	 var expTypeSelect = document.getElementById("att1seInterN"+ido);
	 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
	 var travelDt=document.getElementById("dotravelInterN"+ido).value;
	 var byPassVla=document.getElementById("byPassInterN"+ido).value;
	 var tripFor=document.getElementById("tripForInterN"+ido).value;
	 var scenerio=document.getElementById("sceneInterN"+ido).value;
	 var currency=document.getElementById("currNmInterN"+ido).value;
	 
	 if(expType!='' && currency!='' && travelDt!='' && byPassVla=='N' && tripFor!=='' && scenerio!='' &&(expType=='Fixed Allowance' || expType=='Hotel Charges') ){		 
	    var url="getInterExpContlFixed?expCat="+expCat+"&id="+ido+"&expType="+expType+"&travelDt="+travelDt+"&tripFor="+tripFor+"&scenerio="+scenerio+"&currency="+currency;
	    xmlHttp.onreadystatechange=stateChangedgetInterFixExpAmt
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	 }else{
		 getTotal();
	 }
	
}

function stateChangedgetInterFixExpAmt() 
{ 
	
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var matchAmt = xmlDoc.getElementsByTagName("matchAmt");
           
            var amt=matchAmt[0].getElementsByTagName("Amount");
           	var attid=matchAmt[0].getElementsByTagName("id");
            	
           	var attidval=attid[0].firstChild.data;
           	amt=amt[0].firstChild.data;
           	
           	var expTypeSelect = document.getElementById("att1seInterN"+attidval);
       	 var expType = expTypeSelect.options[expTypeSelect.selectedIndex].text;
       	 if(expType=='Fixed Allowance'){
           	var AmtEnter=document.getElementById('perDiemInterN'+attidval).value;
            if(parseInt(AmtEnter)>parseInt(amt)){
            	alert("Expense Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+amt);
            	document.getElementById('perDiemInterN'+attidval).value='';
            	document.getElementById('perDiemINRInterN'+attidval).value='';
            	document.getElementById('TotAmtInterN'+attidval).value='';
            	document.getElementById('gtotal').value='';		            	
            	return false;
            }else{
            	getTotal();
            }
       	 }else{
       		var AmtEnter=document.getElementById('hotlTaxInterN'+attidval).value;
            if(parseInt(AmtEnter)>parseInt(amt)){
            	alert("Expense Amount Cannot Be Greater Than Eligible Amount as per policy at Row "+attidval+" Amount-"+amt);
            	document.getElementById('hotlTaxInterN'+attidval).value='';
            	document.getElementById('hotelchrInterN'+attidval).value='';
            	document.getElementById('TotAmtInterN'+attidval).value='';
            	document.getElementById('gtotal').value='';		            	
            	return false;
            }else{
            	getTotal();
            } 
       		 
       		 
       	 } 
    }
    
}