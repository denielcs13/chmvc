/**
 * 
 */
// Ajax
function GetXmlHttpObject()
{
	    var xmlHttp=null;
	    try
	    {
	        // Firefox, Opera 8.0+, Safari
	        xmlHttp=new XMLHttpRequest();
	    }
	    catch (e)
	    {
	        // Internet Explorer
	        try
	        {
	            xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
	        }
	        catch (e)
	        {
	            xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
	        }
	    }
	    return xmlHttp;
}

var numb = '0123456789';
var lwr = 'abcdefghijklmnopqrstuvwxyz. ';
var upr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ. ';
var fnum = '0123456789.';
var flag = 0;

//To vaidate forms
function isValid(parm, val) {
	if (parm == "") {
		return false;
	}
	for (i = 0; i < parm.length; i++) {
		if (val.indexOf(parm.charAt(i), 0) == -1) {
			return false;
		}
	}
	return true;
}

// To validate number
function isNum(parm) {
	return isValid(parm, numb);
}

// To validate is lower
function isLower(parm) {
	return isValid(parm, lwr);
}

// To validate is upper
function isUpper(parm) {
	return isValid(parm, upr);
}

// To validate is alpha
function isAlpha(parm) {
	return isValid(parm, lwr + upr);
}

// To validate isAlpahaNumreic
function isAlphanum(parm) {
	return isValid(parm, lwr + upr + numb);
}

// To Validate Float
function isFloat(parm) {
	return isValid(parm, fnum);
}

function checkFloat(obj) {
	if (!isFloat(obj.value) && obj.value != '') {
		alert("Please enter only numbers.");
		obj.focus();
		return false;
	}
	var id = obj.id;
	if (id.substring(0, 9) == 'basicAmt') {
		if (obj.value == 0) {
			alert("Please enter value greater than zero.");
			obj.focus();
			return false;
		}
	}
	obj.value = roundNumber(obj.value, 2);
	return true;
}

function checkNumber(obj) {
	if (!isNum(obj.value) && obj.value != '') {
		obj.value='';
		alert("Please enter only numbers.");
		return false;
	}
	if (obj.value == '') {
		obj.value=0;
	}
}
function preventBack(){
	window.history.forward();
	}
setTimeout("preventBack()", 0);
window.onunload=function(){
	null
	};

function logout()  
	{

	 document.commonfile.action="logout";
	 document.commonfile.method="POST";
	 document.commonfile.submit();

	}
function home(){
	window.location = "welcome.jsp";
}

	function getSupplierName()
	{ 
	    var val=document.getElementById("supplierno").value;
	    xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request")
	      return
	    }
	    var url="getSupplierName?supplyId="+val;	    
	    xmlHttp.onreadystatechange=stateChangedgetSupplier 
	    xmlHttp.open("GET",url,false)
	    xmlHttp.send(null)
	}
	function stateChangedgetSupplier() 
	{ 
	    
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	        var xmlDoc = xmlHttp.responseXML.documentElement;
	           var supplier = xmlDoc.getElementsByTagName("supply");
	            for (i = 0; i < supplier.length ; i++)
	            {
	            	var optval=supplier[i].getElementsByTagName("supplierNm");
	            	document.getElementById("suppliernm").value=optval[0].firstChild.data;
	         
	            }
	       
	    }
	}

function getSupplierSites(){
	
	var val=document.getElementById("supplierno").value;
	document.getElementById("suppliersite").value="";
	document.getElementById("suppliersite").options.length=1;
    xmlHttp=GetXmlHttpObject()
    if (xmlHttp==null)
    {
      alert ("Browser does not support HTTP Request");
      return;
    }
    var url="getSupplierSites?supplyId="+val;	    
    xmlHttp.onreadystatechange=stateChangedgetSuppliersite 
    xmlHttp.open("GET",url,true)
    xmlHttp.send(null)
}
function stateChangedgetSuppliersite() 
{ 
    
    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
        var xmlDoc = xmlHttp.responseXML.documentElement;
           var supplier = xmlDoc.getElementsByTagName("supply");
          
            for (i = 0; i < supplier.length ; i++)
            {
            	var siteId=supplier[i].getElementsByTagName("siteId");
            	var siteName=supplier[i].getElementsByTagName("siteName");
            	
            	var optn = document.createElement("OPTION");
            	
            	var sitenm=siteName[0].firstChild.data;
            	var sitenew = sitenm.replace("amp", "&");
            	optn.text=sitenew;
            	optn.value = siteId[0].firstChild.data;
    			document.getElementById('suppliersite').options.add(optn);
               }
       
    }
}



function addRow(){
	//alert("A");
	var prashidCounter = document.createinv.prashidCounter.value;
	if (document.getElementById('description' + prashidCounter).value == 'select' || document.getElementById('product' + prashidCounter).value == 'select'
		|| document.getElementById('department' + prashidCounter).value == 'select' || document.getElementById('basicAmt' + prashidCounter).value == '' 
		|| document.getElementById('cgst' + prashidCounter).value == '' || document.getElementById('gross' + prashidCounter).value == '' 	
	)  {
		alert("Please fill the last row first.");
		return false;
	}
	var cgsttax=document.getElementById("cgst"+ prashidCounter).value;
	var igsttax=document.getElementById("igst"+ prashidCounter).value;
	
	if(parseInt(cgsttax)>0 && parseInt(igsttax)>0){
		alert("Tax Should be IGST or CGST/SGST");
		return false;
	}
	/*if(document.getElementById("basicAmt"+prashidCounter).value==0 || document.getElementById("basicAmt"+prashidCounter).value==''){
		alert("Basic Amount Should not be Zero");
		return false;		
	}
	if(document.getElementById("net"+prashidCounter).value==0 || document.getElementById("net"+prashidCounter).value==''){
		alert("Net Should not be Zero");
		return false;		
	}*/
	if (document.createinv.ch.length == undefined) {
		document.createinv.ch.disabled = false;
	}
	if (document.createinv.ch.length == 1) {
		document.createinv.ch[0].disabled = false;
	}
	prashidCounter = parseInt(prashidCounter) + 1;
	document.createinv.prashidCounter.value = prashidCounter;
	//alert(document.getElementById('innerTable').tBodies[0]);
	var tblBody = document.getElementById('innerTable').tBodies[0];
	var slrow = document.getElementById("thirdrowf");
	var extrarow=document.getElementById("trrow");
	
	var newline = slrow.cloneNode(false);
	
	var newline00 = slrow.cells[0].cloneNode(false);
	newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
			+ '" id="lno' + prashidCounter + '" size="1" name="lno" />';
	newline.appendChild(newline00);
	
	var newline01 = slrow.cells[1].cloneNode(false);
	newline01.innerHTML = '<input type="text"  value="" id="hsn' + prashidCounter + '" size="5" />';
	newline.appendChild(newline01);
	
	var newline02 = slrow.cells[2].cloneNode(false);
	newline02.innerHTML = '<input type="text"  value="" id="sec' + prashidCounter + '" size="5" />';
	newline.appendChild(newline02);
	
	var newline03 = slrow.cells[3].cloneNode(false);
	newline03.innerHTML = '<select name="department'+ prashidCounter + '" style="width: 98%" id="department'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
	var newdeptselect = newline03.getElementsByTagName('select');
	newdeptselect.id = 'department' + prashidCounter;
	newline.appendChild(newline03);
	
	var newline04 = slrow.cells[4].cloneNode(false);
	newline04.innerHTML = '<select name="product'+ prashidCounter + '" style="width: 98%" id="product'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
	var newproductselect = newline04.getElementsByTagName('select');
	newproductselect.id = 'product' + prashidCounter;
	newline.appendChild(newline04);
	
	var newline05 = slrow.cells[5].cloneNode(false);
	newline05.innerHTML = '<select name="description'+ prashidCounter + '" style="width: 98%" id="description'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
	var newdescselect = newline05.getElementsByTagName('select');
	newdescselect.id = 'description' + prashidCounter;
	newline.appendChild(newline05);
	
////Location
	var newline06 = slrow.cells[6].cloneNode(false);
	newline06.innerHTML = '<select name="location'+ prashidCounter + '" style="width: 98%" onchange="getCorrectTax(this)" id="location'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
	var newlocaselect = newline06.getElementsByTagName('select');
	newlocaselect.id = 'location' + prashidCounter;
	newline.appendChild(newline06);
	
	var newline07 = slrow.cells[7].cloneNode(false);
	newline07.innerHTML = '<input type="text" value="" id="txtdesc' + prashidCounter + '" />';
	newline.appendChild(newline07);

/////Tax type	
	var newline08 = slrow.cells[8].cloneNode(false);
	newline08.innerHTML = '<select name="taxtype'+ prashidCounter + '" id="taxtype'+ prashidCounter + '" onchange="gettaxValue(this,basicAmt'+ prashidCounter +'.value,taxx.value)" ><option value="select">--Select--</option></select>';
	var newtaxtypeselect = newline08.getElementsByTagName('select');
	newtaxtypeselect.id = 'taxtype' + prashidCounter;
	newline.appendChild(newline08);
	
	var newline09 = slrow.cells[9].cloneNode(false);
	newline09.innerHTML = '<input type="text" value="" id="basicAmt' + prashidCounter + '" size="5" onblur="checkFloat(this);gettaxValue1(taxtype'+ prashidCounter +'.value,this,taxx.value)""/>';
	newline.appendChild(newline09);
	
	var newline10 = slrow.cells[10].cloneNode(false);
	newline10.innerHTML = '<input type="text" value="" id="cgst' + prashidCounter + '" size="5" onblur="checkFloat(this);checkTax(this.value,igst'+ prashidCounter +'.value);calculate();"/>';
	newline.appendChild(newline10);
	
	var newline11 = slrow.cells[11].cloneNode(false);
	newline11.innerHTML = '<input type="text" value="" id="sgst' + prashidCounter + '" size="5" readonly="readonly" onblur="checkFloat(this);calculate();"/>';
	newline.appendChild(newline11);
	
	var newline12 = slrow.cells[12].cloneNode(false);
	newline12.innerHTML = '<input type="text" value="" id="igst' + prashidCounter + '" size="5" onblur="checkFloat(this);checkTax(cgst'+ prashidCounter +'.value,this.value);calculate();"/>';
	newline.appendChild(newline12);
	
	var newline13 = slrow.cells[13].cloneNode(false);
	newline13.innerHTML = '<input type="text" style="display: none;" value="" id="gross' + prashidCounter + '" size="6" onblur="checkFloat(this);calculate()"/>';
	newline.appendChild(newline13);
	
	var newline14 = slrow.cells[14].cloneNode(false);
	newline14.innerHTML = '<input type="text" value="" style="display: none;" id="tds' + prashidCounter + '" size="5" onblur="checkFloat(this);calculate()"/>';
	newline.appendChild(newline14);
	
	/*var newline12 = slrow.cells[12].cloneNode(false);
	newline12.innerHTML = '<input type="text" value="" id="advance' + prashidCounter + '" size="4" onblur="checkFloat(this);calculate()"/>';
	newline.appendChild(newline12);
	
	var newline13 = slrow.cells[13].cloneNode(false);
	newline13.innerHTML = '<input type="text" value="" id="other' + prashidCounter + '" size="5" onblur="checkFloat(this);calculate()"/>';
	newline.appendChild(newline13);
*/	
	var newline15 = slrow.cells[15].cloneNode(false);
	newline15.innerHTML = '<input type="text" value="" id="net' + prashidCounter + '" size="6" onblur="checkFloat(this);calculate()"/>';
	newline.appendChild(newline15);
	
	var newline16 = slrow.cells[16].cloneNode(false);
	newline16.innerHTML = '<input type="checkbox" name="ch" value="' + prashidCounter + '" size="2" />';
	newline.appendChild(newline16);
	
	
	tblBody.appendChild(newline);
	
	var newli = extrarow.cloneNode(false);
	var new00 = extrarow.cells[0].cloneNode(true);
	newli.appendChild(new00);
	
	var invtype=document.getElementById("invtype").value;
	if(invtype=='PREPAYMENT'){
		document.getElementById("prepaySrch").style.visibility="";
		document.getElementById("deductionSrch").style.visibility="";
		document.getElementById("preinvId").value="";
		document.getElementById("dedinvId").value="";
		document.getElementById("totalpreAmt").value="";
		document.getElementById("prepayment").value="";
		document.getElementById("deduction").value="";
		document.getElementById("totaldedAmt").value="";
	var cnter=document.getElementById("prashidCounter").value;
		for(var i=1;i<=cnter;i++){
			document.getElementById("cgst"+i).value="";
			document.getElementById("cgst"+i).readOnly = true;
			document.getElementById("cgst"+i).style.backgroundColor ="#D9D9D1";
			
			document.getElementById("igst"+i).value="";
			document.getElementById("igst"+i).readOnly = true;
    		document.getElementById("igst"+i).style.backgroundColor ="#D9D9D1";
    		
    		document.getElementById("sgst"+i).value="";
			document.getElementById("sgst"+i).readOnly = true;
    		document.getElementById("sgst"+i).style.backgroundColor ="#D9D9D1";
		}
	}
	
	
	generatedepartment();
	
}


/*function removeRow() {
	var counter = 0;
	var j = 2;
	var length = document.createinv.ch.length;
	var linecount = document.createinv.prashidCounter.value;
	var remove = new Array();
	var count = 0;
	for (var i = 0, r = 0; i < length; i++) {
		var cond = false;
		if (document.createinv.ch[i].checked != null) {
			cond = document.createinv.ch[i].checked;
		}
		if (cond && cond != null) {
			remove[r] = document.createinv.ch[i].value;
			count++;
			r++;
		}
	}
	if (count == linecount) {
		alert("Can not delete all rows.");
		return false;
	}
	// for message if removed without checkbox selected.
	if (remove.length == 0) {
		alert("Please select record before removing.");
		return false;
	}
	for (var i = 0; i < remove.length; i++) {
		var rem = remove[i];
		line = rem;
		j = j * parseInt(rem);
		var linerow = document.getElementById("innerTable")
				.getElementsByTagName('tr')[j];
		var itemsrow = document.getElementById("innerTable")
				.getElementsByTagName('tr')[j + 1];
		itemsrow.parentNode.removeChild(itemsrow);
		linerow.parentNode.removeChild(linerow);
		counter = counter + 1;

		for (var k = line; k < linecount; k++) {
			
			var lnon = "lno" + k;
			l = parseInt(k) + 1;
			var lnop = "lno" + l;
			
			var hsnn = "hsn" + k;
			l = parseInt(k) + 1;
			var hsnp = "quantity" + l;

			var secn = "sec" + k;
			l = parseInt(k) + 1;
			var secp = "sec" + l;

			var descriptionn = "description" + k;
			l = parseInt(k) + 1;
			var descriptionp = "description" + l;

			var basicAmtn = "basicAmt" + k;
			l = parseInt(k) + 1;
			var basicAmtp = "basicAmt" + l;

			var gstAmtn = "gstAmt" + k;
			l = parseInt(k) + 1;
			var gstAmtp = "gstAmt" + l;

			var grossn = "gross" + k;
			l = parseInt(k) + 1;
			var grossp = "gross" + l;

			var tdsn = "tds" + k;
			l = parseInt(k) + 1;
			var tdsp = "tds" + l;

			var advancen = "advance" + k;
			l = parseInt(k) + 1;
			var advancep = "advance" + l;

			var vn = "v" + k;
			l = parseInt(k) + 1;
			var vp = "v" + l;

			var othern = "other" + k;
			l = parseInt(k) + 1;
			var otherp = "other" + l;

			var en = "e" + k;
			l = parseInt(k) + 1;
			var ep = "e" + l;

			var netn = "net" + k;
			l = parseInt(k) + 1;
			var netp = "net" + l;

			document.getElementById(lnop).id = lnopn;
			document.getElementById(hsnp).id = hsnn;
			document.getElementById(secp).id = secn;
			document.getElementById(descriptionp).id = descriptionn;
			document.getElementById(basicAmtp).id = basicAmtn;
			document.getElementById(gstAmtp).id = gstAmtn;
			document.getElementById(grossp).id = grossn;
			document.getElementById(tdsp).id = tdsn;
			document.getElementById(advancep).id = advancen;
			//document.getElementById(vp).id = vn;
			document.getElementById(otherp).id = othern;
			//document.getElementById(ep).id = en;
			document.getElementById(netp).id = netn;
			
			if (document.createinv.ch.length == undefined) {
				document.createinv.ch.value = 1;
			} else {
				document.createinv.ch[k - 1].value = parseInt(document.createinv.ch[k - 1].value) - 1;
			}
			var epo = document.getElementById(eponon).value;

			for (var m = 0; m < document.getElementById(eponon).options.length; m++) {
				var oldv = document.getElementById(eponon).options[m].value;
				var old = oldv.split("#");
				var oldepono = old[0];
				var newv = oldepono + "#" + k;
				document.getElementById(eponon).options[m].value = newv;
			}
		}
		for (m = i + 1; m < remove.length; m++) {
			remove[m] = parseInt(remove[m]) - 1;
		}
		j = 2;
		linecount = linecount - 1;
	}
	if (document.createinv.ch.length == 1) {
		document.createinv.ch[0].disabled = true;
	}
	if (document.createinv.ch.length == undefined) {
		document.createinv.ch.disabled = true;
	}
	document.createinv.prashidCounter.value = linecount;
	//calculate();
}*/

function removeRow(tblId)
{
  var hidCount = document.createinv.prashidCounter.value;
    
  var tbl = document.getElementById("innerTable");
  var rowsDeleted = 0;
  var rowsDeletedCheck = 0;
  var countArrayOriginal = new Array('0');
  if(hidCount > 0){
    for(i=0;i<hidCount;i++)
    {
      if(document.createinv.ch[i].checked==true)
      {
        rowsDeletedCheck = parseInt(rowsDeletedCheck)+1;
      }
    }
  }

  if(rowsDeletedCheck == parseInt(hidCount)+1) 
  {
    alert('All rows cannot be deleted.');
    return false;
  }
  else
  {
      if(hidCount > 0){
        for(i=0;i<hidCount;i++)
        {
          if(document.createinv.ch[i].checked==true)
          {
        	  tbl.deleteRow(1+i);
            rowsDeleted = parseInt(rowsDeleted)+1;
            hidCount = parseInt(hidCount)-1;
            i=parseInt(i)-1;
            countArrayOriginal.splice(i+1,1);
          }
        }
       document.createinv.prashidCounter.value = hidCount;
      }
      if (hidCount == 1)
      {
        document.createinv.ch[0].disabled=true;
        document.createinv.lno.value=parseInt(hidCount);
      }
      else
      {
        for(j=1;j<=hidCount;j++)
        {
          document.createinv.lno[j].value=parseInt(j)+1;
          //document.createinv.ch[0].disabled=true;
        }
      }
    }

 }


////Invoice Creation
function validateNewInvoice(flg) {

		

   // return true;
	
	if(document.getElementById("suppliernm").value==''){
		alert("Please Select Supplier");
		return false;
	}
	
	if(document.getElementById("supplierSite").value==''){
		alert("Please Select Supplier Site");
		return false;
	}
	
	if(document.getElementById("gstno").value==''){
		alert("Please enter GST Number");
		return false;
	}
	
	if(document.getElementById("datepicker").value==''){
		alert("Please enter Invoice Date");
		return false;
	}
	
	if(document.getElementById("datepicker").value!=''){
		var dob = document.getElementById("datepicker").value;
	    var data = dob;
	    if (isNaN(Date.parse(data[2] + "-" + data[1] + "-" + data[0]))) {
	    	alert("Incorrect date format. Enter as DD-Mon-YYYY.");
	    	return false;
	    }
	}
	
	if(document.getElementById("invno").value==''){
		alert("Please enter Invoice Number");
		return false;
	}
	
	if(document.getElementById("finYear").value==''){
		alert("Please Select Financial Year");
		return false;
	}
	
	if(document.getElementById("frmDate").value==''){
		alert("Please Select Expense From Date");
		return false;
	}
	
	if(document.getElementById("toDate").value==''){
		alert("Please Select Expense To Date");
		return false;
	}
	
	if(document.getElementById("currency").value==''){
		alert("Please Select Currency");
		return false;
	}
	
	if(document.getElementById("invtype").value=='select'){
		alert("Please Select Invoice Type");
		return false;
	}
	
	if(document.getElementById("rcmfunc").checked==true){
		document.getElementById("rcmfuncflag").value='Y';
	}
	var linecount = document.getElementById("prashidCounter").value;
	var itemString = "";
	var itemStringValidate = "";
	for (var i = 1; i <= linecount; i++) {
	//alert(linecount);	
		var hsn = document.getElementById("hsn" + i).value;
		var sec = document.getElementById("sec" + i).value;
		var department=document.getElementById("department" + i).value;
		var product=document.getElementById("product" + i).value;
		var desc = document.getElementById("description" + i).value;
		var basicAmt = document.getElementById("basicAmt" + i).value;
		var cgst = document.getElementById("cgst" + i).value;
		var sgst = document.getElementById("sgst" + i).value;
		var igst = document.getElementById("igst" + i).value;
		var gross = document.getElementById("gross" + i).value;
		var tds = document.getElementById("tds" + i).value;
		//var advance = document.getElementById("advance" + i).value;
		//var other = document.getElementById("other" + i).value;
		var net = document.getElementById("net" + i).value;		
		var location=document.getElementById("location"+i).value;
		var taxtype=document.getElementById("taxtype"+i).value;
		var txtdesc=document.getElementById("txtdesc"+i).value;
		
		if (basicAmt == "") {
			basicAmt = 0;
		}
		
		if (cgst == "") {
			cgst = 0;
		}
		if (sgst == "") {
			sgst = 0;
		}
		if (igst == "") {
			igst = 0;
		}
		
		if (gross == "") {
			gross = 0;
		}
		
		if (tds == "") {
			tds = 0;
		}
		
		/*if (advance == "") {
			advance = 0;
		}*/
		
		if(location=='select'){
			alert("Please Select Line Location");
			return false;
		}
		var locationarr=location.split(",");
		
		location=locationarr[0];
		//alert(location);
		if(taxtype=='select'){
			alert("Please Select Tax Type");
			return false;
		}
		
		if(txtdesc==""){
			alert("Please Enter Description");
			return false;
		}
		
		if(parseInt(cgst)>0 && parseInt(igst)>0){
			alert("Tax Should be IGST or CGST/SGST");
			document.getElementById("cgst"+i).focus();
			return false;
		}
		
		var totalamount = document.getElementById("totalinvAmt").value;
		if(desc=='select'){
			alert("Please Select Nature Of Expense");
			return false;
		}
		if (totalamount <= 0) {
			alert("Total amount cannot be less than or equal to zero.");
			return false;
		}
		
		/*itemString += hsn + "~" + sec + "~" + department + "~" + product + "~"  
				+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
				+ gross + "~" + tds + "~" + advance	+ "~" + other + "~" + net + "@@";

		itemStringValidate += hsn + "~" + sec + "~" + department + "~" + product + "~"  
		+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
		+ gross + "~" + tds + "~" + advance	+ "~" + other + "~" + net + "@@";*/
		
		itemString += hsn + "~" + sec + "~" + department + "~" + product + "~"  
		+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
		+ gross + "~" + tds + "~" + location	+ "~" + taxtype + "~" + txtdesc + "~" + net + "@@";

		itemStringValidate += hsn + "~" + sec + "~" + department + "~" + product + "~"  
		+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
		+ gross + "~" + tds + "~" + location	+ "~" + taxtype + "~" + txtdesc + "~" + net + "@@";
		
	}
	document.getElementById('itemString').value = itemString;
	//alert(itemString);
	//var invoicenum=document.getElementById('invno').value;
	//var suppliernum=document.getElementById('suppliernm').value;
	//var suppliersite=document.getElementById('siteid').value;
	
	//checkInvoiceNoBeforeSubmit(invoicenum,suppliernum,suppliersite);
	
	if (document.getElementById('othernote') != undefined) {
		if (trim(document.getElementById('othernote').value) == '') {
			alert("Please enter other notes.");
			document.getElementById('othernote').focus();
			return false;
		}
	}
	/*xmlHttp = GetXmlHttpObject();
	if (xmlHttp == null) {
		alert("Your browser does not support AJAX!");
		return;
	}*/
	var afpno='';
	var editFlag = '';
	
	if (trim(document.getElementById('afpno').value) != '') {
		afpno = document.getElementById('afpno').value;
		
	}	
		
	if (document.getElementById('afpno').value != '') {
		editFlag = 'Y';
	}
	//var submissionFlag='I';
	// document.createinv.createInv.disabled=true;
	var siteid=document.getElementById("siteid").value;
	var suppliernum=document.getElementById("suppliernm").value;
	var invno=document.getElementById("invno").value;
	var invdate=document.getElementById("datepicker").value;
	var frmDt=document.getElementById("frmDate").value;
	var toDt=document.getElementById("toDate").value;
	var finYear=document.getElementById("finYear").value;
	var othernote=document.getElementById("othernote").value;
	var totalinvAmt=document.getElementById("totalinvAmt").value;
	var suppliername=document.getElementById("suppliername").value;
	var gstno=document.getElementById("gstno").value;
	var orgId=document.getElementById("orgId").value;
	
	var currency=document.getElementById("currency").value;
	var invoicetype=document.getElementById("invtype").value;
	var prepay=document.getElementById("totalpreAmt").value;
	var deduct=document.getElementById("totaldedAmt").value;
	var preinvId=document.getElementById("preinvId").value;
	var dedinvId=document.getElementById("dedinvId").value;
	var rcmfuncflag=document.getElementById("rcmfuncflag").value;
	/*if(invoicetype=='STANDARD' && (prepay=="" || deduct=="")){
		alert("Please select prepayment Amount and Deduction");
		return false;
	}
	*/
	 /*var url="savenewinvoice?flag=validate&itemStr="+itemStringValidate+"&editFlag="+editFlag+"&afpno="+afpno+"&submissionFlag="+flg+"&siteid="+siteid+
	 		"&suppliernum="+suppliernum+"&invno="+invno+"&invdate="+invdate+"&frmDt="+frmDt+"&toDt="+toDt+"&finYear="+finYear+"&othernote="+othernote+
	 		"&totalinvAmt="+totalinvAmt+"&suppliername="+suppliername+"&gstno="+gstno+"&orgId="+orgId;*/
	
	var url="savenewinvoice?flag=validate&itemStr="+itemStringValidate+"&editFlag="+editFlag+"&afpno="+afpno+"&submissionFlag="+flg+"&siteid="+siteid+
		"&suppliernum="+suppliernum+"&invno="+invno+"&invdate="+invdate+"&frmDt="+frmDt+"&toDt="+toDt+"&finYear="+finYear+"&othernote="+othernote+
		"&totalinvAmt="+totalinvAmt+"&suppliername="+suppliername+"&gstno="+gstno+"&orgId="+orgId+"&currency="+currency+
		"&invoicetype="+invoicetype+"&prepay="+prepay+"&deduct="+deduct+"&preinvId="+preinvId+"&dedinvId="+dedinvId+"&rcmfuncflag="+rcmfuncflag;
	  
	    /*xmlHttp.onreadystatechange=stateChangedValidateNewInvoice;
	    
	    xmlHttp.open("GET",url,true);
	    
	    xmlHttp.send(null);*/
	// alert(url);
	document.createinv.createInv.disabled=true;
	document.createinv.submitAppr.disabled=true;
	document.createinv.close.disabled=true;
	 document.createinv.action=url;
	 document.createinv.method="POST";
	 document.createinv.submit();
	
	
	
	
	
}


function validateEditInvoice(flg) {

	if(document.getElementById("suppliernm").value==''){
		alert("Please Select Supplier");
		return false;
	}
	
	if(document.getElementById("supplierSite").value==''){
		alert("Please Select Supplier Site");
		return false;
	}
	
	if(document.getElementById("gstno").value==''){
		alert("Please enter GST Number");
		return false;
	}
	
	if(document.getElementById("datepicker").value==''){
		alert("Please enter Invoice Date");
		return false;
	}
	
	if(document.getElementById("invno").value==''){
		alert("Please enter Invoice Number");
		return false;
	}
	
	if(document.getElementById("finYear").value==''){
		alert("Please Select Financial Year");
		return false;
	}
	
	if(document.getElementById("frmDate").value==''){
		alert("Please Select Expense From Date");
		return false;
	}
	
	if(document.getElementById("toDate").value==''){
		alert("Please Select Expense To Date");
		return false;
	}
	
	
	var linecount = document.getElementById("prashidCounter").value;
	var itemString = "";
	var itemStringValidate = "";
	for (var i = 1; i <= linecount; i++) {
	//alert(linecount);	
		var hsn = document.getElementById("hsn" + i).value;
		var sec = document.getElementById("sec" + i).value;
		var department=document.getElementById("department" + i).value;
		var product=document.getElementById("product" + i).value;
		var desc = document.getElementById("description" + i).value;
		var basicAmt = document.getElementById("basicAmt" + i).value;
		var cgst = document.getElementById("cgst" + i).value;
		var sgst = document.getElementById("sgst" + i).value;
		var igst = document.getElementById("igst" + i).value;
		var gross = document.getElementById("gross" + i).value;
		var tds = document.getElementById("tds" + i).value;
		var advance = document.getElementById("advance" + i).value;
		var other = document.getElementById("other" + i).value;
		var net = document.getElementById("net" + i).value;		
		
		
		if (basicAmt == "") {
			basicAmt = 0;
		}
		
		if (cgst == "") {
			cgst = 0;
		}
		if (sgst == "") {
			sgst = 0;
		}
		if (igst == "") {
			igst = 0;
		}
		
		if (gross == "") {
			gross = 0;
		}
		
		if (tds == "") {
			tds = 0;
		}
		
		if (advance == "") {
			advance = 0;
		}
		var totalamount = document.getElementById("totalinvAmt").value;
		if(desc==''){
			alert("Please Select Nature Of Expense");
			return false;
		}
		if (totalamount <= 0) {
			alert("Total amount cannot be less than or equal to zero.");
			return false;
		}
		
		itemString += hsn + "~" + sec + "~" + department + "~" + product + "~"  
				+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
				+ gross + "~" + tds + "~" + advance	+ "~" + other + "~" + net + "@@";

		itemStringValidate += hsn + "~" + sec + "~" + department + "~" + product + "~"  
		+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
		+ gross + "~" + tds + "~" + advance	+ "~" + other + "~" + net + "@@";
	}
	document.getElementById('itemString').value = itemString;
	//alert(itemString);
	//var invoicenum=document.getElementById('invno').value;
	//var suppliernum=document.getElementById('suppliernm').value;
	//var suppliersite=document.getElementById('siteid').value;
	
	//checkInvoiceNoBeforeSubmit(invoicenum,suppliernum,suppliersite);
	
	if (document.getElementById('othernote') != undefined) {
		if (trim(document.getElementById('othernote').value) == '') {
			alert("Please enter other notes.");
			document.getElementById('othernote').focus();
			return false;
		}
	}
	xmlHttp = GetXmlHttpObject();
	if (xmlHttp == null) {
		alert("Your browser does not support AJAX!");
		return;
	}
	var afpno='';
	var editFlag = '';
	
	if (trim(document.getElementById('afpno').value) != '') {
		afpno = document.getElementById('afpno').value;
		
	}	
		
	if (document.getElementById('afpno').value != '') {
		editFlag = 'Y';
	}
	//var submissionFlag='I';
	// document.createinv.createInv.disabled=true;
	var siteid=document.getElementById("siteid").value;
	var suppliernum=document.getElementById("suppliernm").value;
	var invno=document.getElementById("invno").value;
	var invdate=document.getElementById("datepicker").value;
	var frmDt=document.getElementById("frmDate").value;
	var toDt=document.getElementById("toDate").value;
	var finYear=document.getElementById("finYear").value;
	var othernote=document.getElementById("othernote").value;
	var totalinvAmt=document.getElementById("totalinvAmt").value;
	var suppliername=document.getElementById("suppliername").value;
	var gstno=document.getElementById("gstno").value;
	var orgId=document.getElementById("orgId").value;
	
	 var url="savenewinvoice?flag=validate&itemStr="+itemStringValidate+"&editFlag="+editFlag+"&afpno="+afpno+"&submissionFlag="+flg+"&siteid="+siteid+
	 		"&suppliernum="+suppliernum+"&invno="+invno+"&invdate="+invdate+"&frmDt="+frmDt+"&toDt="+toDt+"&finYear="+finYear+"&othernote="+othernote+
	 		"&totalinvAmt="+totalinvAmt+"&suppliername="+suppliername+"&gstno="+gstno+"&orgId="+orgId;
	  
	   /* xmlHttp.onreadystatechange=stateChangedValidateNewInvoice;
	    
	    xmlHttp.open("GET",url,true);
	    
	    xmlHttp.send(null);*/
	// alert(url);
	 document.createinv.action=url;
	 document.createinv.method="POST";
	 document.createinv.submit();
	

}

function submitApprInvoice() {

	if(document.getElementById("suppliernm").value==''){
		alert("Please Select Supplier");
		return false;
	}
	
	if(document.getElementById("supplierSite").value==''){
		alert("Please Select Supplier Site");
		return false;
	}
	
	if(document.getElementById("gstno").value==''){
		alert("Please enter GST Number");
		return false;
	}
	
	if(document.getElementById("datepicker").value==''){
		alert("Please enter Invoice Date");
		return false;
	}
	
	if(document.getElementById("invno").value==''){
		alert("Please enter Invoice Number");
		return false;
	}
	
	if(document.getElementById("finYear").value==''){
		alert("Please Select Financial Year");
		return false;
	}
	
	if(document.getElementById("frmDate").value==''){
		alert("Please Select Expense From Date");
		return false;
	}
	
	if(document.getElementById("toDate").value==''){
		alert("Please Select Expense To Date");
		return false;
	}
	
	
	var linecount = document.getElementById("prashidCounter").value;
	var itemString = "";
	var itemStringValidate = "";
	for (var i = 1; i <= linecount; i++) {
	//alert(linecount);	
		var hsn = document.getElementById("hsn" + i).value;
		var sec = document.getElementById("sec" + i).value;
		var department=document.getElementById("department" + i).value;
		var product=document.getElementById("product" + i).value;
		var desc = document.getElementById("description" + i).value;
		var basicAmt = document.getElementById("basicAmt" + i).value;
		var cgst = document.getElementById("cgst" + i).value;
		var sgst = document.getElementById("sgst" + i).value;
		var igst = document.getElementById("igst" + i).value;
		var gross = document.getElementById("gross" + i).value;
		var tds = document.getElementById("tds" + i).value;
		var advance = document.getElementById("advance" + i).value;
		var other = document.getElementById("other" + i).value;
		var net = document.getElementById("net" + i).value;		
		
		
		if (basicAmt == "") {
			basicAmt = 0;
		}
		
		if (cgst == "") {
			cgst = 0;
		}
		if (sgst == "") {
			sgst = 0;
		}
		if (igst == "") {
			igst = 0;
		}
		
		if (gross == "") {
			gross = 0;
		}
		
		if (tds == "") {
			tds = 0;
		}
		
		if (advance == "") {
			advance = 0;
		}
		var totalamount = document.getElementById("totalinvAmt").value;
		if(desc==''){
			alert("Please Select Nature Of Expense");
			return false;
		}
		if (totalamount <= 0) {
			alert("Total amount cannot be less than or equal to zero.");
			return false;
		}
		
		itemString += hsn + "~" + sec + "~" + department + "~" + product + "~"  
				+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
				+ gross + "~" + tds + "~" + advance	+ "~" + other + "~" + net + "@@";

		itemStringValidate += hsn + "~" + sec + "~" + department + "~" + product + "~"  
		+ desc + "~" + basicAmt + "~" + cgst + "~" + sgst + "~" + igst + "~" 
		+ gross + "~" + tds + "~" + advance	+ "~" + other + "~" + net + "@@";
	}
	document.getElementById('itemString').value = itemString;
	//alert(itemString);
	//var invoicenum=document.getElementById('invno').value;
	//var suppliernum=document.getElementById('suppliernm').value;
	//var suppliersite=document.getElementById('siteid').value;
	
	//checkInvoiceNoBeforeSubmit(invoicenum,suppliernum,suppliersite);
	
	if (document.getElementById('othernote') != undefined) {
		if (trim(document.getElementById('othernote').value) == '') {
			alert("Please enter other notes.");
			document.getElementById('othernote').focus();
			return false;
		}
	}
	/*xmlHttp = GetXmlHttpObject();
	if (xmlHttp == null) {
		alert("Your browser does not support AJAX!");
		return;
	}*/
	var afpno='';
	var editFlag = '';
	
	if (trim(document.getElementById('afpno').value) != '') {
		afpno = document.getElementById('afpno').value;
		
	}	
		
	if (document.getElementById('afpno').value != '') {
		editFlag = 'Y';
	}
	var submissionFlag='P';
	// document.createinv.createInv.disabled=true;
	var siteid=document.getElementById("siteid").value;
	var suppliernum=document.getElementById("suppliernm").value;
	var invno=document.getElementById("invno").value;
	var invdate=document.getElementById("datepicker").value;
	var frmDt=document.getElementById("frmDate").value;
	var toDt=document.getElementById("toDate").value;
	var finYear=document.getElementById("finYear").value;
	var othernote=document.getElementById("othernote").value;
	var totalinvAmt=document.getElementById("totalinvAmt").value;
	var suppliername=document.getElementById("suppliername").value;
	var gstno=document.getElementById("gstno").value;
	var orgId=document.getElementById("orgId").value;
	
	 var url="savenewinvoice?flag=validate&itemStr="+itemStringValidate+"&editFlag="+editFlag+"&afpno="+afpno+"&submissionFlag="+submissionFlag+"&siteid="+siteid+
	 		"&suppliernum="+suppliernum+"&invno="+invno+"&invdate="+invdate+"&frmDt="+frmDt+"&toDt="+toDt+"&finYear="+finYear+"&othernote="+othernote+
	 		"&totalinvAmt="+totalinvAmt+"&suppliername="+suppliername+"&gstno="+gstno+"&orgId="+orgId;
	  
	    /*xmlHttp.onreadystatechange=stateChangedValidateNewInvoice;
	    
	    xmlHttp.open("GET",url,true);
	    
	    xmlHttp.send(null);*/
	// alert(url);
	 document.createinv.action=url;
	 document.createinv.method="POST";
	 document.createinv.submit();
	
	
	
	
	
}

function ApprsubmittedInvoice(){
	
	var afpno=document.getElementById("afpno").value;
	document.viewsubInv.action="submitForApprovalInv?apfno="+afpno;
	//document.viewsubInv.method="POST";
	document.viewsubInv.submit();
}

function checkInvoiceNoBeforeSubmit(obj, obj2,obj3) {
	
	if(document.getElementById("suppliernm").value==''){
		alert("Please select Supplier");
		document.getElementById("invno").value='';
		return false;
		
	}
	if(document.getElementById("supplierSite").value==''){
		alert("Please select Supplier Site");
		document.getElementById("invno").value='';
		return false;
		
	}
	var invNo = obj.value;
	invNo = invNo.replace('&', '%26');
	
	if (obj.length == 0) {
		document.getElementById("existinvoice").innerHTML = "";
		return;
	}
	mode = "existInvoice";
	xmlHttp = GetXmlHttpObject();
	if (xmlHttp == null) {
		alert("Your browser does not support AJAX!");
		return;
	}
	var url = "existInvoice";
	url = url + "?&invoiceNo=" + invNo + "&userVID=" + obj2.value
			+ "&vsite=" + obj3.value;
	
	
	xmlHttp.onreadystatechange = stateChangedcheckInvoiceNoBeforeSubmit;
	xmlHttp.open("GET", url, true);
	xmlHttp.send(null);
}

function stateChangedcheckInvoiceNoBeforeSubmit() { 
    if (xmlHttp.readyState==4)
    { 
       var exist=xmlHttp.responseText;
       if(exist>=1)
       {
    	    alert('Invoice number already exists, please enter another invoice number.');
            document.getElementById('invno').focus();
            document.getElementById("invno").value='';
            return false;
       }
       else
       {
    	  return true;
    	   
       }
       
    }
}
function checksearchval(){
	var apfno= document.viewinv.apfnumber.value;
	var invno= document.viewinv.invnumber.value;
	
	if(apfno==""){
		
		apfno="";
				
	}
	if(invno==""){
		invno="";
	}
	
		document.viewinv.flag.value="search";
		document.viewinv.afpno.value=apfno;
		document.viewinv.invoiceno.value=invno;
		document.viewinv.submit();
	
}

function searchinvAppr(){
	
		document.invappr.flag.value="searchapprInv";
		document.invappr.afpno.value=apfno;
		document.invappr.submit();
	
}

function approveInv(){
	var apprRem=document.invapprove.apprRemarks.value;
	
	if(apprRem==""){
		alert("Please Enter Remarks")
		document.invapprove.apprRemarks.focus();
		return false;
	}
	else{	
	document.invapprove.status.value="S";	
	document.invapprove.flag.value="apprInv";
	document.invapprove.submit();
	//window.close();	
	}
	
}

function finapproveInv(){
	var apprRem=document.invapprove.finRemarks.value;
	var gldate=document.invapprove.gldate.value;
	
	if(apprRem==""){
		alert("Please Enter Remarks");
		document.invapprove.finRemarks.focus();
		return false;
	}
	if(gldate==""){
		alert("Please Enter GL Date");
		//document.invapprove.finRemarks.focus();
		return false;
	}
	else{
		
	document.invapprove.status.value="A";	
	document.invapprove.flag.value="finapprInv"; 
	document.invapprove.submit();
	}
}

function finrejectInv(){
var apprRem=document.invapprove.finRemarks.value;
	
	if(apprRem==""){
		alert("Please Enter Remarks")
		document.invapprove.finRemarks.focus();
		return false;
	}
	else{
	
	document.invapprove.status.value="R";	
	document.invapprove.flag.value="finRejectInv";
	document.invapprove.submit();
	//window.close();	
	}
}
function referBackInv(){
var apprRem=document.invapprove.apprRemarks.value;
	
	if(apprRem==""){
		alert("Please Enter Remarks")
		document.invappr.apprRemarks.focus();
		return false;
	}
	else{
	document.invapprove.status.value="R";	
	document.invapprove.flag.value="rejInv";
	document.invapprove.submit();
	}
}

/*function multiInvAppr(){
	var totcnt=document.getElementById("totcnt").value;
	var afpno='';
	var cnt=0;
	//alert(totcnt);
	for(var i=1;i<=totcnt;i++){
		
		if(document.getElementById("chk"+i).checked){
			cnt=cnt+1;
			var afpn=document.getElementById("chk"+i).value;
			
			afpno+=afpn+',';
			
			//alert(afpno);
		}
		
	}
	if(cnt==0){
		alert("Please check atleast one checkbox");
		return false;
	}
	if(cnt>0 && document.getElementById("rmks").value==''){
		alert("Please enter Remarks");
		document.getElementById("rmks").focus();
		return false;
	}else{
		document.invappr.afpno.value=afpno;
		document.invappr.chkcnt.value=cnt;
		document.invappr.status.value='S';
		document.invappr.flag.value='multiInv';
		document.invappr.submit();
	}
	
	
}*/
function multiInvAppr(){
	var totcnt=document.getElementById("totcnt").value;
	var afpno='';
	var cnt=0;
	//alert(totcnt);
	for(var i=1;i<=totcnt;i++){
		
		if(document.getElementById("chk"+i).checked){
			cnt=cnt+1;
			var afpn=document.getElementById("afpexpno"+i).value;
			var afpExpCate=document.getElementById("afpexpCat"+i).value;
			var afpnType=document.getElementById("afpexptype"+i).value;
			
			afpno+=afpn+'~'+afpExpCate+'~'+afpnType+',';
			
			//alert(afpno);
		}
		
	}
	//alert(afpno);
	if(cnt==0){
		alert("Please check atleast one checkbox");
		return false;
	}
	if(cnt>0 && document.getElementById("rmks").value==''){
		alert("Please enter Remarks");
		document.getElementById("rmks").focus();
		return false;
	}else{
		document.invappr.afpno.value=afpno;
		document.invappr.chkcnt.value=cnt;
		document.getElementById("appr").disabled=true;
		document.invappr.status.value='S';
		document.invappr.flag.value='multiInv';
		document.invappr.submit();
	}
	
	
}

/*function multiFinInvAppr(){
	var totcnt=document.getElementById("totcnt").value;
	var afpno='';
	var gldt='';
	var cnt=0;
	var afpstring='';
	//alert(totcnt);
	for(var i=1;i<=totcnt;i++){
		
		if(document.getElementById("chk"+i).checked){
			cnt=cnt+1;
			var afpn=document.getElementById("chk"+i).value;
			if(document.getElementById("datepicker"+i).value==''){
				alert("Please select GL Date");
				return false;
			}
			var glDt=document.getElementById("datepicker"+i).value;
			var invst=document.getElementById("invstat"+i).value;
			if(invst==''){
				alert("Please select Invoice Status");
				return false;
			}
			afpno+=afpn+',';
			gldt+=glDt+',';
			//afpstring+=afpn+'~'+glDt+'@@';
			afpstring+=afpn+'~'+glDt+'~'+invst+'@@';
			//alert(afpstring);
		}
		
	}
	if(cnt==0){
		alert("Please check atleast one checkbox");
		return false;
	}
	if(cnt>0 && document.getElementById("rmks").value==''){
		alert("Please enter Remarks");
		document.getElementById("rmks").focus();
		return false;
	}else{
		
		document.invappr.afpno.value=afpno;
		document.invappr.chkcnt.value=cnt;
		document.invappr.glDate.value=gldt;
		document.invappr.afpstr.value=afpstring;
		document.invappr.status.value='A';
		document.invappr.flag.value='multiFinInv';
		document.invappr.submit();
	}
	
	
}*/
function multiFinInvAppr(){
	var totcnt=document.getElementById("totcnt").value;
	var afpno='';
	var gldt='';
	var cnt=0;
	var afpstring='';
	//alert(totcnt);
	for(var i=1;i<=totcnt;i++){
		
		if(document.getElementById("chk"+i).checked){
			cnt=cnt+1;
			var afpn=document.getElementById("afpexpno"+i).value;
			var expCat=document.getElementById("afpexpCat"+i).value;
			var expType=document.getElementById("afpexptype"+i).value;
			
			var invst=document.getElementById("invstat"+i).value;
			if(invst==''){
				alert("Please select Invoice Status");
				return false;
			}
			
			if(document.getElementById("datepicker"+i).value=='' && invst=='A'){
				alert("Please select GL Date");
				return false;
			}
			var glDt=document.getElementById("datepicker"+i).value;
			
			/*afpno+=afpn+',';
			gldt+=glDt+',';
			//afpstring+=afpn+'~'+glDt+'@@';
			afpstring+=afpn+'~'+glDt+'~'+invst+'@@';
			//alert(afpstring);*/
			afpstring+=afpn+'~'+expCat+'~'+expType+'~'+glDt+'~'+invst+'@@';
		}
		
	}
	//alert(afpstring);
	if(cnt==0){
		alert("Please check atleast one checkbox");
		return false;
	}
	if(cnt>0 && document.getElementById("rmks").value==''){
		alert("Please enter Remarks");
		document.getElementById("rmks").focus();
		return false;
	}else{
		
		document.invappr.afpno.value=afpno;
		document.invappr.chkcnt.value=cnt;
		document.invappr.glDate.value=gldt;
		document.invappr.afpstr.value=afpstring;
		document.getElementById("appr1").disabled=true;
		document.invappr.status.value='A';
		document.invappr.flag.value='multiFinInv';
		document.invappr.submit();
	}
	
	
}

function roundNumber(num, dec) {
	var result = Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
	if (dec != 0) {
		result = result.toFixed(2);
	}
	return result;
}


function calculate() {
	var linecount = document.createinv.prashidCounter.value;
	var basicamt = 0;
	var v = 0;
	var cgst = 0;
	var sgst = 0;
	var igst = 0;
	var gross = 0;
	var tds = 0;
	var advance = 0;
	var otherded = 0;
	var net = 0;
	var totalprice = 0;
	
	for (var i = 1; i <= linecount; i++) {
		basicamt=document.getElementById("basicAmt"+i).value;
		cgst=document.getElementById("cgst"+i).value;
		sgst=document.getElementById("cgst"+i).value;
		igst=document.getElementById("igst"+i).value;
		gross=document.getElementById("gross"+i).value;
		tds=document.getElementById("tds"+i).value; 
	//	advance=document.getElementById("advance"+i).value;
	//	otherded=document.getElementById("other"+i).value;
		net=document.getElementById("net"+i).value;
		 
		if (basicamt == '') {
			basicamt = 0;
		}
		if (cgst == '') {
			cgst = 0;
		}
		/*if (sgst == '') {
			sgst = 0;
		}*/
		if (igst == '') {
			igst = 0;
		}
		/*if (gross == '') {
			gross = 0;
		}*/
		if (tds == '') {
			tds = 0;
		}
		/*if (advance == '') {
			advance = 0;
		}
		if (otherded == '') {
			otherded = 0;
		}*/
		/*if (net == '') {
			net = 0;
		}*/

		/*totalprice=totalprice+roundNumber(basicamt, 0)+roundNumber(gst, 0)+roundNumber(gross, 0)+roundNumber(tds, 0)+roundNumber(advance, 0)+
		roundNumber(otherded, 0)+roundNumber(net, 0);*/
		/*if(parseFloat(cgst)>0 && parseFloat(igst)>0){
			document.getElementById("cgst"+i).value='';
			document.getElementById("igst"+i).value='';
			document.getElementById("sgst"+i).value='';
		}*/
		
		gross=parseFloat(basicamt)+parseFloat(cgst)+parseFloat(sgst)+parseFloat(igst);
		document.getElementById("basicAmt"+i).value=basicamt;
		document.getElementById("cgst"+i).value=cgst;
		document.getElementById("sgst"+i).value=cgst;
		document.getElementById("igst"+i).value=igst;
		if(!(isNaN(gross))){
			
			document.getElementById("gross"+i).value=parseFloat(gross);	
		}else{
			document.getElementById("gross"+i).value=0;
		}
		
		
		//net=parseFloat(gross)-parseFloat(tds)-parseFloat(advance)-parseFloat(otherded);
		net=parseFloat(gross)-parseFloat(tds);
		
		document.getElementById("tds"+i).value=tds;
		//document.getElementById("advance"+i).value=advance;
		//document.getElementById("other"+i).value=otherded;
		if(!(isNaN(gross))){
		document.getElementById("net"+i).value=roundNumber(net, 2);
		}else{
			document.getElementById("net"+i).value=0;
		}
		totalprice=parseFloat(totalprice)+parseFloat(net);
			
	}
	/*totalprice=roundNumber(basicamt, 0)+roundNumber(gst, 0)+roundNumber(gross, 0)+roundNumber(tds, 0)+roundNumber(advance, 0)+
			roundNumber(otherded, 0)+roundNumber(net, 0);
	*/
	
	advance=document.getElementById("totalpreAmt").value;
	otherded=document.getElementById("totaldedAmt").value;
	
	if (advance == '') {
		advance = 0;
	}
	if (otherded == '') {
		otherded = 0;
	}
	
	totalprice=parseFloat(totalprice)-parseFloat(advance)-parseFloat(otherded);
	
	if(!(isNaN(totalprice))){
	document.createinv.totalinvAmt.value = roundNumber(totalprice, 2);
	}else{
		document.createinv.totalinvAmt.value =0;
	}
	
}

function checkTax(cgst,igst){
	
	//alert(cgst +"-"+igst);
	if(parseFloat(cgst)>0 && parseFloat(igst)>0){
		alert("Tax Should be IGST or CGST/SGST");
		return false;
	}
	
}

function searchdeductionwin(){
	
	if(document.getElementById("suppliernm").value==''){
		alert("Please Select Supplier");
		return false;
	}
	
	if(document.getElementById("supplierSite").value==''){
		alert("Please Select Supplier Site");
		return false;
	}
	
	var supplierid=document.getElementById("supplierid").value;
	var supplierSiteid=document.getElementById("siteid").value;
	
	var url="searchdeduction?supplierid="+supplierid+"&Siteid="+supplierSiteid;
	window.open(url,'Search PrePayment','width=800,height=400,resizable=no');
}

function selectDeduction(){
	var totalch=document.supplierdeduc.dedcSize.value;
	var invIdArr="";
	var crNumArr="";
	var crAmtArr="";
	var remBalArr="";
	
	var totalAmt=0;
	for(var i=0;i<totalch;i++){
		if(document.getElementById("ch"+i).checked==true){
			var invId=document.getElementById("dedInvId"+i).value;
			var crNum=document.getElementById("creditMemNo"+i).value;
			var crAmt=document.getElementById("creditMemAmt"+i).value;
			var remBal=document.getElementById("remAmt"+i).value;
			
			 
			if(invIdArr==""){	invIdArr=invId;		}
			else{	invIdArr +=","+invId; 			}	
			
			if(crNumArr==""){	crNumArr=crNum;	}
			else{ crNumArr +=","+crNum;			}

			if(crAmtArr==""){	crAmtArr=crAmt;	}
			else{ crAmtArr +=","+crAmt;			}
			
			if(remBalArr==""){	remBalArr=remBal;	}
			else{ remBalArr +=","+remBal;			}
			
					
			totalAmt=parseInt(totalAmt)+parseInt(remBal);
		}
	}
	window.opener.document.getElementById("dedinvId").value=invIdArr;
	window.opener.document.getElementById("crmemoNum").value=crNumArr;
	window.opener.document.getElementById("crmemoAmt").value=crAmtArr;
	window.opener.document.getElementById("remBal").value=remBalArr;
	window.opener.document.getElementById("deduction").value=roundNumber(totalAmt,0);
	window.opener.document.getElementById("totaldedAmt").value=roundNumber(totalAmt,0);
	
	window.close();
}

function searchprepaywin(){
	
	if(document.getElementById("suppliernm").value==''){
		alert("Please Select Supplier");
		return false;
	}
	
	if(document.getElementById("supplierSite").value==''){
		alert("Please Select Supplier Site");
		return false;
	}
	
	var supplierid=document.getElementById("supplierid").value;
	var supplierSiteid=document.getElementById("siteid").value;
	
	var url="searchprepayment?supplierid="+supplierid+"&Siteid="+supplierSiteid;
	window.open(url,'Search PrePayment','width=800,height=400,resizable=no');
}

function selectPrepayment(){
	var totalch=document.supplierprePay.prepaySize.value;
	var invIdArr="";
	var preNumArr="";
	var preAmtArr="";
	var preBalArr="";
	var amtPaidArr="";
	var totalAmt=0;
	for(var i=0;i<totalch;i++){
		if(document.getElementById("ch"+i).checked==true){
			var invId=document.getElementById("invoiceId"+i).value;
			var preNum=document.getElementById("prepayNum"+i).value;
			var preAmt=document.getElementById("prepayAmt"+i).value;
			var preBal=document.getElementById("prepayBal"+i).value;
			var amtPaid=document.getElementById("amountPaid"+i).value;
			 
			if(invIdArr==""){	invIdArr=invId;		}
			else{	invIdArr +=","+invId; 			}	
			
			if(preNumArr==""){	preNumArr=preNum;	}
			else{ preNumArr +=","+preNum;			}

			if(preAmtArr==""){	preAmtArr=preAmt;	}
			else{ preAmtArr +=","+preAmt;			}
			
			if(preBalArr==""){	preBalArr=preBal;	}
			else{ preBalArr +=","+preBal;			}
			
			if(amtPaidArr==""){	amtPaidArr=amtPaid;	}
			else{ amtPaidArr +=","+amtPaid;			}
			
			totalAmt=parseInt(totalAmt)+parseInt(preBalArr);
		}
	}
	window.opener.document.getElementById("preinvId").value=invIdArr;
	window.opener.document.getElementById("prepayNum").value=preNumArr;
	window.opener.document.getElementById("prepayAmt").value=preAmtArr;
	window.opener.document.getElementById("prepayBal").value=preBalArr;
	window.opener.document.getElementById("amountPaid").value=amtPaidArr;
	window.opener.document.getElementById("prepayment").value=roundNumber(totalAmt,0);
	window.opener.document.getElementById("totalpreAmt").value=roundNumber(totalAmt,0);
	
	
	
	window.close();
	
	
}

function searchsupplierwin(){
	
	document.getElementById("supplierSite").value="";
	document.getElementById("siteid").value="";
	document.getElementById("orgId").value="";
	document.getElementById("gstno").value="";
	document.getElementById("preinvId").value="";
	document.getElementById("dedinvId").value="";
	document.getElementById("totalpreAmt").value="";
	document.getElementById("prepayment").value="";
	document.getElementById("deduction").value="";
	document.getElementById("totaldedAmt").value="";
	
	var url="searchsupplier";
	window.open(url,'Search Supplier','width=800,height=400,resizable=no');
}

function searchsupplier(){
	
	var textval=document.suppliersrch.supplierName.value;
	/*if(textval==''){
		alert("Please enter Supplier Name ");
		document.suppliersrch.supplierName.focus();
		return false;
	}else{*/
		document.suppliersrch.suppliernm.value=textval;
		document.suppliersrch.flag.value="search";
		document.suppliersrch.submit();
	//}
}

function setsupplier(id){
	var vno=document.getElementById("venNum"+id).value;
	var vname=document.getElementById("venName"+id).value;
	var vid=document.getElementById("venId"+id).value;
	var vtype=document.getElementById("ventype"+id).value;
	
	window.opener.document.getElementById("suppliernm").value=vno;
	window.opener.document.getElementById("suppliername").value=vname;
	window.opener.supplierid.value=vid;
	window.opener.suppliertype.value=vtype;
	
	window.close();
	
}

function searchsupplierwinsite(){
	
	if(document.getElementById("suppliernm").value==''){
		alert("Please Select Vendor First");
		return false;
	}
	document.getElementById("location1").value="select";
	document.getElementById("preinvId").value="";
	document.getElementById("dedinvId").value="";
	document.getElementById("totalpreAmt").value="";
	document.getElementById("prepayment").value="";
	document.getElementById("deduction").value="";
	document.getElementById("totaldedAmt").value="";
	
	var supplierid=document.getElementById("supplierid").value;
	var url="searchsuppliersite?supplierid="+supplierid;
	window.open(url,'Search Supplier Site','width=800,height=400,resizable=no');
}

function searchsuppliersite(){
	var textval=document.suppliersitesrch.suppliersiteName.value;
	/*if(textval==''){
		alert("Please enter Supplier site ");
		document.suppliersitesrch.suppliersiteName.focus();
		return false;
	}
	else{*/
		document.suppliersitesrch.suppliersiteName.value=textval;
		document.suppliersitesrch.flag.value="search";
		document.suppliersitesrch.submit();
	//}
}
function setsuppliersite(id){
	var siteCode=document.getElementById("sitecode"+id).value;
	var siteId=document.getElementById("siteId"+id).value;
	var orgId=document.getElementById("orgId"+id).value;
	var supplier=document.getElementById("supplierid").value;
	var state=document.getElementById("state"+id).value;

	window.opener.document.getElementById("supplierSite").value=siteCode;
	window.opener.document.getElementById("siteid").value=siteId;
	window.opener.orgId.value=orgId;
	window.opener.state.value=state;
	
	var gstno=getGSTdtls(supplier,siteId);
	//window.opener.document.getElementById("gstno").value=getGSTdtls(supplier,siteId);
	//alert("gst-"+  gstno);
		window.opener.document.getElementById("gstno").value=document.getElementById("gstno").value;
	
	window.close();
	
}

function getGSTdtls(supplier,siteId){
	
	xmlHttp=GetXmlHttpObject()
    if (xmlHttp==null)
    {
      alert ("Browser does not support HTTP Request")
      return
    }
	
    var url="getSupplierGST?supplysiteId="+siteId+"&supplierid="+supplier;
   
    xmlHttp.onreadystatechange=stateChangedgetGST 
    xmlHttp.open("GET",url,false)
    xmlHttp.send(null)
	
}
	
function stateChangedgetGST() 
{ 
    
    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
        var xmlDoc = xmlHttp.responseXML.documentElement;
           var supplier = xmlDoc.getElementsByTagName("supply");
            for (i = 0; i < supplier.length ; i++)
            {
            	var optval=supplier[i].getElementsByTagName("supplierGST");
            	document.getElementById("gstno").value=optval[0].firstChild.data;
            	//var gst=optval[0].firstChild.data;
            	
         
            }
          
    }

}

function updatePass(){
	var oldPass=document.changePass.oldPass.value;
	var newPass=document.changePass.newPass.value;
	var confirmPass=document.changePass.confirmPass.value;
	
	if(oldPass==''){
		alert("Please Enter Old Password");
		document.changePass.oldPass.focus();
		return false;
	}
	if(newPass==''){
		alert("Please Enter New Password");
		document.changePass.newPass.focus();
		return false;
	}
	if(confirmPass==''){
		alert("Please Enter Confirm Password");
		document.changePass.confirmPass.focus();
		return false;
	}
	if(newPass!=confirmPass){
		alert("New and Confirm Password Did Not Match");
		return false;
	}
	if(oldPass==newPass){
		alert("Old and New Password Should not be Same");
		return false;
	}
	document.changePass.Update.disabled=true;
	document.changePass.flag.value="update";
	document.changePass.submit();
}


function updateFirstPass(){
	var oldPass=document.changefirstPass.oldPass.value;
	var newPass=document.changefirstPass.newPass.value;
	var confirmPass=document.changefirstPass.confirmPass.value;
	
	if(oldPass==''){
		alert("Please Enter Old Password");
		document.changefirstPass.oldPass.focus();
		return false;
	}
	if(newPass==''){
		alert("Please Enter New Password");
		document.changefirstPass.newPass.focus();
		return false;
	}
	if(confirmPass==''){
		alert("Please Enter Confirm Password");
		document.changefirstPass.confirmPass.focus();
		return false;
	}
	if(newPass!=confirmPass){
		alert("New and Confirm Password Did Not Match");
		return false;
	}
	if(oldPass==newPass){
		alert("Old and New Password Should not be Same");
		return false;
	}
	document.changefirstPass.Update.disabled=true;
	document.changefirstPass.flag.value="updatefirstPass";
	document.changefirstPass.submit();
}

function checkDate(fld) {
	var success = true;
	var mo, day, yy, testDate;
	var val = fld.value;
	var re = new RegExp("[0-9]{1,2}[/-][A-Z a-z]{3}[/-][0-9]{4}", "g");
	if (val != '') {
		if (re.test(val)) {
			var delimChar = (val.indexOf("-") != -1) ? "-" : "-";
			var delim1 = val.indexOf(delimChar);
			var delim2 = val.lastIndexOf(delimChar);
			day = parseInt(val.substring(0, delim1), 10);
			mo = getMonth(val.substring(delim1 + 1, delim2), 10);
			yy = parseInt(val.substring(delim2 + 1), 10);
			testDate = new Date(yy, mo, day);

			if (testDate.getDate() == day) {

				if (testDate.getMonth() == mo) {
					if (!testDate.getFullYear() == yy) {
						alert("Invalid year entry.");
						fld.focus();
						success = false;
					}
				}

				else {
					alert("Invalid month entry.");
					fld.focus();
					success = false;
				}
			} else {
				alert("Invalid day entry.");
				fld.focus();
				success = false;
			}
		} else {
			alert("Incorrect date format. Enter as DD-Mon-YYYY.");
			success = false;
			//fld.focus();
		}
	}
	
	return (success);
}

function trim(s) {
	var i;
	var returnString = "";
	// Search through string's characters one by one.
	// If character is not a whitespace, append to returnString.
	for (i = 0; i < s.length; i++) {
		// Check that current character isn't whitespace.
		var c = s.charAt(i);
		if (c != " ")
			returnString += c;
	}
	return returnString;
}

function generatedepartment(){
	
	    xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	    var url="getdepartment";	    
	    xmlHttp.onreadystatechange=stateChangedgetDept
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	    
	}
	function stateChangedgetDept() 
	{ 
		var lineCount = document.getElementById('prashidCounter').value;
	   
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var dept = xmlDoc.getElementsByTagName("dept");
	           //alert(dept.length);
	            for (i = 0; i < dept.length ; i++)
	            {
	            	/*var optval=dept[i].getElementsByTagName("department");
	            	document.getElementById("suppliernm").value=optval[0].firstChild.data;*/
	        //   if (document.getElementById('department' + lineCount).value == '') {	
	            	var flexVal=dept[i].getElementsByTagName("flexVal");
	            	var description=dept[i].getElementsByTagName("description");
	            	//alert(flexVal+"-"+description);
	            	var optn = document.createElement("OPTION");
	            	//var descnew = description.replace("amp", "&");
	            	var descnew = description[0].firstChild.data;
	            	optn.text=descnew.replace("amp", "&");
					optn.value = flexVal[0].firstChild.data;
	           	document.getElementById('department' + lineCount).options.add(optn);
	          // }	
				
	            }
	            generateProduct();
	        	
	    }
	    
	}
	
	function generateProduct(){
		
	    xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	    var url="getProduct";	    
	    xmlHttp.onreadystatechange=stateChangedgetProd
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	    
	}
	function stateChangedgetProd() 
	{ 
		var lineCount = document.getElementById('prashidCounter').value;
	   
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var prod = xmlDoc.getElementsByTagName("prod");
	           //alert(dept.length);
	            for (i = 0; i < prod.length ; i++)
	            {
	            	var flexVal=prod[i].getElementsByTagName("flexVal");
	            	var description=prod[i].getElementsByTagName("description");
	            	
	            	var optn = document.createElement("OPTION");
	            	
	            	var descnew = description[0].firstChild.data;
	            	optn.text=descnew.replace("amp", "&");
					optn.value = flexVal[0].firstChild.data;
	           	document.getElementById('product' + lineCount).options.add(optn);
	          
				
	            }
	            generateDesc();
	    }
	    
	}
	
function generateDesc(){
		
	    xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	    var url="getDescription";	    
	    xmlHttp.onreadystatechange=stateChangedgetDesc
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	}
	function stateChangedgetDesc() 
	{ 
		var lineCount = document.getElementById('prashidCounter').value;
	   
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("desc");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("glCode");
	            	var description=desc[i].getElementsByTagName("description");
	            	
	            	var optn = document.createElement("OPTION");
	            	
	            	var descnew = description[0].firstChild.data;
	            	optn.text=descnew.replace("amp", "&");
					optn.value = glCode[0].firstChild.data;
	           	document.getElementById('description' + lineCount).options.add(optn);
	          }
	            generateLocation();
	       
	    }
	    
	}
	
function generateLocation(){
		
	    xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	    var url="getLocation";	    
	    xmlHttp.onreadystatechange=stateChangedgetLoc
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	}
	function stateChangedgetLoc() 
	{ 
		var lineCount = document.getElementById('prashidCounter').value;
	   
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var loca = xmlDoc.getElementsByTagName("loca");
	           //alert(dept.length);
	            for (i = 0; i < loca.length ; i++)
	            {
	            	var glCode=loca[i].getElementsByTagName("glCode");
	            	var llocation=loca[i].getElementsByTagName("llocation");
	            	var tag=loca[i].getElementsByTagName("tag");
	            	
	            	var optn = document.createElement("OPTION");
	            	
	            	var locationnew = llocation[0].firstChild.data;
	            	optn.text=locationnew;
					optn.value = tag[0].firstChild.data+","+glCode[0].firstChild.data;
					//alert(optn.value);
	           	document.getElementById('location' + lineCount).options.add(optn);
	          }
	            generateTaxType();
	       
	    }
	    
	}
	
function generateTaxType(){
		
	    xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	    var url="getTaxType";	    
	    xmlHttp.onreadystatechange=stateChangedgetTaxType
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	}
	function stateChangedgetTaxType() 
	{ 
		var lineCount = document.getElementById('prashidCounter').value;
	   
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var taxtype = xmlDoc.getElementsByTagName("taxtype");
	           //alert(dept.length);
	            for (i = 0; i < taxtype.length ; i++)
	            {
	            	var lttype=taxtype[i].getElementsByTagName("lttype");
	            	var glCode=taxtype[i].getElementsByTagName("glCode");	            	
	            	
	            	var optn = document.createElement("OPTION");
	            	
	            	var lttypenew = lttype[0].firstChild.data;
	            	
	            	optn.text=lttypenew.replace(" per","%");
					optn.value = glCode[0].firstChild.data;
	           	document.getElementById('taxtype' + lineCount).options.add(optn);
	          }
	            //generateTaxType();
	       
	    }
	    
	}	
function checkforgotdtls(){
	var userID=document.forgotp.lname.value;
	
	if(userID==""){
		alert("Please enter Login Id");
		return false;
	}else{
		document.forgotp.flg.value="sub";
		document.forgotp.submitbtn.disabled=true;
		document.forgotp.action=""
		document.forgotp.submit();
	}
}

function checkAllBoxes(ele){
	var checkboxes = document.getElementsByTagName('input');
    if (ele.checked) {
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].type == 'checkbox') {
                checkboxes[i].checked = true;
            }
        }
    } else {
        for (var i = 0; i < checkboxes.length; i++) {
            console.log(i)
            if (checkboxes[i].type == 'checkbox') {
                checkboxes[i].checked = false;
            }
        }
    }
}

function readUploadedFl(val){
	
	//alert(val);
	document.getElementById("fileName").value=val;
	document.viewsubInv.action="readUploadedFile";
	document.viewsubInv.submit();
	
}

function chkGLDate(obj){
	var val=obj.value;
	var id=obj.id;
    xmlHttp=GetXmlHttpObject()
    if (xmlHttp==null)
    {
      alert ("Browser does not support HTTP Request");
      return;
    }
    var url="getGLDateValid?glDate="+val+"&glid="+id;	    
    xmlHttp.onreadystatechange=stateChangedgetValidGL
    xmlHttp.open("GET",url,true);
    xmlHttp.send(null);
    
}
function stateChangedgetValidGL() 
{ 
	
    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var glData = xmlDoc.getElementsByTagName("glData");
            for (i = 0; i < glData.length ; i++)
            {
            	var glDateValid=glData[i].getElementsByTagName("glDateValid");
            	
            	var validdt=glDateValid[0].firstChild.data;
            	
            	var glDateValidID=glData[i].getElementsByTagName("glDateID");
            	
            	var validid=glDateValidID[0].firstChild.data;
            	
            	if(validdt==0){
            		alert("GL Date is not in Open GL Period");
            		document.getElementById(validid).value="";
            		return false;
            	}
          
			
            }
           
    }
    
}

function getempValue(){
	if(document.getElementById("empchk").checked==true){
		document.getElementById("emphid").style.visibility = "";
		document.getElementById("emphid1").style.visibility = "";
	}else{
		document.getElementById("emphid").style.visibility = "hidden";
		document.getElementById("emphid1").style.visibility = "hidden";
	}
}


function frmDtValid(){
	var frmDt=document.getElementById("frmDate").value;
	var finYear=document.getElementById("finYear").value;
	var toDate=document.getElementById("toDate").value;
	if(frmDt!="" && finYear!=""){
		var textdate1 = frmDt;
		var myArray1 = textdate1.split('-');
		var input1 = myArray1[2] + myArray1[1] + myArray1[0];
		
		var frmYear=finYear.split('-');
		var crtFinYear='1-Apr-20'+frmYear[0];
		
		//alert(crtFinYear);
		
		var sampledate1 = crtFinYear;
		var myArray1 = sampledate1.split('-');
		var target1 = myArray1[2] + myArray1[1] + myArray1[0];
		//alert("target1 ~"+target1);
		//alert("input1 ~"+input1);
		if (Date.parse(input1) < Date.parse(target1)) {
			alert("From Date to be greater than Financial Year");
			document.getElementById("frmDate").value="";
			return false;
		}
		
	}
	if(frmDt!="" && toDate!=""){
		var textdate1 = frmDt;
		var myArray1 = textdate1.split('-');
		var input1 = myArray1[2] + myArray1[1] + myArray1[0];
		
		var sampledate1 = toDate;
		var myArray1 = sampledate1.split('-');
		var target1 = myArray1[2] + myArray1[1] + myArray1[0];
		//alert("target1 ~"+target1);
		//alert("input1 ~"+input1);
		if (Date.parse(target1) < Date.parse(input1)) {
			alert("To date should be greater than From Date");
			document.getElementById("toDate").value="";
			return false;
		}
		
	}
	
	if(finYear==""){
		document.getElementById("frmDate").value="";
		document.getElementById("toDate").value="";
		alert("Please select Financial Year first");
		return false;
	}
}

function getCorrectTax(obj){
	
	var supplierst=document.getElementById("state").value;
	var lineloc=obj.value;
	var lineid=obj.id;
	lineid=lineid.substring(8);
	document.getElementById("taxtype"+lineid).value="select";
	if(supplierst!="" && lineloc!="select"){
	
	xmlHttp=GetXmlHttpObject()
    if (xmlHttp==null)
    {
      alert ("Browser does not support HTTP Request");
      return;
    }
	//alert(lineloc);
	var linelocarr=lineloc.split(",");
	lineloc=linelocarr[1];
	
	//alert(lineloc);
	
    var url="getValidTax?lineloc="+lineloc+"&supplierst="+supplierst+"&lineid="+lineid;	    
    xmlHttp.onreadystatechange=stateChangedgetValidTax
    xmlHttp.open("GET",url,true);
    xmlHttp.send(null);
 } 
}
function stateChangedgetValidTax() 
{  
	
    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    {
    	 var xmlDoc = xmlHttp.responseXML.documentElement;
           var stcode = xmlDoc.getElementsByTagName("stcode");
           
            for (i = 0; i < stcode.length ; i++)
            {
            	var stats=stcode[i].getElementsByTagName("stats");
            	
            	var correcttaxty=stats[0].firstChild.data;
            	
            	var lineids=stcode[i].getElementsByTagName("lineid");
            	
            	var lineid=lineids[0].firstChild.data;
            	
            	if(correcttaxty=="Y"){
            		document.getElementById("taxx").value="cgst";
            		document.getElementById("igst"+lineid).value="";
            		document.getElementById("igst"+lineid).readOnly = true;
            		document.getElementById("igst"+lineid).style.backgroundColor ="#D9D9D1";
            		
            		document.getElementById("cgst"+lineid).value="";
            		document.getElementById("cgst"+lineid).readOnly = false;
            		document.getElementById("cgst"+lineid).style.backgroundColor ="";
            		document.getElementById("sgst"+lineid).value="";
            		document.getElementById("sgst"+lineid).readOnly = false;
            		document.getElementById("sgst"+lineid).style.backgroundColor ="";
            		
            		
            	}else{
            		document.getElementById("taxx").value="igst";
            		document.getElementById("cgst"+lineid).value="";
            		document.getElementById("cgst"+lineid).readOnly = true;
            		document.getElementById("cgst"+lineid).style.backgroundColor ="#D9D9D1";
            		document.getElementById("sgst"+lineid).value="";
            		document.getElementById("sgst"+lineid).readOnly = true;
            		document.getElementById("sgst"+lineid).style.backgroundColor ="#D9D9D1";
            		
            		document.getElementById("igst"+lineid).value="";
            		document.getElementById("igst"+lineid).readOnly = false;
            		document.getElementById("igst"+lineid).style.backgroundColor ="";
            		
            	}
          
			
            }
           
    }
    
}

function gettaxValue(obj,basic,invtype){
	//alert(obj.value+"--"+basic+"--invtype-"+invtype)
	var lineid=obj.id.substring(7);
	//alert(lineid);
	
	var tax=obj.value; 
	basic=roundNumber(basic,0);
	if(tax!="select" && basic!="" && invtype!="" && invtype=="cgst"){
		var totaltax=parseFloat(basic)*parseInt(tax)/(100*2);
		document.getElementById("cgst"+lineid).value=totaltax;
		document.getElementById("sgst"+lineid).value=totaltax;
		
	}if(tax!="select" && basic!="" && invtype!="" && invtype=="igst"){
		var totaltax=basic*tax/100;
		document.getElementById("igst"+lineid).value=totaltax;
	}if(parseFloat(basic)<=0){
		document.getElementById("cgst"+lineid).value=0;
		document.getElementById("sgst"+lineid).value=0;
		document.getElementById("igst"+lineid).value=0;
	}
	
	calculate();
	
}

function gettaxValue1(tax,obj,invtype){
	
	var lineid=obj.id.substring(8);
	//alert(lineid);
	
	var basic=roundNumber(obj.value,0); 
	//alert(basic+"--"+tax);
	if(tax!="select" && basic!="" && invtype!="" && invtype=="cgst"){
		var totaltax=basic*tax/(100*2);
	//	alert(totaltax);
	//	alert(roundNumber(totaltax,0));
		document.getElementById("cgst"+lineid).value=totaltax;
		document.getElementById("sgst"+lineid).value=totaltax;
		
	}if(tax!="select" && basic!="" && invtype!="" && invtype=="igst"){
		var totaltax=basic*tax/100;
		document.getElementById("igst"+lineid).value=totaltax;
	}
	if(parseFloat(basic)<=0){
		document.getElementById("cgst"+lineid).value=0;
		document.getElementById("sgst"+lineid).value=0;
		document.getElementById("igst"+lineid).value=0;
	}
	
	calculate();
}

function checkapplprepay(){
	var invtype=document.getElementById("invtype").value;
	if(invtype=='STANDARD'){
		document.getElementById("prepaySrch").style.visibility="";
		document.getElementById("deductionSrch").style.visibility="";
		document.getElementById("preinvId").value="";
		document.getElementById("dedinvId").value="";
		document.getElementById("totalpreAmt").value="";
		document.getElementById("prepayment").value="";
		document.getElementById("deduction").value="";
		document.getElementById("totaldedAmt").value="";
		var cnter=document.getElementById("prashidCounter").value;
		for(var i=1;i<=cnter;i++){
		document.getElementById("cgst"+i).readOnly = false;
		document.getElementById("cgst"+i).style.backgroundColor ="";
		document.getElementById("sgst"+i).readOnly = false;
		document.getElementById("sgst"+i).style.backgroundColor ="";
		document.getElementById("igst"+i).readOnly = false;
		document.getElementById("igst"+i).style.backgroundColor ="";
		}
	} else if(invtype=='PREPAYMENT'){
		document.getElementById("prepaySrch").style.visibility="";
		document.getElementById("deductionSrch").style.visibility="";
		document.getElementById("preinvId").value="";
		document.getElementById("dedinvId").value="";
		document.getElementById("totalpreAmt").value="";
		document.getElementById("prepayment").value="";
		document.getElementById("deduction").value="";
		document.getElementById("totaldedAmt").value="";
	var cnter=document.getElementById("prashidCounter").value;
		for(var i=1;i<=cnter;i++){
			document.getElementById("cgst"+i).value="";
			document.getElementById("cgst"+i).readOnly = true;
			document.getElementById("cgst"+i).style.backgroundColor ="#D9D9D1";
			
			document.getElementById("igst"+i).value="";
			document.getElementById("igst"+i).readOnly = true;
    		document.getElementById("igst"+i).style.backgroundColor ="#D9D9D1";
    		
    		document.getElementById("sgst"+i).value="";
			document.getElementById("sgst"+i).readOnly = true;
    		document.getElementById("sgst"+i).style.backgroundColor ="#D9D9D1";
		}
	}
	
	else{
		document.getElementById("prepaySrch").style.visibility="hidden";
		document.getElementById("deductionSrch").style.visibility="hidden";
		document.getElementById("preinvId").value="";
		document.getElementById("dedinvId").value="";
		document.getElementById("totalpreAmt").value="";
		document.getElementById("prepayment").value="";
		document.getElementById("deduction").value="";
		document.getElementById("totaldedAmt").value="";
		var cnter=document.getElementById("prashidCounter").value;
		for(var i=1;i<=cnter;i++){
		document.getElementById("cgst"+i).readOnly = false;
		document.getElementById("cgst"+i).style.backgroundColor ="";
		document.getElementById("sgst"+i).readOnly = false;
		document.getElementById("sgst"+i).style.backgroundColor ="";
		document.getElementById("igst"+i).readOnly = false;
		document.getElementById("igst"+i).style.backgroundColor ="";
		}
		
	}
}

function getBaseLocation(loc){
	
	var val=loc.options[loc.selectedIndex].text;
	//alert(val);
	//getElementById("location").value;
	
    xmlHttp=GetXmlHttpObject()
    if (xmlHttp==null)
    {
      alert ("Browser does not support HTTP Request");
      return;
    }
    var url="getBaseLocation?location="+val;	    
    xmlHttp.onreadystatechange=stateChangedgetBaseLocation 
    xmlHttp.open("GET",url,true)
    xmlHttp.send(null)
}
function stateChangedgetBaseLocation() 
{ 
    
    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
    { 
        var xmlDoc = xmlHttp.responseXML.documentElement;
           var supplier = xmlDoc.getElementsByTagName("loca");
          
            for (i = 0; i < supplier.length ; i++)
            {
            	var locaName=supplier[i].getElementsByTagName("baselocv");
            	
            	var optn = document.createElement("OPTION");
            	
            	var locaName=locaName[0].firstChild.data;
            	
            	optn.text=locaName;
            	optn.value = locaName;
    			document.getElementById('baseloc').options.add(optn);
               }
       
    }
}

function checkfrmTodtValid(){
	var frmDt=document.getElementById("frmDate").value;
	var toDate=document.getElementById("toDate").value;
	if(frmDt!="" && toDate!=""){
		var textdate1 = frmDt;
		var myArray1 = textdate1.split('-');
		var input1 = myArray1[2] + myArray1[1] + myArray1[0];
		
		var sampledate1 = toDate;
		var myArray1 = sampledate1.split('-');
		var target1 = myArray1[2] + myArray1[1] + myArray1[0];
		//alert("target1 ~"+target1);
		//alert("input1 ~"+input1);
		if (Date.parse(target1) < Date.parse(input1)) {
			alert("To date should be greater than From Date");
			document.getElementById("toDate").value="";
			return false;
		}
		
	}if(frmDt!="" && toDate==""){
		alert("Please select To Date");
		return false;
	}
	if(frmDt=="" && toDate!=""){
		alert("Please select From Date");
		return false;
	}	
	
}