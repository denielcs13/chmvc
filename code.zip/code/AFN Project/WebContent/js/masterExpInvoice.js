/*var numb = '0123456789';
var lwr = 'abcdefghijklmnopqrstuvwxyz. ';
var upr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ. ';
var fnum = '0123456789.';
var flag = 0;

//To vaidate forms
function isValid(parm, val) {
	if (parm == "") {
		return false;
	}
	for (i = 0; i < parm.length; i++) {
		if (val.indexOf(parm.charAt(i), 0) == -1) {
			return false;
		}
	}
	return true;
}

function checkFloat(obj) {
	if (!isFloat(obj.value) && obj.value != '') {
		alert("Please enter only numbers.");
		obj.focus();		
	}	
	obj.value = roundNumber(obj.value, 2);
	return true;
}

function isFloat(parm) {
	return isValid(parm, fnum);
}*/

var weekday=new Array(7);
	weekday[0]="Sunday";
	weekday[1]="Monday";
	weekday[2]="Tuesday";
	weekday[3]="Wednesday";
	weekday[4]="Thursday";
	weekday[5]="Friday";
	weekday[6]="Saturday";
	

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 46 || charCode > 57 || charCode == 47)  ) {
        return false;
    }
    return true;
}
function checkDec(el){
	if(el.value!=""){
	 var ex = /^[0-9]+\.?[0-9]*$/;
	 if(ex.test(el.value)==false){
	    alert('Incorrect Number');
	    var ido=el.id;
	    document.getElementById(ido).value="";
	  }
	}
}
function getAtt1(val){
	var ido=val.id;
	ido=ido.substring(6);
	var expCat;
	if(val.value=='OutStation Travel')
	document.getElementById('att1se'+ido).length = 1;
	if(val.value=='Entertainment')
		document.getElementById('att1Enter'+ido).length = 1;
	if(val.value=='Food Expense')
		document.getElementById('att1Food'+ido).length = 1;	
	if(val.value=='Local Conveyance')
		document.getElementById('att1localC'+ido).length = 1;
	if(val.value=='Miscellaneous')
		document.getElementById('att1Misce'+ido).length = 1;
	if(val.value=='International Travel')
		document.getElementById('att1seInterN'+ido).length = 1;
	if(val.value=='Combined - Food and conveyance')
		document.getElementById('att1Comb'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	
	 	expCat=val.value;
	
	    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAtt1
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetAtt1() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att1");
	           //alert(dept.length);
	          // var expcat=document.getElementById("expcat1").value;
	           
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var descri=desc[i].getElementsByTagName("expenseAtt1");
	            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var inpParam=desc[i].getElementsByTagName("inpParam");
	            	var expcat=inpParam[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = lokupcode[0].firstChild.data;
	            	optn.text = descri[0].firstChild.data;
	            
	            	if(expcat=='OutStation Travel')
	            		document.getElementById('att1se'+attidval).options.add(optn);  
	            		if(expcat=='Entertainment')
	            			document.getElementById('att1Enter'+attidval).options.add(optn);  
	            		if(expcat=='Food Expense')
	            			document.getElementById('att1Food'+attidval).options.add(optn);  
	            		if(expcat=='Local Conveyance')
	            			document.getElementById('att1localC'+attidval).options.add(optn);  
	            		if(expcat=='Miscellaneous')
	            			document.getElementById('att1Misce'+attidval).options.add(optn);  
	            		if(expcat=='International Travel')
	            			document.getElementById('att1seInterN'+attidval).options.add(optn);  
	            		if(expcat=='Combined - Food and conveyance')
	            			document.getElementById('att1Comb'+attidval).options.add(optn);
				
	            }
	                        
	    }
	    
	}
	
	
function getDropDownFields(val)
{
	document.getElementById('prashidCounter').value=1;
	document.getElementById('gtotal').value='';
	if(val=='OutStation Travel'){
		
		document.getElementById("Outstat").style.display="block";
		document.getElementById("AddRem").style.display="block";
		document.getElementById("FoodExp").style.display="none";
		document.getElementById("Entertain").style.display="none";
		document.getElementById("LocalConv").style.display="none";
		document.getElementById("Misce").style.display="none";
		document.getElementById("InterN").style.display="none";
		document.getElementById("Combine").style.display="none";
	}
	if(val=='Entertainment'){
		
		document.getElementById("Outstat").style.display="none";
		document.getElementById("AddRem").style.display="block";
		document.getElementById("FoodExp").style.display="none";
		document.getElementById("Entertain").style.display="block";
		document.getElementById("LocalConv").style.display="none";
		document.getElementById("Misce").style.display="none";
		document.getElementById("InterN").style.display="none";
		document.getElementById("Combine").style.display="none";
	}
	if(val=='Food Expense'){
		
		document.getElementById("Outstat").style.display="none";
		document.getElementById("AddRem").style.display="block";		
		document.getElementById("Entertain").style.display="none";
		document.getElementById("FoodExp").style.display="block";
		document.getElementById("LocalConv").style.display="none";
		document.getElementById("Misce").style.display="none";
		document.getElementById("InterN").style.display="none";
		document.getElementById("Combine").style.display="none";
	}
	if(val=='Local Conveyance'){
		
		document.getElementById("Outstat").style.display="none";
		document.getElementById("AddRem").style.display="block";		
		document.getElementById("Entertain").style.display="none";
		document.getElementById("FoodExp").style.display="none";
		document.getElementById("LocalConv").style.display="block";
		document.getElementById("Misce").style.display="none";
		document.getElementById("InterN").style.display="none";
		document.getElementById("Combine").style.display="none";
	}
	if(val=='Miscellaneous'){
		
		document.getElementById("Outstat").style.display="none";
		document.getElementById("AddRem").style.display="block";		
		document.getElementById("Entertain").style.display="none";
		document.getElementById("FoodExp").style.display="none";
		document.getElementById("LocalConv").style.display="none";
		document.getElementById("Misce").style.display="block";
		document.getElementById("InterN").style.display="none";
		document.getElementById("Combine").style.display="none";
	}
	if(val=='International Travel'){
		
		document.getElementById("Outstat").style.display="none";
		document.getElementById("AddRem").style.display="block";		
		document.getElementById("Entertain").style.display="none";
		document.getElementById("FoodExp").style.display="none";
		document.getElementById("LocalConv").style.display="none";
		document.getElementById("Misce").style.display="none";
		document.getElementById("InterN").style.display="block";
		document.getElementById("Combine").style.display="none";
	}
	if(val=='Combined - Food and conveyance'){
		
		document.getElementById("Outstat").style.display="none";
		document.getElementById("AddRem").style.display="block";		
		document.getElementById("Entertain").style.display="none";
		document.getElementById("FoodExp").style.display="none";
		document.getElementById("LocalConv").style.display="none";
		document.getElementById("Misce").style.display="none";
		document.getElementById("InterN").style.display="none";
		document.getElementById("Combine").style.display="block";
	}
	
	}
	
	
function getfieldDtls(val){
		
	var ido=val.id;
	ido=ido.substring(6);
	
	//var expcat=document.getElementById("expcat1").value;
	document.getElementById('total'+ido).value='';
	if(document.getElementById('prashidCounter').value==1)	document.getElementById('gtotal').value='';
	if(val.value=='CONVEYNACE_AMOUNT'){
		document.getElementById("arratbase"+ido).style.backgroundColor ="";
		document.getElementById("arratbase"+ido).readOnly = false;
		document.getElementById("arratbase"+ido).value="";
			
		document.getElementById("ticket"+ido).style.backgroundColor ="";
		document.getElementById("ticket"+ido).readOnly = false;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("totaltTym"+ido).value="";
		document.getElementById("totaltTym"+ido).readOnly = false;
		document.getElementById("totaltTym"+ido).style.backgroundColor =""; 
		
		document.getElementById("aPM"+ido).value="";
		document.getElementById("aPM"+ido).disabled = false;
		document.getElementById("aPM"+ido).style.backgroundColor =""; 
		
		
		document.getElementById("motrans"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("motrans"+ido).disabled = true;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = true;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = true;
		document.getElementById("taxhotelch"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = true;
		document.getElementById("breakFast"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = true;
		document.getElementById("lunch"+ido).style.backgroundColor ="#D9D9D1";
		
		
		document.getElementById("rpk"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("rpk"+ido).readOnly = true;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("totalkm"+ido).readOnly = true;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("convAmt"+ido).readOnly = true;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = true;
		document.getElementById("dinner"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = true;
		document.getElementById("abaAmt"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = true;
		document.getElementById("others"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("tollPark"+ido).readOnly = true;
		document.getElementById("tollPark"+ido).value="";
		
		
	}else if(val.value=='OUTSTATION_TRAVEL'){
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = false;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = false;
		document.getElementById("taxhotelch"+ido).style.backgroundColor =""; 
		
		document.getElementById("arratbase"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("arratbase"+ido).readOnly = true;
		document.getElementById("arratbase"+ido).value="";
		
		document.getElementById("motrans"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("motrans"+ido).disabled = true;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("ticket"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("ticket"+ido).readOnly = true;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("rpk"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("rpk"+ido).readOnly = true;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("totalkm"+ido).readOnly = true;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("convAmt"+ido).readOnly = true;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = true;
		document.getElementById("breakFast"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = true;
		document.getElementById("lunch"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = true;
		document.getElementById("dinner"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = true;
		document.getElementById("abaAmt"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = true;
		document.getElementById("others"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("totaltTym"+ido).value="";
		document.getElementById("totaltTym"+ido).readOnly = true;
		document.getElementById("totaltTym"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("aPM"+ido).value="";
		document.getElementById("aPM"+ido).disabled = true;
		document.getElementById("aPM"+ido).style.backgroundColor ="#D9D9D1";
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("tollPark"+ido).readOnly = true;
		document.getElementById("tollPark"+ido).value="";
		
	}
	else if(val.value=='FOOD_EXPENSE_DURING_TRAVEL'){
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = false;
		document.getElementById("breakFast"+ido).style.backgroundColor ="";  
		
		document.getElementById("arratbase"+ido).style.backgroundColor ="";
		document.getElementById("arratbase"+ido).readOnly = false;
		document.getElementById("arratbase"+ido).value="";
		
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = false;
		document.getElementById("lunch"+ido).style.backgroundColor ="";  
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = false;
		document.getElementById("dinner"+ido).style.backgroundColor =""; 
		
		document.getElementById("totaltTym"+ido).value="";
		document.getElementById("totaltTym"+ido).readOnly = false;
		document.getElementById("totaltTym"+ido).style.backgroundColor =""; 
		
		document.getElementById("aPM"+ido).value="";
		document.getElementById("aPM"+ido).disabled = false;
		document.getElementById("aPM"+ido).style.backgroundColor =""; 
		
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = true;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = true;
		document.getElementById("taxhotelch"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("motrans"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("motrans"+ido).disabled = true;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("ticket"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("ticket"+ido).readOnly = true;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("rpk"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("rpk"+ido).readOnly = true;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("totalkm"+ido).readOnly = true;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("convAmt"+ido).readOnly = true;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = true;
		document.getElementById("abaAmt"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = true;
		document.getElementById("others"+ido).style.backgroundColor ="#D9D9D1";
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("tollPark"+ido).readOnly = true;
		document.getElementById("tollPark"+ido).value="";		
		
		
	}else if(val.value=='LOCAL_CONVEYANCE'){
		document.getElementById("motrans"+ido).style.backgroundColor ="";
		document.getElementById("motrans"+ido).disabled = false;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("rpk"+ido).style.backgroundColor ="";
		document.getElementById("rpk"+ido).readOnly = false;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("arratbase"+ido).style.backgroundColor ="";
		document.getElementById("arratbase"+ido).readOnly = false;
		document.getElementById("arratbase"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="";
		document.getElementById("totalkm"+ido).readOnly = false;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="";
		document.getElementById("convAmt"+ido).readOnly = false;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="";
		document.getElementById("tollPark"+ido).readOnly = false;
		document.getElementById("tollPark"+ido).value="";
		
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = true;
		document.getElementById("breakFast"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = true;
		document.getElementById("lunch"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = true;
		document.getElementById("dinner"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = true;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = true;
		document.getElementById("taxhotelch"+ido).style.backgroundColor ="#D9D9D1"; 
		
		
		document.getElementById("ticket"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("ticket"+ido).readOnly = true;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = true;
		document.getElementById("abaAmt"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = true;
		document.getElementById("others"+ido).style.backgroundColor ="#D9D9D1";
		
	}
	else if(val.value=='ADDITIONAL_BOARDING_ALLOWANCE'){
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = false;
		document.getElementById("abaAmt"+ido).style.backgroundColor =""; 
		
		document.getElementById("arratbase"+ido).style.backgroundColor ="";
		document.getElementById("arratbase"+ido).readOnly = false;
		document.getElementById("arratbase"+ido).value="";
		
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = true;
		document.getElementById("breakFast"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = true;
		document.getElementById("lunch"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = true;
		document.getElementById("dinner"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = true;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = true;
		document.getElementById("taxhotelch"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("motrans"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("motrans"+ido).disabled = true;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("ticket"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("ticket"+ido).readOnly = true;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("rpk"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("rpk"+ido).readOnly = true;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("totalkm"+ido).readOnly = true;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("convAmt"+ido).readOnly = true;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = true;
		document.getElementById("others"+ido).style.backgroundColor ="#D9D9D1";
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("tollPark"+ido).readOnly = true;
		document.getElementById("tollPark"+ido).value="";
		
		
	}
	else if(val.value=='OTHERS_1'){
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = false;
		document.getElementById("others"+ido).style.backgroundColor ="";
		
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = true;
		document.getElementById("abaAmt"+ido).style.backgroundColor ="#D9D9D1"; 
		
		
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = true;
		document.getElementById("breakFast"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = true;
		document.getElementById("lunch"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = true;
		document.getElementById("dinner"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = true;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = true;
		document.getElementById("taxhotelch"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("arratbase"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("arratbase"+ido).readOnly = true;
		document.getElementById("arratbase"+ido).value="";
		
		document.getElementById("motrans"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("motrans"+ido).disabled = true;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("ticket"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("ticket"+ido).readOnly = true;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("rpk"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("rpk"+ido).readOnly = true;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("totalkm"+ido).readOnly = true;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("convAmt"+ido).readOnly = true;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("totaltTym"+ido).value="";
		document.getElementById("totaltTym"+ido).readOnly = true;
		document.getElementById("totaltTym"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("aPM"+ido).value="";
		document.getElementById("aPM"+ido).disabled = true;
		document.getElementById("aPM"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("tollPark"+ido).readOnly = true;
		document.getElementById("tollPark"+ido).value="";
	}
	
	else if(val.value=='TAXI EXPENSE'){
		document.getElementById("arratbase"+ido).style.backgroundColor ="";
		document.getElementById("arratbase"+ido).readOnly = false;
		document.getElementById("arratbase"+ido).value="";
			
		document.getElementById("ticket"+ido).style.backgroundColor ="";
		document.getElementById("ticket"+ido).readOnly = false;
		document.getElementById("ticket"+ido).value="";
		
		document.getElementById("totaltTym"+ido).value="";
		document.getElementById("totaltTym"+ido).readOnly = false;
		document.getElementById("totaltTym"+ido).style.backgroundColor =""; 
		
		document.getElementById("aPM"+ido).value="";
		document.getElementById("aPM"+ido).disabled = false;
		document.getElementById("aPM"+ido).style.backgroundColor =""; 
		
		
		document.getElementById("motrans"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("motrans"+ido).disabled = true;
		document.getElementById("motrans"+ido).value="";
		
		document.getElementById("hotelchramt"+ido).value="";
		document.getElementById("hotelchramt"+ido).readOnly = true;
		document.getElementById("hotelchramt"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("taxhotelch"+ido).value="";
		document.getElementById("taxhotelch"+ido).readOnly = true;
		document.getElementById("taxhotelch"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("breakFast"+ido).value="";
		document.getElementById("breakFast"+ido).readOnly = true;
		document.getElementById("breakFast"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("lunch"+ido).value="";
		document.getElementById("lunch"+ido).readOnly = true;
		document.getElementById("lunch"+ido).style.backgroundColor ="#D9D9D1";
		
		
		document.getElementById("rpk"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("rpk"+ido).readOnly = true;
		document.getElementById("rpk"+ido).value="";
		
		document.getElementById("totalkm"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("totalkm"+ido).readOnly = true;
		document.getElementById("totalkm"+ido).value="";
		
		document.getElementById("convAmt"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("convAmt"+ido).readOnly = true;
		document.getElementById("convAmt"+ido).value="";
		
		document.getElementById("dinner"+ido).value="";
		document.getElementById("dinner"+ido).readOnly = true;
		document.getElementById("dinner"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("abaAmt"+ido).value="";
		document.getElementById("abaAmt"+ido).disabled = true;
		document.getElementById("abaAmt"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("others"+ido).value="";
		document.getElementById("others"+ido).readOnly = true;
		document.getElementById("others"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("tollPark"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("tollPark"+ido).readOnly = true;
		document.getElementById("tollPark"+ido).value="";
		
		
	}
	getAtt4(ido);
	//getTravelTo(ido);
	/*if(val.value=='CONVEYNACE_AMOUNT')
	getModeOfTransport(val);*/
}

function getAtt4(val){
	//alert(val);
		var ido=val;
		document.getElementById('transMode'+ido).length = 1;
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat='OutStation Travel';
		    var url="getAttribute4Val?expCat="+expCat+"&id="+ido;
		   // alert(url);
		    xmlHttp.onreadystatechange=stateChangedgetAtt4
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		
	}	 
		function stateChangedgetAtt4() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att2");
		           //alert(dept.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = glCode[0].firstChild.data;
		            	optn.text = glCode[0].firstChild.data;
		            	document.getElementById('transMode'+attidval).options.add(optn);
		          
		            }
		            //var attrib=document.getElementById("att1se"+attidval);
		            getTravelTo(attidval);  
		    }
		    
		}	

function getTravelTo(val){
	var ido=val;
	//.id;
	//ido=ido.substring(6);
	
	document.getElementById('travelto'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat=document.getElementById("expcat1").value;
	    var url="gettravelToVal?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAtt2
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetAtt2() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	            	//var categ=desc[i].getElementsByTagName("cat");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            //	var optn1 = document.createElement("OPTION");
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	            //	optn1.value = categ[0].firstChild.data;
	            //	optn1.text = categ[0].firstChild.data;
	            	
	           	document.getElementById('travelto'+attidval).options.add(optn);	
	           //	document.getElementById('cityClass'+attidval).options.add(optn1);	
	            }
	          //  var expcat=document.getElementById("expcat1");
	            gettravelEOD(attidval);          
	    }
	    
}
	
	function gettravelEOD(val){
		var ido=val/*.id;
		ido=ido.substring(6)*/;
				document.getElementById('traveleod'+ido).length = 1;
					
				 xmlHttp=GetXmlHttpObject()
				    if (xmlHttp==null)
				    {
				      alert ("Browser does not support HTTP Request");
				      return;
				    }
				 var expCat="OutStation Travel";				 
				    var url="getAttribute3Val?expCat="+expCat+"&id="+ido;	
				    //alert(url);
				    xmlHttp.onreadystatechange=stateChangedgetAtt3
				    xmlHttp.open("GET",url,true);
				    xmlHttp.send(null);
				
			}	 
	function stateChangedgetAtt3() 
				{ 
					
				    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
				    { 
				    	 //alert(xmlHttp.responseXML);
				    	
				    	 var xmlDoc = xmlHttp.responseXML.documentElement;
				           var desc = xmlDoc.getElementsByTagName("att2");
				           //alert(dept.length);
				            for (i = 0; i < desc.length ; i++)
				            {
				            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
				            	var attid=desc[i].getElementsByTagName("ids");
				            	var attidval=attid[0].firstChild.data;
				            	
				            	var optn = document.createElement("OPTION");
				            	
				            	optn.value = glCode[0].firstChild.data;
				            	optn.text = glCode[0].firstChild.data;
				           	document.getElementById('traveleod'+attidval).options.add(optn);							
				            }
				          var attrib=document.getElementById("att1se"+attidval);
				          getModeOfTransport(attrib);
				    }
				    
				}
	
function getModeOfTransport(val){
	var ido=val.id;
	ido=ido.substring(6);
	//alert(val.value);
	if(val.value=='CONVEYNACE_AMOUNT'){
	
	document.getElementById('motrans'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat=document.getElementById("expcat1").value;
	    var url="getModeOfTransportVal?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetModeOfTransport
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	}else if(val.value=='LOCAL_CONVEYANCE'){
		document.getElementById('motrans'+ido).length = 1;
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat=document.getElementById("expcat1").value;
		 var url="getAttribute7Val?expCat="+expCat+"&id="+ido;		    
		 xmlHttp.onreadystatechange=stateChangedgetAtt7
		xmlHttp.open("GET",url,true);
		xmlHttp.send(null);
	}else{	}
}	 
	function stateChangedgetModeOfTransport() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("motrans");
	           //alert(desc.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("motransval");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	            	document.getElementById('motrans'+attidval).options.add(optn);				
	            }
	             
	    }
	    
}
	
function getCityClass(val){
	
	var ido=val.id;
	ido=ido.substring(8);
	document.getElementById('cityClass'+ido).length = 1;
	document.getElementById('hotelchramt'+ido).value='';
	document.getElementById('total'+ido).value='';
	document.getElementById('gtotal').value='';		     
	
	xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var trvlTo=val.value;
	    var url="getcityClVal?trvlTo="+trvlTo+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAttCity2
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetAttCity2() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var categ=desc[i].getElementsByTagName("cat");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	          
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = categ[0].firstChild.data;
	            	optn.text = categ[0].firstChild.data;
	            	
	           		
	           	document.getElementById('cityClass'+attidval).options.add(optn);	
	            }
	                    
	    }
	    
	
}
	
function stateChangedgetAtt7() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
{ 
	 //alert(xmlHttp.responseXML);
	
	 var xmlDoc = xmlHttp.responseXML.documentElement;
       var desc = xmlDoc.getElementsByTagName("att2");
       //alert(dept.length);
        for (i = 0; i < desc.length ; i++)
        {
        	var glCode=desc[i].getElementsByTagName("expenseAtt2");
        	var attid=desc[i].getElementsByTagName("ids");
        	var attidval=attid[0].firstChild.data;
        	
        	var optn = document.createElement("OPTION");
        	
        	optn.value = glCode[0].firstChild.data;
        	optn.text = glCode[0].firstChild.data;
        	document.getElementById('motrans'+attidval).options.add(optn);
      
		
        }
       
    }
    
}	

function getInterfieldDtls(val){
	
	var ido=val.id;
	ido=ido.substring(12);	
	
	if(val.value=='TAXI_CHARGES'){
		document.getElementById("currNmInterN"+ido).style.backgroundColor ="";
		document.getElementById("currNmInterN"+ido).readOnly = false;
		document.getElementById("currNmInterN"+ido).value="";
		
		document.getElementById("excRtInterN"+ido).style.backgroundColor ="";
		document.getElementById("excRtInterN"+ido).readOnly = true;
		document.getElementById("excRtInterN"+ido).value="";
		
		document.getElementById("taxichrInterN"+ido).style.backgroundColor ="";
		document.getElementById("taxichrInterN"+ido).readOnly = true;
		document.getElementById("taxichrInterN"+ido).value="";
		
		document.getElementById("taxichrFInterN"+ido).style.backgroundColor ="";
		document.getElementById("taxichrFInterN"+ido).readOnly = false;
		document.getElementById("taxichrFInterN"+ido).value="";
		
		document.getElementById("arratbaseInterN"+ido).style.backgroundColor ="";
		document.getElementById("arratbaseInterN"+ido).readOnly = false;
		document.getElementById("arratbaseInterN"+ido).value="";
		
		document.getElementById("perDiemInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("perDiemInterN"+ido).readOnly = true;
		document.getElementById("perDiemInterN"+ido).value="";
		
		document.getElementById("perDiemINRInterN"+ido).value="";
		document.getElementById("perDiemINRInterN"+ido).readOnly = true;
		document.getElementById("perDiemINRInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotlTaxInterN"+ido).value="";
		document.getElementById("hotlTaxInterN"+ido).readOnly = true;
		document.getElementById("hotlTaxInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotelchrInterN"+ido).value="";
		document.getElementById("hotelchrInterN"+ido).readOnly = true;
		document.getElementById("hotelchrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrFInterN"+ido).value="";
		document.getElementById("buschrFInterN"+ido).readOnly = true;
		document.getElementById("buschrFInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrInterN"+ido).value="";
		document.getElementById("buschrInterN"+ido).readOnly = true;
		document.getElementById("buschrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("othersFAmtInterN"+ido).value="";
		document.getElementById("othersFAmtInterN"+ido).readOnly = true;
		document.getElementById("othersFAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("othersAmtInterN"+ido).value="";
		document.getElementById("othersAmtInterN"+ido).readOnly = true;
		document.getElementById("othersAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 
		
						
	}else if(val.value=='OTHERS_2'){
		document.getElementById("currNmInterN"+ido).style.backgroundColor ="";
		document.getElementById("currNmInterN"+ido).readOnly = false;
		document.getElementById("currNmInterN"+ido).value="";
		
		document.getElementById("excRtInterN"+ido).style.backgroundColor ="";
		document.getElementById("excRtInterN"+ido).readOnly = true;
		document.getElementById("excRtInterN"+ido).value="";
		
		document.getElementById("arratbaseInterN"+ido).style.backgroundColor ="";
		document.getElementById("arratbaseInterN"+ido).readOnly = false;
		document.getElementById("arratbaseInterN"+ido).value="";
		
		document.getElementById("taxichrInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrInterN"+ido).readOnly = true;
		document.getElementById("taxichrInterN"+ido).value="";
		
		document.getElementById("taxichrFInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrFInterN"+ido).readOnly = true;
		document.getElementById("taxichrFInterN"+ido).value="";
		
		document.getElementById("perDiemInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("perDiemInterN"+ido).readOnly = true;
		document.getElementById("perDiemInterN"+ido).value="";
		
		document.getElementById("perDiemINRInterN"+ido).value="";
		document.getElementById("perDiemINRInterN"+ido).readOnly = true;
		document.getElementById("perDiemINRInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotlTaxInterN"+ido).value="";
		document.getElementById("hotlTaxInterN"+ido).readOnly = true;
		document.getElementById("hotlTaxInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotelchrInterN"+ido).value="";
		document.getElementById("hotelchrInterN"+ido).readOnly = true;
		document.getElementById("hotelchrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrFInterN"+ido).value="";
		document.getElementById("buschrFInterN"+ido).readOnly = true;
		document.getElementById("buschrFInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrInterN"+ido).value="";
		document.getElementById("buschrInterN"+ido).readOnly = true;
		document.getElementById("buschrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("othersFAmtInterN"+ido).value="";
		document.getElementById("othersFAmtInterN"+ido).readOnly = false;
		document.getElementById("othersFAmtInterN"+ido).style.backgroundColor =""; 
		
		document.getElementById("othersAmtInterN"+ido).value="";
		document.getElementById("othersAmtInterN"+ido).readOnly = true;
		document.getElementById("othersAmtInterN"+ido).style.backgroundColor =""; 
		
		
		
	}
	else if(val.value=='FIXED_ALLOWANCE'){
		document.getElementById("currNmInterN"+ido).style.backgroundColor ="";
		document.getElementById("currNmInterN"+ido).readOnly = false;
		document.getElementById("currNmInterN"+ido).value="";
		
		document.getElementById("excRtInterN"+ido).style.backgroundColor ="";
		document.getElementById("excRtInterN"+ido).readOnly = true;
		document.getElementById("excRtInterN"+ido).value="";
		
		document.getElementById("taxichrInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrInterN"+ido).readOnly = true;
		document.getElementById("taxichrInterN"+ido).value="";
		
		document.getElementById("taxichrFInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrFInterN"+ido).readOnly = true;
		document.getElementById("taxichrFInterN"+ido).value="";
		
		document.getElementById("arratbaseInterN"+ido).style.backgroundColor ="";
		document.getElementById("arratbaseInterN"+ido).readOnly = false;
		document.getElementById("arratbaseInterN"+ido).value="";
		
		document.getElementById("perDiemInterN"+ido).style.backgroundColor ="";
		document.getElementById("perDiemInterN"+ido).readOnly = false;
		document.getElementById("perDiemInterN"+ido).value="";
		
		document.getElementById("perDiemINRInterN"+ido).value="";
		document.getElementById("perDiemINRInterN"+ido).readOnly = true;
		document.getElementById("perDiemINRInterN"+ido).style.backgroundColor ="";  
		
		document.getElementById("hotlTaxInterN"+ido).value="";
		document.getElementById("hotlTaxInterN"+ido).readOnly = true;
		document.getElementById("hotlTaxInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotelchrInterN"+ido).value="";
		document.getElementById("hotelchrInterN"+ido).readOnly = true;
		document.getElementById("hotelchrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrFInterN"+ido).value="";
		document.getElementById("buschrFInterN"+ido).readOnly = true;
		document.getElementById("buschrFInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrInterN"+ido).value="";
		document.getElementById("buschrInterN"+ido).readOnly = true;
		document.getElementById("buschrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("othersFAmtInterN"+ido).value="";
		document.getElementById("othersFAmtInterN"+ido).readOnly = true;
		document.getElementById("othersFAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("othersAmtInterN"+ido).value="";
		document.getElementById("othersAmtInterN"+ido).readOnly = true;
		document.getElementById("othersAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 

		
		
	}else if(val.value=='TICKET_CHARGES'){
		document.getElementById("currNmInterN"+ido).style.backgroundColor ="";
		document.getElementById("currNmInterN"+ido).readOnly = false;
		document.getElementById("currNmInterN"+ido).value="";
		
		document.getElementById("excRtInterN"+ido).style.backgroundColor ="";
		document.getElementById("excRtInterN"+ido).readOnly = true;
		document.getElementById("excRtInterN"+ido).value="";
		
		document.getElementById("arratbaseInterN"+ido).style.backgroundColor ="";
		document.getElementById("arratbaseInterN"+ido).readOnly = false;
		document.getElementById("arratbaseInterN"+ido).value="";
		
		document.getElementById("taxichrInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrInterN"+ido).readOnly = true;
		document.getElementById("taxichrInterN"+ido).value="";
		
		document.getElementById("taxichrFInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrFInterN"+ido).readOnly = true;
		document.getElementById("taxichrFInterN"+ido).value="";
		
		
		document.getElementById("perDiemInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("perDiemInterN"+ido).readOnly = true;
		document.getElementById("perDiemInterN"+ido).value="";
		
		document.getElementById("perDiemINRInterN"+ido).value="";
		document.getElementById("perDiemINRInterN"+ido).readOnly = true;
		document.getElementById("perDiemINRInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotlTaxInterN"+ido).value="";
		document.getElementById("hotlTaxInterN"+ido).readOnly = true;
		document.getElementById("hotlTaxInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotelchrInterN"+ido).value="";
		document.getElementById("hotelchrInterN"+ido).readOnly = true;
		document.getElementById("hotelchrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrFInterN"+ido).value="";
		document.getElementById("buschrFInterN"+ido).readOnly = false;
		document.getElementById("buschrFInterN"+ido).style.backgroundColor ="";  
		
		document.getElementById("buschrInterN"+ido).value="";
		document.getElementById("buschrInterN"+ido).readOnly = true;
		document.getElementById("buschrInterN"+ido).style.backgroundColor ="";  
		
		document.getElementById("othersFAmtInterN"+ido).value="";
		document.getElementById("othersFAmtInterN"+ido).readOnly = true;
		document.getElementById("othersFAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("othersAmtInterN"+ido).value="";
		document.getElementById("othersAmtInterN"+ido).readOnly = true;
		document.getElementById("othersAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 

		
	}
	else if(val.value=='HOTEL_CHARGES'){
		
		document.getElementById("currNmInterN"+ido).style.backgroundColor ="";
		document.getElementById("currNmInterN"+ido).readOnly = false;
		document.getElementById("currNmInterN"+ido).value="";
		
		document.getElementById("excRtInterN"+ido).style.backgroundColor ="";
		document.getElementById("excRtInterN"+ido).readOnly = true;
		document.getElementById("excRtInterN"+ido).value="";		

		document.getElementById("arratbaseInterN"+ido).style.backgroundColor ="";
		document.getElementById("arratbaseInterN"+ido).readOnly = false;
		document.getElementById("arratbaseInterN"+ido).value="";
		
		document.getElementById("taxichrInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrInterN"+ido).readOnly = true;
		document.getElementById("taxichrInterN"+ido).value="";
		
		document.getElementById("taxichrFInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("taxichrFInterN"+ido).readOnly = true;
		document.getElementById("taxichrFInterN"+ido).value="";
				
		document.getElementById("perDiemInterN"+ido).style.backgroundColor ="#D9D9D1";
		document.getElementById("perDiemInterN"+ido).readOnly = true;
		document.getElementById("perDiemInterN"+ido).value="";
		
		document.getElementById("perDiemINRInterN"+ido).value="";
		document.getElementById("perDiemINRInterN"+ido).readOnly = true;
		document.getElementById("perDiemINRInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("hotlTaxInterN"+ido).value="";
		document.getElementById("hotlTaxInterN"+ido).readOnly = false;
		document.getElementById("hotlTaxInterN"+ido).style.backgroundColor ="";  
		
		document.getElementById("hotelchrInterN"+ido).value="";
		document.getElementById("hotelchrInterN"+ido).readOnly = true;
		document.getElementById("hotelchrInterN"+ido).style.backgroundColor ="";  
		
		document.getElementById("buschrFInterN"+ido).value="";
		document.getElementById("buschrFInterN"+ido).readOnly = true;
		document.getElementById("buschrFInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("buschrInterN"+ido).value="";
		document.getElementById("buschrInterN"+ido).readOnly = true;
		document.getElementById("buschrInterN"+ido).style.backgroundColor ="#D9D9D1";  
		
		document.getElementById("othersFAmtInterN"+ido).value="";
		document.getElementById("othersFAmtInterN"+ido).readOnly = true;
		document.getElementById("othersFAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 
		
		document.getElementById("othersAmtInterN"+ido).value="";
		document.getElementById("othersAmtInterN"+ido).readOnly = true;
		document.getElementById("othersAmtInterN"+ido).style.backgroundColor ="#D9D9D1"; 

		
	}
	
	getTripFor(ido);
	
} 

function getTripFor(val){
	var ido=val;
			document.getElementById('tripForInterN'+ido).length = 1;
				
			 xmlHttp=GetXmlHttpObject()
			    if (xmlHttp==null)
			    {
			      alert ("Browser does not support HTTP Request");
			      return;
			    }
			 var expCat="International Travel";			 
			    var url="getAttribute3Val?expCat="+expCat+"&id="+ido;	
			    xmlHttp.onreadystatechange=stateChangedgetTripFor
			    xmlHttp.open("GET",url,true);
			    xmlHttp.send(null);
			
		}	 
function stateChangedgetTripFor() 
			{ 
				
			    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
			    { 
			    	 //alert(xmlHttp.responseXML);
			    	var attidval;
			    	 var xmlDoc = xmlHttp.responseXML.documentElement;
			           var desc = xmlDoc.getElementsByTagName("att2");
			           //alert(dept.length);
			            for (i = 0; i < desc.length ; i++)
			            {
			            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
			            	var attid=desc[i].getElementsByTagName("ids");
			            	 attidval=attid[0].firstChild.data;
			            	
			            	var optn = document.createElement("OPTION");
			            	
			            	optn.value = glCode[0].firstChild.data;
			            	optn.text = glCode[0].firstChild.data;
			           	document.getElementById('tripForInterN'+attidval).options.add(optn);							
			            }
			            
			            getscenerio(attidval);
			    }
			    
			}

function getscenerio(val){
	var ido=val;
		document.getElementById('sceneInterN'+ido).length = 1;
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat="International Travel";
		    var url="getAttribute5Val?expCat="+expCat+"&id="+ido;	    
		    xmlHttp.onreadystatechange=stateChangedgetscenerio
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		
	}	 
		function stateChangedgetscenerio() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	var attidval;
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att2");
		           //alert(dept.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	 attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = glCode[0].firstChild.data;
		            	optn.text = glCode[0].firstChild.data;
		            	document.getElementById('sceneInterN'+attidval).options.add(optn);
		          
					
		            }		           
		            gettraveleodInter(attidval);
		    }
		    
		}
		
function gettraveleodInter(val){
	var ido=val;
	document.getElementById('traveleodInterN'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat="International Travel";
	    var url="getAttribute2Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgettraveleod
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgettraveleod() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	           	document.getElementById('traveleodInterN'+attidval).options.add(optn);
	          }
	            getcurrenNMInter(attidval);       
	    }
	    
}

function getcurrenNMInter(val){
	var ido=val;
	document.getElementById('currNmInterN'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat="International Travel";
	    var url="getCurrNmVal?id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetcurrNm
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetcurrNm() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("cat");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	           	document.getElementById('currNmInterN'+attidval).options.add(optn);
	          }
	             
	    }
}	
function addRow(){
	//alert("A");
	var prashidCounter = document.masterInvExp.prashidCounter.value;
	/*if (document.getElementById('description' + prashidCounter).value == 'select' || document.getElementById('product' + prashidCounter).value == 'select'
		|| document.getElementById('department' + prashidCounter).value == 'select' || document.getElementById('basicAmt' + prashidCounter).value == '' 
		|| document.getElementById('cgst' + prashidCounter).value == '' || document.getElementById('gross' + prashidCounter).value == '' 	
	)  {
		alert("Please fill the last row first.");
		return false;
	}
	
	if (document.createinv.ch.length == undefined) {
		document.createinv.ch.disabled = false;
	}
	if (document.createinv.ch.length == 1) {
		document.createinv.ch[0].disabled = false;
	}*/
	prashidCounter = parseInt(prashidCounter) + 1;
	document.masterInvExp.prashidCounter.value = prashidCounter;
	//alert(document.getElementById('innerTable').tBodies[0]);
	
	
if(document.masterInvExp.expCat.value=="OutStation Travel"){
	//document.getElementById("expCatAll").disabled=true;
	var tblBody = document.getElementById('innerTable').tBodies[0];
	var slrow = document.getElementById("thirdrowf");
	//var extrarow=document.getElementById("trrow");	
	var newline = slrow.cloneNode(false);
	
	var newline00 = slrow.cells[0].cloneNode(false);
	newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
			+ '" id="lno' + prashidCounter + '" size="1" name="lno" />';
	newline.appendChild(newline00);
	
	var newline01 = slrow.cells[1].cloneNode(false);
	newline01.innerHTML = '<input type="text"  value="" id="invno' + prashidCounter + '" size="10" style="display: none;"/>';
	newline.appendChild(newline01);
	
	var newline02 = slrow.cells[2].cloneNode(false);
	newline02.innerHTML = '<input type="text"  value="" id="invoiceDate' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDate'+prashidCounter+'","ddmmmyyyy","","") style="display: none;" />';
	newline.appendChild(newline02);
	
	var newline03 = slrow.cells[3].cloneNode(false);
	newline03.innerHTML = '<select name="description'+ prashidCounter + '" style="width: 98%" id="description'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
	var newdeptselect = newline03.getElementsByTagName('select');
	newdeptselect.id = 'description' + prashidCounter;
	newline.appendChild(newline03);
	
	var newline04 = slrow.cells[4].cloneNode(false);
	newline04.innerHTML = '<select name="att1se'+ prashidCounter + '" style="width: 98%" id="att1se'+ prashidCounter + '" onchange="getfieldDtls(this)" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
	var newproductselect = newline04.getElementsByTagName('select');
	newproductselect.id = 'att1se' + prashidCounter;
	newline.appendChild(newline04);
	
	var newline05 = slrow.cells[5].cloneNode(false);
	newline05.innerHTML = '<input type="text"  value="" id="dotravel' + prashidCounter + '" size="8"  readonly="readonly" onclick=javascript:NewCal("dotravel'+prashidCounter+'","ddmmmyyyy","","") onblur ="getDayFol(this);" />';
	newline.appendChild(newline05);
	
	var newline06 = slrow.cells[6].cloneNode(false);
	/*newline06.innerHTML = '<select name="day'+ prashidCounter + '" style="width: 98%" id="day'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
	var newlocaselect = newline06.getElementsByTagName('select');
	newlocaselect.id = 'day' + prashidCounter;*/
	newline06.innerHTML = '<input type="text" value="" id="day' + prashidCounter + '" size="8"/>';
	newline.appendChild(newline06);
	
	var newline07 = slrow.cells[7].cloneNode(false);
	newline07.innerHTML = '<input type="text" value="" id="travelstime' + prashidCounter + '" size="8" onchange="validateHhMm(this);"/>';
	newline.appendChild(newline07);

	var newline08 = slrow.cells[8].cloneNode(false);
	newline08.innerHTML = '<select name="amPM'+ prashidCounter + '" style="width: 98%" id="amPM'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option><option value="AM"> AM</option><option value="PM"> PM</option><option value="MidNight"> MidNight</option></select>';
	var newproductselect = newline08.getElementsByTagName('select');
	newproductselect.id = 'amPM' + prashidCounter;
	newline.appendChild(newline08);
	
	var newline09 = slrow.cells[9].cloneNode(false);
	//newline09.innerHTML = '<input type="text" value="" id="transMode' + prashidCounter + '" size="5"/>';
	newline09.innerHTML = '<select name="transMode'+ prashidCounter + '" style="width: 98%" id="transMode'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="airAlert(this);"> <option value="select">--Select--</option></select>';
	var newtransModeselect = newline09.getElementsByTagName('select');
	newtransModeselect.id = 'transMode' + prashidCounter;
	newline.appendChild(newline09);

	var newline10 = slrow.cells[10].cloneNode(false);
	newline10.innerHTML = '<input type="text" value="" id="coTravelNm' + prashidCounter + '" size="5"/>';
	newline.appendChild(newline10);
	
	var newline11 = slrow.cells[11].cloneNode(false);
	/*newline08.innerHTML = '<select name="departfrm'+ prashidCounter + '" id="departfrm'+ prashidCounter + '" ><option value="select">--Select--</option></select>';
	var newtaxtypeselect = newline08.getElementsByTagName('select');
	newtaxtypeselect.id = 'departfrm' + prashidCounter;*/
	newline11.innerHTML = '<input type="text" value="" id="departfrm' + prashidCounter + '" size="5"/>';
	newline.appendChild(newline11);
	
	var newline12 = slrow.cells[12].cloneNode(false);
	//newline09.innerHTML = '<input type="text" value="" id="travelto' + prashidCounter + '" size="5" />';
	newline12.innerHTML = '<select name="travelto'+ prashidCounter + '" id="travelto'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="getCityClass(this)"><option value="select">--Select--</option></select>';
	var newtraveltoselect = newline12.getElementsByTagName('select');
	newtraveltoselect.id = 'travelto' + prashidCounter;
	newline.appendChild(newline12);
	
	var newline13 = slrow.cells[13].cloneNode(false);
	newline13.innerHTML = '<input type="text" value="" id="othercnm' + prashidCounter + '" size="8" />';
	newline.appendChild(newline13);
	
	var newline14 = slrow.cells[14].cloneNode(false);
	//newline14.innerHTML = '<input type="text" value="" id="cityClass' + prashidCounter + '" size="5" />';
	newline14.innerHTML = '<select name="cityClass'+ prashidCounter + '" style="width: 98%" id="cityClass'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
	var newcityClasselect = newline14.getElementsByTagName('select');
	newtransModeselect.id = 'cityClass' + prashidCounter;
	newline.appendChild(newline14);
	
	var newline15 = slrow.cells[15].cloneNode(false);
	//newline11.innerHTML = '<input type="text" value="" id="traveleod' + prashidCounter + '" size="13" />';
	newline15.innerHTML = '<select name="traveleod'+ prashidCounter + '" id="traveleod'+ prashidCounter + '" style="border-color: #59839E;width: 98%"><option value="select">--Select--</option></select>';
	var traveleodselect = newline15.getElementsByTagName('select');
	traveleodselect.id = 'traveleod' + prashidCounter;
	newline.appendChild(newline15);
	
	var newline16 = slrow.cells[16].cloneNode(false);
	newline16.innerHTML = '<input type="text" value="" id="arratbase' + prashidCounter + '" size="18"  />';
	newline.appendChild(newline16);
	
	var newline17 = slrow.cells[17].cloneNode(false);
	newline17.innerHTML = '<select name="aPM'+ prashidCounter + '" style="width: 98%" id="aPM'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option><option value="AM"> AM</option><option value="PM"> PM</option><option value="MidNight"> MidNight</option></select>';
	var newproductselect = newline17.getElementsByTagName('select');
	newproductselect.id = 'aPM' + prashidCounter;
	newline.appendChild(newline17);
	
	var newline18 = slrow.cells[18].cloneNode(false);
	newline18.innerHTML = '<input type="text" value="" id="totaltTym' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);"  />';
	newline.appendChild(newline18);
	
	var newline19 = slrow.cells[19].cloneNode(false);
	//newline13.innerHTML = '<input type="text" value="" id="motrans' + prashidCounter + '" size="10" />';
	newline19.innerHTML = '<select name="motrans'+ prashidCounter + '" id="motrans'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="matchConvMasterData(this);"><option value="select">--Select--</option></select>';
	var motransselect = newline19.getElementsByTagName('select');
	motransselect.id = 'motrans' + prashidCounter;
	newline.appendChild(newline19);
	
	var newline20 = slrow.cells[20].cloneNode(false);
	newline20.innerHTML = '<input type="text" value="" id="ticket' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
	newline.appendChild(newline20);
	
	var newline21 = slrow.cells[21].cloneNode(false);
	newline21.innerHTML = '<input type="text" value="" id="rpk' + prashidCounter + '" size="6" onkeypress="return isNumber(event)" onblur="checkDec(this);" readonly="readonly"/>';
	newline.appendChild(newline21);
	
	var newline22 = slrow.cells[22].cloneNode(false);
	newline22.innerHTML = '<input type="text" value="" id="totalkm' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
	newline.appendChild(newline22);
	
	var newline23 = slrow.cells[23].cloneNode(false);
	newline23.innerHTML = '<input type="text" value="" id="convAmt' + prashidCounter + '" size="9" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
	newline.appendChild(newline23);
	
	var newline24 = slrow.cells[24].cloneNode(false);
	newline24.innerHTML = '<input type="text" value="" id="hotelchramt' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();matchHotelMasterData(this);""/>';
	newline.appendChild(newline24);
	
	var newline25 = slrow.cells[25].cloneNode(false);
	newline25.innerHTML = '<input type="text" name="taxhotelch" value="" id="taxhotelch' + prashidCounter + '" size="9" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
	newline.appendChild(newline25);
	
	var newline26 = slrow.cells[26].cloneNode(false);
	newline26.innerHTML = '<input type="text" name="breakFast" value="" id="breakFast' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();matchFoodMasterData(this);"/>';
	newline.appendChild(newline26);
	
	var newline27 = slrow.cells[27].cloneNode(false);
	newline27.innerHTML = '<input type="text" name="lunch" value="" id="lunch' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();matchFoodMasterData(this);"/>';
	newline.appendChild(newline27);
	
	var newline28 = slrow.cells[28].cloneNode(false);
	newline28.innerHTML = '<input type="text" name="dinner" value="" id="dinner' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();matchFoodMasterData(this);"/>';
	newline.appendChild(newline28);
	
/*	var newline29 = slrow.cells[29].cloneNode(false);
	newline29.innerHTML = '<input type="text" name="abaAmt" value="" id="abaAmt' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
	newline.appendChild(newline29);*/
	
	var newline29 = slrow.cells[29].cloneNode(false);
	newline29.innerHTML = '<select name="abaAmt'+ prashidCounter + '" id="abaAmt'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="abaAlert(this);"><option value="">--Select--</option><option value="125">125</option><option value="250">250</option></select>';
	var abaAmtselect = newline29.getElementsByTagName('select');
	abaAmtselect.id = 'abaAmt' + prashidCounter;
	newline.appendChild(newline29);
	
	var newline30 = slrow.cells[30].cloneNode(false);
	newline30.innerHTML = '<input type="text" name="tollPark" value="" id="tollPark' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
	newline.appendChild(newline30);
	
	var newline31 = slrow.cells[31].cloneNode(false);
	newline31.innerHTML = '<input type="text" name="others" value="" id="others' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
	newline.appendChild(newline31);
	
	var newline32 = slrow.cells[32].cloneNode(false);
	newline32.innerHTML = '<input type="text" name="remark" value="" id="remark' + prashidCounter + '" size="5" />';
	newline.appendChild(newline32);
	
	var newline33 = slrow.cells[33].cloneNode(false);
	newline33.innerHTML = '<input type="text" name="total" value="" id="total' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);" readonly="readonly"/>';
	newline.appendChild(newline33);
	
/*	var newline34 = slrow.cells[34].cloneNode(false);
	newline34.innerHTML = '<input type="text" name="byPass" value="" id="byPass' + prashidCounter + '" size="5" />';
	newline.appendChild(newline34);*/
	
	var newline34 = slrow.cells[34].cloneNode(false);
	newline34.innerHTML = '<select name="byPass'+ prashidCounter + '" id="byPass'+ prashidCounter + '" style="border-color: #59839E;width: 98%"><option value="N">NO</option><option value="Y">YES</option></select>';
	var byPassselect = newline34.getElementsByTagName('select');
	byPassselect.id = 'byPass' + prashidCounter;
	newline.appendChild(newline34);
	
	tblBody.appendChild(newline);
	
/*	var newli = extrarow.cloneNode(false);
	var new00 = extrarow.cells[0].cloneNode(true);
	newli.appendChild(new00);
	
	var invtype=document.getElementById("invtype").value;
	if(invtype=='PREPAYMENT'){
		document.getElementById("prepaySrch").style.visibility="";
		document.getElementById("deductionSrch").style.visibility="";
		document.getElementById("preinvId").value="";
		document.getElementById("dedinvId").value="";
		document.getElementById("totalpreAmt").value="";
		document.getElementById("prepayment").value="";
		document.getElementById("deduction").value="";
		document.getElementById("totaldedAmt").value="";
	var cnter=document.getElementById("prashidCounter").value;
		for(var i=1;i<=cnter;i++){
			document.getElementById("cgst"+i).value="";
			document.getElementById("cgst"+i).readOnly = true;
			document.getElementById("cgst"+i).style.backgroundColor ="#D9D9D1";
			
			document.getElementById("igst"+i).value="";
			document.getElementById("igst"+i).readOnly = true;
    		document.getElementById("igst"+i).style.backgroundColor ="#D9D9D1";
    		
    		document.getElementById("sgst"+i).value="";
			document.getElementById("sgst"+i).readOnly = true;
    		document.getElementById("sgst"+i).style.backgroundColor ="#D9D9D1";
		}
	}
	
	
	generatedepartment();*/
	getAtt1Inner(document.getElementById("expcat1"),prashidCounter);
 }else if(document.masterInvExp.expCat.value=="Entertainment"){
	 var tblBody = document.getElementById('innerTableEnter').tBodies[0];
		var slrow = document.getElementById("thirdrowfEnter");			
		var newline = slrow.cloneNode(false);
		
	 var newline00 = slrow.cells[0].cloneNode(false);
		newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
				+ '" id="lnoEnter' + prashidCounter + '" size="1" name="lnoEnter" />';
		newline.appendChild(newline00);
		
		var newline01 = slrow.cells[1].cloneNode(false);
		newline01.innerHTML = '<input type="text"  value="" id="invnoEnter' + prashidCounter + '" size="10" />';
		newline.appendChild(newline01);
		
		var newline02 = slrow.cells[2].cloneNode(false);
		newline02.innerHTML = '<input type="text"  value="" id="invoiceDateEnter' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDateEnter'+prashidCounter+'","ddmmmyyyy","","")  />';
		newline.appendChild(newline02);
		
		var newline03 = slrow.cells[3].cloneNode(false);
		newline03.innerHTML = '<select name="descriptionEnter'+ prashidCounter + '" style="width: 98%" id="descriptionEnter'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
		var newdeptselect = newline03.getElementsByTagName('select');
		newdeptselect.id = 'descriptionEnter' + prashidCounter;
		newline.appendChild(newline03);
		
		var newline04 = slrow.cells[4].cloneNode(false);
		newline04.innerHTML = '<select name="att1Enter'+ prashidCounter + '" style="width: 98%" id="att1Enter'+ prashidCounter + '" onchange="getfieldDtls(this)" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
		var newproductselect = newline04.getElementsByTagName('select');
		newproductselect.id = 'att1Enter' + prashidCounter;
		newline.appendChild(newline04);
		
			
		var newline05 = slrow.cells[5].cloneNode(false);
		newline05.innerHTML = '<input type="text"  value="" id="doeEnter' + prashidCounter + '" size="8"  readonly="readonly" onclick=javascript:NewCal("doeEnter'+prashidCounter+'","ddmmmyyyy","","")  onblur ="getDayFol(this);"/>';
		newline.appendChild(newline05);

		
		var newline06 = slrow.cells[6].cloneNode(false);
		newline06.innerHTML = '<input type="text" value="" id="dayEnter' + prashidCounter + '" size="8" readonly="readonly"/>';
		newline.appendChild(newline06);
		
		var newline07 = slrow.cells[7].cloneNode(false);
		newline07.innerHTML = '<input type="text" value="" id="totalPerEnter' + prashidCounter + '" size="20"/>';
		newline.appendChild(newline07);
		
		var newline08 = slrow.cells[8].cloneNode(false);
		newline08.innerHTML = '<input type="text" value="" id="nameofperson1Enter' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline08);
		
		var newline09 = slrow.cells[9].cloneNode(false);
		newline09.innerHTML = '<input type="text" value="" id="nameofperson2Enter' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline09);
		
		var newline10 = slrow.cells[10].cloneNode(false);
		newline10.innerHTML = '<input type="text" value="" id="nameofperson3Enter' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline10);
		
		var newline11 = slrow.cells[11].cloneNode(false);
		newline11.innerHTML = '<input type="text" value="" id="nameofperson4Enter' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline11);
		
		var newline12 = slrow.cells[12].cloneNode(false);
		newline12.innerHTML = '<input type="text" value="" id="nameofperson5Enter' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline12);
		
		var newline13 = slrow.cells[13].cloneNode(false);
		newline13.innerHTML = '<input type="text" value="" id="nameofperson6Enter' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline13);
		
		var newline14 = slrow.cells[14].cloneNode(false);
		newline14.innerHTML = '<input type="text" value="" id="bafmemberEnter' + prashidCounter + '" size="8"/>';
		newline.appendChild(newline14);
		
		var newline15 = slrow.cells[15].cloneNode(false);
		newline15.innerHTML = '<input type="text" value="" id="placeEnter' + prashidCounter + '" size="6"/>';
		newline.appendChild(newline15);
		
		var newline16 = slrow.cells[16].cloneNode(false);
		newline16.innerHTML = '<input type="text" value="" id="amountEnter' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
		newline.appendChild(newline16);
		
		var newline17 = slrow.cells[17].cloneNode(false);
		newline17.innerHTML = '<input type="text" value="" id="remarkEnter' + prashidCounter + '" size="20" />';
		newline.appendChild(newline17);
		
		tblBody.appendChild(newline);
		
		getAtt1InnerEnter(document.getElementById("expcat1"),prashidCounter);		
		
 }else if(document.masterInvExp.expCat.value=="Food Expense"){
	 
	 var tblBody = document.getElementById('innerTableFood').tBodies[0];
		var slrow = document.getElementById("thirdrowfFood");			
		var newline = slrow.cloneNode(false);
	 
	 var newline00 = slrow.cells[0].cloneNode(false);
		newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
				+ '" id="lnoFood' + prashidCounter + '" size="1" name="lnoFood" />';
		newline.appendChild(newline00);
		
		var newline01 = slrow.cells[1].cloneNode(false);
		newline01.innerHTML = '<input type="text"  value="" id="invnoFood' + prashidCounter + '" size="10" />';
		newline.appendChild(newline01);
		
		var newline02 = slrow.cells[2].cloneNode(false);
		newline02.innerHTML = '<input type="text"  value="" id="invoiceDateFood' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDateFood'+prashidCounter+'","ddmmmyyyy","","")  />';
		newline.appendChild(newline02);
		
		var newline03 = slrow.cells[3].cloneNode(false);
		newline03.innerHTML = '<select name="descriptionFood'+ prashidCounter + '" style="width: 98%" id="descriptionFood'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
		var newdeptselect = newline03.getElementsByTagName('select');
		newdeptselect.id = 'descriptionFood' + prashidCounter;
		newline.appendChild(newline03);
		
		var newline04 = slrow.cells[4].cloneNode(false);
		newline04.innerHTML = '<select name="att1Food'+ prashidCounter + '" style="width: 98%" id="att1Food'+ prashidCounter + '" onchange="gettypeOfFood(this)" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
		var newproductselect = newline04.getElementsByTagName('select');
		newproductselect.id = 'att1Food' + prashidCounter;
		newline.appendChild(newline04);
		
			
		var newline05 = slrow.cells[5].cloneNode(false);
		newline05.innerHTML = '<input type="text"  value="" id="doeFood' + prashidCounter + '" size="8"  readonly="readonly" onclick=javascript:NewCal("doeFood'+prashidCounter+'","ddmmmyyyy","","") onblur ="getDayFol(this);" />';
		newline.appendChild(newline05);
		
		var newline06 = slrow.cells[6].cloneNode(false);
		newline06.innerHTML = '<input type="text" value="" id="dayFood' + prashidCounter + '" size="8" readonly="readonly"/>';
		newline.appendChild(newline06);
		
		var newline07 = slrow.cells[7].cloneNode(false);
		newline07.innerHTML = '<select name="typefoodexpFood'+ prashidCounter + '" style="width: 98%" id="typefoodexpFood'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="remTotalAmt(this)"> <option value="select">--Select--</option></select>';
		var newfoodtypeselect = newline07.getElementsByTagName('select');
		newfoodtypeselect.id = 'typefoodexpFood' + prashidCounter;
		newline.appendChild(newline07);
		
		var newline08 = slrow.cells[8].cloneNode(false);
		newline08.innerHTML = '<input type="text" value="" id="empIdFood' + prashidCounter + '" size="8"/>';
		newline.appendChild(newline08);
		
		var newline09 = slrow.cells[9].cloneNode(false);
		newline09.innerHTML = '<input type="text" value="" id="nameOfEmpFood' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline09);
		
		var newline10 = slrow.cells[10].cloneNode(false);
		newline10.innerHTML = '<input type="text" value="" id="workReqFood' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline10);
		
		var newline11 = slrow.cells[11].cloneNode(false);
		newline11.innerHTML = '<input type="text" value="" id="totalnoEmpFood' + prashidCounter + '" size="12"/>';
		newline.appendChild(newline11);
		
		var newline12 = slrow.cells[12].cloneNode(false);
		newline12.innerHTML = '<input type="text" value="" id="noguestAuditFood' + prashidCounter + '" size="10" />';
		newline.appendChild(newline12);
		
		var newline13 = slrow.cells[13].cloneNode(false);
		newline13.innerHTML = '<input type="text" value="" id="expamountFood' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();matchFoodExpMaster(this);"/>';
		newline.appendChild(newline13);
		
		var newline14 = slrow.cells[14].cloneNode(false);
		newline14.innerHTML = '<input type="text" value="" id="remarkFood' + prashidCounter + '" size="5" />';
		newline.appendChild(newline14);
		
		var newline15 = slrow.cells[15].cloneNode(false);
		newline15.innerHTML = '<input type="text" value="" id="totalFood' + prashidCounter + '" size="5" readonly="readonly"/>';
		newline.appendChild(newline15);
		
		/*var newline16 = slrow.cells[16].cloneNode(false);
		newline16.innerHTML = '<input type="text" value="" id="byPassFood' + prashidCounter + '" size="5" />';
		newline.appendChild(newline16);
		*/
		var newline16 = slrow.cells[16].cloneNode(false);
		newline16.innerHTML = '<select name="byPassFood'+ prashidCounter + '" style="width: 98%" id="byPassFood'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="remTotalAmt(this);"> <option value="N">NO</option><option value="Y">YES</option></select>';
		var newfoodtypeselect = newline16.getElementsByTagName('select');
		newfoodtypeselect.id = 'byPassFood' + prashidCounter;
		newline.appendChild(newline16);
		
		tblBody.appendChild(newline);
		
		getAtt1InnerFood(document.getElementById("expcat1"),prashidCounter);	
 	}
 	else if(document.masterInvExp.expCat.value=="Local Conveyance"){
 		
 		var tblBody = document.getElementById('innerTableLocal').tBodies[0];
		var slrow = document.getElementById("thirdrowfLocal");			
		var newline = slrow.cloneNode(false);
 		
	 var newline00 = slrow.cells[0].cloneNode(false);
		newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
				+ '" id="lnolocalC' + prashidCounter + '" size="1" name="lnolocalC" />';
		newline.appendChild(newline00);
		
		var newline01 = slrow.cells[1].cloneNode(false);
		newline01.innerHTML = '<input type="text"  value="" id="invnolocalC' + prashidCounter + '" size="10" />';
		newline.appendChild(newline01);
		
		var newline02 = slrow.cells[2].cloneNode(false);
		newline02.innerHTML = '<input type="text"  value="" id="invoiceDatelocalC' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDatelocalC'+prashidCounter+'","ddmmmyyyy","","")  />';
		newline.appendChild(newline02);
		
		var newline03 = slrow.cells[3].cloneNode(false);
		newline03.innerHTML = '<select name="descriptionlocalC'+ prashidCounter + '" style="width: 98%" id="descriptionlocalC'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
		var newdeptselect = newline03.getElementsByTagName('select');
		newdeptselect.id = 'descriptionlocalC' + prashidCounter;
		newline.appendChild(newline03);
		
		var newline04 = slrow.cells[4].cloneNode(false);
		newline04.innerHTML = '<select name="att1localC'+ prashidCounter + '" style="width: 98%" id="att1localC'+ prashidCounter + '" onchange="getmotrans(this)" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
		var newproductselect = newline04.getElementsByTagName('select');
		newproductselect.id = 'att1localC' + prashidCounter;
		newline.appendChild(newline04);
		
			
		var newline05 = slrow.cells[5].cloneNode(false);
		newline05.innerHTML = '<input type="text"  value="" id="dotlocalC' + prashidCounter + '" size="8"  readonly="readonly" onclick=javascript:NewCal("dotlocalC'+prashidCounter+'","ddmmmyyyy","","") onblur ="getDayFol(this);" />';
		newline.appendChild(newline05);
		
		var newline06 = slrow.cells[6].cloneNode(false);
		newline06.innerHTML = '<input type="text" value="" id="daylocalC' + prashidCounter + '" size="8" readonly="readonly"/>';
		newline.appendChild(newline06);
		
		var newline07 = slrow.cells[7].cloneNode(false);
		newline07.innerHTML = '<input type="text" value="" id="travFrmlocalC' + prashidCounter + '" size="12"/>';
		newline.appendChild(newline07);
		
		var newline08 = slrow.cells[8].cloneNode(false);
		newline08.innerHTML = '<input type="text" value="" id="travTolocalC' + prashidCounter + '" size="8"/>';
		newline.appendChild(newline08);
		
		var newline09 = slrow.cells[9].cloneNode(false);
		newline09.innerHTML = '<input type="text" value="" id="retBacklocalC' + prashidCounter + '" size="10"/>';
		newline.appendChild(newline09);
		
		var newline10 = slrow.cells[10].cloneNode(false);
		newline10.innerHTML = '<select name="modeTranlocalC'+ prashidCounter + '" style="width: 98%" id="modeTranlocalC'+ prashidCounter + '" onchange="matchLocConvExpMaster(this);" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
		var newproductselect = newline10.getElementsByTagName('select');
		newproductselect.id = 'modeTranlocalC' + prashidCounter;
		newline.appendChild(newline10);
		
		var newline11 = slrow.cells[11].cloneNode(false);
		newline11.innerHTML = '<input type="text" value="" id="ownVehlocalC' + prashidCounter + '" size="12"/>';
		newline.appendChild(newline11);
		
		var newline12 = slrow.cells[12].cloneNode(false);
		newline12.innerHTML = '<input type="text" value="" id="ratePKlocalC' + prashidCounter + '" size="10" onkeypress="return isNumber(event)" onblur="checkDec(this);" readonly="readonly"/>';
		newline.appendChild(newline12);
		
		var newline13 = slrow.cells[13].cloneNode(false);
		newline13.innerHTML = '<input type="text" value="" id="totKMlocalC' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
		newline.appendChild(newline13);
		
		var newline14 = slrow.cells[14].cloneNode(false);
		newline14.innerHTML = '<input type="text" value="" id="ParkTolllocalC' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
		newline.appendChild(newline14);
		
		var newline14 = slrow.cells[14].cloneNode(false);
		newline14.innerHTML = '<input type="text" value="" id="ConvTotlocalC' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
		newline.appendChild(newline14);
		
		var newline14 = slrow.cells[14].cloneNode(false);
		newline14.innerHTML = '<input type="text" value="" id="remarklocalC' + prashidCounter + '" size="5" />';
		newline.appendChild(newline14);
		
		var newline15 = slrow.cells[15].cloneNode(false);
		newline15.innerHTML = '<input type="text" value="" id="TotAmtlocalC' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);" readonly="readonly"/>';
		newline.appendChild(newline15);
		
		/*var newline16 = slrow.cells[16].cloneNode(false);
		newline16.innerHTML = '<input type="text" value="" id="byPasslocC' + prashidCounter + '" size="5" />';
		newline.appendChild(newline16);*/
		var newline16 = slrow.cells[16].cloneNode(false);
		newline16.innerHTML = '<select name="byPasslocC'+ prashidCounter + '" style="width: 98%" id="byPasslocC'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="N">NO</option><option value="Y">YES</option></select>';
		var newlocclselect = newline16.getElementsByTagName('select');
		newlocclselect.id = 'byPasslocC' + prashidCounter;
		newline.appendChild(newline16);

		tblBody.appendChild(newline);
		
		getAtt1InnerLocal(document.getElementById("expcat1"),prashidCounter);	
 	}
 	else if(document.masterInvExp.expCat.value=="Miscellaneous"){
 		
 		var tblBody = document.getElementById('innerTableMisc').tBodies[0];
		var slrow = document.getElementById("thirdrowfMisc");			
		var newline = slrow.cloneNode(false);
 		
 		 var newline00 = slrow.cells[0].cloneNode(false);
 			newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
 					+ '" id="lnoMisce' + prashidCounter + '" size="1" name="lnoMisce" />';
 			newline.appendChild(newline00);
 			
 			var newline01 = slrow.cells[1].cloneNode(false);
 			newline01.innerHTML = '<input type="text"  value="" id="invnoMisce' + prashidCounter + '" size="10" />';
 			newline.appendChild(newline01);
 			
 			var newline02 = slrow.cells[2].cloneNode(false);
 			newline02.innerHTML = '<input type="text"  value="" id="invoiceDateMisce' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDateMisce'+prashidCounter+'","ddmmmyyyy","","")  />';
 			newline.appendChild(newline02);
 			
 			var newline03 = slrow.cells[3].cloneNode(false);
 			newline03.innerHTML = '<select name="descriptionMisce'+ prashidCounter + '" style="width: 98%" id="descriptionMisce'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
 			var newdeptselect = newline03.getElementsByTagName('select');
 			newdeptselect.id = 'descriptionMisce' + prashidCounter;
 			newline.appendChild(newline03);
 			
 			var newline04 = slrow.cells[4].cloneNode(false);
 			newline04.innerHTML = '<select name="att1Misce'+ prashidCounter + '" style="width: 98%" id="att1Misce'+ prashidCounter + '" onchange="getfieldDtls(this)" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
 			var newproductselect = newline04.getElementsByTagName('select');
 			newproductselect.id = 'att1Misce' + prashidCounter;
 			newline.appendChild(newline04);
 			
 				
 			var newline05 = slrow.cells[5].cloneNode(false);
 			newline05.innerHTML = '<input type="text"  value="" id="doeMisce' + prashidCounter + '" size="12"  readonly="readonly" onclick=javascript:NewCal("doeMisce'+prashidCounter+'","ddmmmyyyy","","")  onblur ="getDayFol(this);"/>';
 			newline.appendChild(newline05);
 			
 			var newline06 = slrow.cells[6].cloneNode(false);
 			newline06.innerHTML = '<input type="text" value="" id="dayMisce' + prashidCounter + '" size="12" readonly="readonly"/>';
 			newline.appendChild(newline06);
 			
 			var newline07 = slrow.cells[7].cloneNode(false);
 			newline07.innerHTML = '<input type="text" value="" id="ExpPeriodMisce' + prashidCounter + '" size="12"/>';
 			newline.appendChild(newline07);
 			
 			var newline08 = slrow.cells[8].cloneNode(false);
 			newline08.innerHTML = '<input type="text" value="" id="amountMisce' + prashidCounter + '" size="15" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
 			newline.appendChild(newline08);		
 			
 			var newline09 = slrow.cells[9].cloneNode(false);
 			newline09.innerHTML = '<input type="text" value="" id="remarkMiscC' + prashidCounter + '" size="5" />';
 			newline.appendChild(newline09);	
 			
 			var newline10 = slrow.cells[10].cloneNode(false);
 			newline10.innerHTML = '<input type="text" value="" id="TotAmtMiscC' + prashidCounter + '" size="5" onkeypress="return isNumber(event)" onblur="checkDec(this);" readonly="readonly"/>';
 			newline.appendChild(newline10);	
 			
 			/*var newline11 = slrow.cells[11].cloneNode(false);
 			newline11.innerHTML = '<input type="text" value="" id="byPassMisc' + prashidCounter + '" size="5"/>';
 			newline.appendChild(newline11);	*/
 			var newline11 = slrow.cells[11].cloneNode(false);
 			newline11.innerHTML = '<select name="byPassMisc'+ prashidCounter + '" style="width: 98%" id="byPassMisc'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="N">NO</option><option value="Y">YES</option></select>';
 			var newmisctypeselect = newline11.getElementsByTagName('select');
 			newmisctypeselect.id = 'byPassMisc' + prashidCounter;
 			newline.appendChild(newline11);
 			
 			tblBody.appendChild(newline);
 			
 			getAtt1InnerMisce(document.getElementById("expcat1"),prashidCounter);	
 	 	}
 	else if(document.masterInvExp.expCat.value=="International Travel"){
 		var tblBody = document.getElementById('innerTableInter').tBodies[0];
		var slrow = document.getElementById("thirdrowfInter");			
		var newline = slrow.cloneNode(false);
		
 		 var newline00 = slrow.cells[0].cloneNode(false);
 			newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
 					+ '" id="lnoInterN' + prashidCounter + '" size="1" name="lnoInterN" />';
 			newline.appendChild(newline00);
 			
 			var newline01 = slrow.cells[1].cloneNode(false);
 			newline01.innerHTML = '<input type="text"  value="" id="invnoInterN' + prashidCounter + '" size="10" />';
 			newline.appendChild(newline01);
 			
 			var newline02 = slrow.cells[2].cloneNode(false);
 			newline02.innerHTML = '<input type="text"  value="" id="invoiceDateInterN' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDateInterN'+prashidCounter+'","ddmmmyyyy","","")  />';
 			newline.appendChild(newline02);
 			
 			var newline03 = slrow.cells[3].cloneNode(false);
 			newline03.innerHTML = '<select name="descriptionInterN'+ prashidCounter + '" style="width: 98%" id="descriptionInterN'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
 			var newdeptselect = newline03.getElementsByTagName('select');
 			newdeptselect.id = 'descriptionInterN' + prashidCounter;
 			newline.appendChild(newline03);
 			
 			var newline04 = slrow.cells[4].cloneNode(false);
 			newline04.innerHTML = '<select name="att1seInterN'+ prashidCounter + '" style="width: 98%" id="att1seInterN'+ prashidCounter + '" onchange="getInterfieldDtls(this)" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
 			var newproductselect = newline04.getElementsByTagName('select');
 			newproductselect.id = 'att1Enter' + prashidCounter;
 			newline.appendChild(newline04);
 			
 			var newline05 = slrow.cells[5].cloneNode(false);
 			newline05.innerHTML = '<input type="text"  value="" id="dotravelInterN' + prashidCounter + '" size="8"  readonly="readonly" onclick=javascript:NewCal("dotravelInterN'+prashidCounter+'","ddmmmyyyy","","") onblur ="getDayFol(this);" />';
 			newline.appendChild(newline05);
 			
 			var newline06 = slrow.cells[6].cloneNode(false);
 			newline06.innerHTML = '<input type="text" value="" id="dayInterN' + prashidCounter + '" size="8" readonly="readonly"/>';
 			newline.appendChild(newline06);
 			
 			var newline07 = slrow.cells[7].cloneNode(false);
 			newline07.innerHTML = '<select name="tripForInterN'+ prashidCounter + '" style="width: 98%" id="tripForInterN'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
 			var newtripForselect = newline07.getElementsByTagName('select');
 			newtripForselect.id = 'tripForInterN' + prashidCounter;
 			newline.appendChild(newline07);
 			
 			var newline08 = slrow.cells[8].cloneNode(false);
 			newline08.innerHTML = '<select name="sceneInterN'+ prashidCounter + '" style="width: 98%" id="sceneInterN'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
 			var newsceneselect = newline08.getElementsByTagName('select');
 			newsceneselect.id = 'sceneInterN' + prashidCounter;
 			newline.appendChild(newline08);
 			
 			var newline09 = slrow.cells[9].cloneNode(false);
 			newline09.innerHTML = '<input type="text" value="" id="travelstimeInter' + prashidCounter + '" size="5" onchange="validateHhMm(this);"/>';
 			newline.appendChild(newline09);
 			
 			var newline10 = slrow.cells[10].cloneNode(false);
 			newline10.innerHTML = '<input type="text" value="" id="hrPerInter' + prashidCounter + '" size="5"/>';
 			newline.appendChild(newline10);
 			
 			var newline11 = slrow.cells[11].cloneNode(false);
 			newline11.innerHTML = '<input type="text" value="" id="deprtFrmInterN' + prashidCounter + '" size="8"/>';
 			newline.appendChild(newline11);
 			
 			var newline12 = slrow.cells[12].cloneNode(false);
 			newline12.innerHTML = '<input type="text" value="" id="travelToInterN' + prashidCounter + '" size="8"/>';
 			newline.appendChild(newline12);
 			
 			var newline13 = slrow.cells[13].cloneNode(false);
 			newline13.innerHTML = '<select name="traveleodInterN'+ prashidCounter + '" style="width: 98%" id="traveleodInterN'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
 			var newtraveleodselect = newline13.getElementsByTagName('select');
 			newtraveleodselect.id = 'traveleodInterN' + prashidCounter;
 			newline.appendChild(newline13);
 			
 			var newline14 = slrow.cells[14].cloneNode(false);
 			newline14.innerHTML = '<input type="text" value="" id="arratbaseInterN' + prashidCounter + '" size="18" onchange="validateHhMm(this);"/>';
 			newline.appendChild(newline14);
 			
 			var newline15 = slrow.cells[15].cloneNode(false);
 			newline15.innerHTML = '<input type="text" value="" id="hrPer1Inter' + prashidCounter + '" size="5" />';
 			newline.appendChild(newline15);
 			
 			/*var newline16 = slrow.cells[16].cloneNode(false);
 			newline16.innerHTML = '<input type="text" value="" id="currNmInterN' + prashidCounter + '" size="10" />';
 			newline.appendChild(newline16);*/
 			var newline16 = slrow.cells[16].cloneNode(false);
 			newline16.innerHTML = '<select name="currNmInterN'+ prashidCounter + '" style="width: 98%" id="currNmInterN'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="getExchRate(this)"> <option value="select">--Select--</option></select>';
 			var newtraveleodselect = newline16.getElementsByTagName('select');
 			newtraveleodselect.id = 'currNmInterN' + prashidCounter;
 			newline.appendChild(newline16);
 			
 			var newline17 = slrow.cells[17].cloneNode(false);
 			newline17.innerHTML = '<input type="text" value="" id="excRtInterN' + prashidCounter + '" size="8" readonly="readonly"/>';
 			newline.appendChild(newline17);
 			
 			var newline18 = slrow.cells[18].cloneNode(false);
 			newline18.innerHTML = '<input type="text" value="" id="perDiemInterN' + prashidCounter + '" size="6" onblur="checkDec(this);getInterMatchFixed(this);getTotal();"/>';
 			newline.appendChild(newline18);
 			
 			var newline19 = slrow.cells[19].cloneNode(false);
 			newline19.innerHTML = '<input type="text" value="" id="perDiemINRInterN' + prashidCounter + '" size="8" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
 			newline.appendChild(newline19);
 			
 			var newline20 = slrow.cells[21].cloneNode(false);
 			newline20.innerHTML = '<input type="text" value="" id="hotlTaxInterN' + prashidCounter + '" size="9" onblur="checkDec(this);getInterMatchFixed(this);getTotal();"/>';
 			newline.appendChild(newline20);
 			
 			var newline21 = slrow.cells[21].cloneNode(false);
 			newline21.innerHTML = '<input type="text" value="" id="hotelchrInterN' + prashidCounter + '" size="8" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
 			newline.appendChild(newline21);
 			
 			var newline22 = slrow.cells[22].cloneNode(false);
 			newline22.innerHTML = '<input type="text" value="" id="taxichrFInterN' + prashidCounter + '" size="9" onblur="checkDec(this);getTotal();"/>';
 			newline.appendChild(newline22);
 			
 			var newline23 = slrow.cells[23].cloneNode(false);
 			newline23.innerHTML = '<input type="text" value="" id="taxichrInterN' + prashidCounter + '" size="5" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
 			newline.appendChild(newline23);
 			
 			var newline24 = slrow.cells[24].cloneNode(false);
 			newline24.innerHTML = '<input type="text" value="" id="buschrFInterN' + prashidCounter + '" size="8" onblur="checkDec(this);getTotal();"/>';
 			newline.appendChild(newline24);
 			
 			var newline25 = slrow.cells[25].cloneNode(false);
 			newline25.innerHTML = '<input type="text" value="" id="buschrInterN' + prashidCounter + '" size="8" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
 			newline.appendChild(newline25);
 			
 			var newline26 = slrow.cells[26].cloneNode(false);
 			newline26.innerHTML = '<input type="text" value="" id="othersFAmtInterN' + prashidCounter + '" size="5" onblur="checkDec(this);getTotal();"/>';
 			newline.appendChild(newline26);
 			
 			var newline27 = slrow.cells[27].cloneNode(false);
 			newline27.innerHTML = '<input type="text" value="" id="othersAmtInterN' + prashidCounter + '" size="5" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
 			newline.appendChild(newline27);
 			
 			var newline28 = slrow.cells[28].cloneNode(false);
 			newline28.innerHTML = '<input type="text" value="" id="remarkInterN' + prashidCounter + '" size="5" />';
 			newline.appendChild(newline28);
 			
 			var newline29 = slrow.cells[29].cloneNode(false);
 			newline29.innerHTML = '<input type="text" value="" id="TotAmtInterN' + prashidCounter + '" size="5" readonly="readonly"/>';
 			newline.appendChild(newline29);
 			
 			/*var newline30 = slrow.cells[30].cloneNode(false);
 			newline30.innerHTML = '<input type="text" value="" id="byPassInterN' + prashidCounter + '" size="5" />';
 			newline.appendChild(newline30);*/
 			var newline30 = slrow.cells[30].cloneNode(false);
 			newline30.innerHTML = '<select name="byPassInterN'+ prashidCounter + '" style="width: 98%" id="byPassInterN'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="N">NO</option><option value="Y">YES</option></select>';
 			var newintertypeselect = newline30.getElementsByTagName('select');
 			newintertypeselect.id = 'byPassInterN' + prashidCounter;
 			newline.appendChild(newline30);
 			
 			
 			tblBody.appendChild(newline);
 			
 			getAtt1InnerInterN(document.getElementById("expcat1"),prashidCounter);
 	 }
 	else if(document.masterInvExp.expCat.value=="Combined - Food and conveyance"){
 		 
 		 		var tblBody = document.getElementById('innerTableComb').tBodies[0];
				var slrow = document.getElementById("thirdrowfComb");			
				var newline = slrow.cloneNode(false);
		 		
			 var newline00 = slrow.cells[0].cloneNode(false);
				newline00.innerHTML = '<input type="text" readonly value="' + prashidCounter
						+ '" id="lnoComb' + prashidCounter + '" size="1" name="lnoComb" />';
				newline.appendChild(newline00);
				
				var newline01 = slrow.cells[1].cloneNode(false);
				newline01.innerHTML = '<input type="text"  value="" id="invnoComb' + prashidCounter + '" size="10" />';
				newline.appendChild(newline01);
				
				var newline02 = slrow.cells[2].cloneNode(false);
				newline02.innerHTML = '<input type="text"  value="" id="invoiceDateComb' + prashidCounter + '" size="7"  readonly="readonly" onclick=javascript:NewCal("invoiceDateComb'+prashidCounter+'","ddmmmyyyy","","")  />';
				newline.appendChild(newline02);
				
				var newline03 = slrow.cells[3].cloneNode(false);
				newline03.innerHTML = '<select name="descriptionComb'+ prashidCounter + '" style="width: 98%" id="descriptionComb'+ prashidCounter + '"> <option value="select">--Select--</option></select>';
				var newdeptselect = newline03.getElementsByTagName('select');
				newdeptselect.id = 'descriptionComb' + prashidCounter;
				newline.appendChild(newline03);
				
				var newline04 = slrow.cells[4].cloneNode(false);
				newline04.innerHTML = '<select name="att1Comb'+ prashidCounter + '" style="width: 98%" id="att1Comb'+ prashidCounter + '" onchange="getCombfieldDtls(this);getCombFields(this);" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
				var newproductselect = newline04.getElementsByTagName('select');
				newproductselect.id = 'att1Comb' + prashidCounter;
				newline.appendChild(newline04);
				
					
				var newline05 = slrow.cells[5].cloneNode(false);
				newline05.innerHTML = '<input type="text"  value="" id="dotComb' + prashidCounter + '" size="8"  readonly="readonly" onclick=javascript:NewCal("dotComb'+prashidCounter+'","ddmmmyyyy","","")  onblur ="getDayFol(this);"/>';
				newline.appendChild(newline05);
				
				var newline06 = slrow.cells[6].cloneNode(false);
				newline06.innerHTML = '<input type="text" value="" id="dayComb' + prashidCounter + '" size="8" readonly="readonly"/>';
				newline.appendChild(newline06);
				
				var newline07 = slrow.cells[7].cloneNode(false);
				newline07.innerHTML = '<input type="text" value="" id="travFrmComb' + prashidCounter + '" size="12"/>';
				newline.appendChild(newline07);
				
				var newline08 = slrow.cells[8].cloneNode(false);
				newline08.innerHTML = '<input type="text" value="" id="travToComb' + prashidCounter + '" size="8"/>';
				newline.appendChild(newline08);
				
				var newline09 = slrow.cells[9].cloneNode(false);
				newline09.innerHTML = '<input type="text" value="" id="retBackComb' + prashidCounter + '" size="10"/>';
				newline.appendChild(newline09);
				
				var newline10 = slrow.cells[10].cloneNode(false);
				newline10.innerHTML = '<select name="modeTranComb'+ prashidCounter + '" style="width: 98%" id="modeTranComb'+ prashidCounter + '" style="border-color: #59839E;width: 98%" onchange="getCombMatchLocl(this)"> <option value="select">--Select--</option></select>';
				var newproductselect = newline10.getElementsByTagName('select');
				newproductselect.id = 'modeTranComb' + prashidCounter;
				newline.appendChild(newline10);
				
				var newline11 = slrow.cells[11].cloneNode(false);
				newline11.innerHTML = '<input type="text" value="" id="ownVehComb' + prashidCounter + '" size="12"/>';
				newline.appendChild(newline11);
				
				var newline12 = slrow.cells[12].cloneNode(false);
				newline12.innerHTML = '<input type="text" value="" id="ratePKComb' + prashidCounter + '" size="10" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
				newline.appendChild(newline12);
				
				var newline13 = slrow.cells[13].cloneNode(false);
				newline13.innerHTML = '<input type="text" value="" id="totKMComb' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
				newline.appendChild(newline13);
				
				var newline14 = slrow.cells[14].cloneNode(false);
				newline14.innerHTML = '<input type="text" value="" id="ParkTollComb' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();"/>';
				newline.appendChild(newline14);
				
				var newline15 = slrow.cells[15].cloneNode(false);
 				newline15.innerHTML = '<select name="typefoodexpComb'+ prashidCounter + '" style="width: 98%" id="typefoodexpComb'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="select">--Select--</option></select>';
 				var newfoodtypeselect = newline15.getElementsByTagName('select');
 				newfoodtypeselect.id = 'typefoodexpComb' + prashidCounter;
 				newline.appendChild(newline15);
 				
 				var newline16 = slrow.cells[16].cloneNode(false);
 				newline16.innerHTML = '<input type="text" value="" id="empIdComb' + prashidCounter + '" size="8"/>';
 				newline.appendChild(newline16);
 				
 				var newline17 = slrow.cells[17].cloneNode(false);
 				newline17.innerHTML = '<input type="text" value="" id="nameOfEmpComb' + prashidCounter + '" size="10"/>';
 				newline.appendChild(newline17);
 				
 				var newline18 = slrow.cells[18].cloneNode(false);
 				newline18.innerHTML = '<input type="text" value="" id="workReqComb' + prashidCounter + '" size="10"/>';
 				newline.appendChild(newline18);
 				
 				var newline19 = slrow.cells[19].cloneNode(false);
 				newline19.innerHTML = '<input type="text" value="" id="totalnoEmpComb' + prashidCounter + '" size="12"/>';
 				newline.appendChild(newline19);
 				
 				var newline20 = slrow.cells[20].cloneNode(false);
 				newline20.innerHTML = '<input type="text" value="" id="noguestAuditComb' + prashidCounter + '" size="10" />';
 				newline.appendChild(newline20);
 				
 				var newline21 = slrow.cells[21].cloneNode(false);
 				newline21.innerHTML = '<input type="text" value="" id="expamountComb' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getCombMatchFood(this);getTotal();" readonly="readonly"/>';
 				newline.appendChild(newline21);
 				
 				var newline22 = slrow.cells[22].cloneNode(false);
 				newline22.innerHTML = '<input type="text" value="" id="TotAmtComb' + prashidCounter + '" size="8" onkeypress="return isNumber(event)" onblur="checkDec(this);getTotal();" readonly="readonly"/>';
 				newline.appendChild(newline22);
 				
 				var newline23 = slrow.cells[23].cloneNode(false);
				newline23.innerHTML = '<input type="text" value="" id="remarkComb' + prashidCounter + '" size="5" />';
				newline.appendChild(newline23);
 				
 				/*var newline24 = slrow.cells[24].cloneNode(false);
 				newline24.innerHTML = '<input type="text" value="" id="byPassComb' + prashidCounter + '" size="5" />';
 				newline.appendChild(newline24);*/
				var newline24 = slrow.cells[24].cloneNode(false);
	 			newline24.innerHTML = '<select name="byPassComb'+ prashidCounter + '" style="width: 98%" id="byPassComb'+ prashidCounter + '" style="border-color: #59839E;width: 98%"> <option value="N">NO</option><option value="Y">YES</option></select>';
	 			var newCombtypeselect = newline24.getElementsByTagName('select');
	 			newCombtypeselect.id = 'byPassComb' + prashidCounter;
	 			newline.appendChild(newline24);
 				
 				tblBody.appendChild(newline);
 				
 				getAtt1InnerComb(document.getElementById("expcat1"),prashidCounter);	
				//getAtt1InnerLocal(document.getElementById("expcat1"),prashidCounter);	
 		 
 	 }
}

function getAtt1InnerComb(val,ido){
	
	document.getElementById('att1Comb'+ido).length = 1;
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 	var expCat="Combined - Food and conveyance";
	    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAttComb
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetAttComb() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att1");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var descri=desc[i].getElementsByTagName("expenseAtt1");
	            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = lokupcode[0].firstChild.data;
	            	optn.text = descri[0].firstChild.data;
	            	
	           	document.getElementById('att1Comb'+attidval).options.add(optn);          
				
	            }
	       getNatureOfExp(attidval);                 
	    }
	    
	}


function getAtt1InnerEnter(val,ido){
	
	document.getElementById('att1Enter'+ido).length = 1;
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 	var expCat="Entertainment";
	    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAttEnter
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetAttEnter() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att1");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var descri=desc[i].getElementsByTagName("expenseAtt1");
	            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = lokupcode[0].firstChild.data;
	            	optn.text = descri[0].firstChild.data;
	            	
	           	document.getElementById('att1Enter'+attidval).options.add(optn);          
				
	            }
	       getNatureOfExp(attidval);                 
	    }
	    
	}
	
	function getAtt1InnerFood(val,ido){
		
		document.getElementById('att1Food'+ido).length = 1;
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 	var expCat="Food Expense";
		    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
		    xmlHttp.onreadystatechange=stateChangedgetAttFood
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		
	}	 
		function stateChangedgetAttFood() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att1");
		           //alert(dept.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var descri=desc[i].getElementsByTagName("expenseAtt1");
		            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = lokupcode[0].firstChild.data;
		            	optn.text = descri[0].firstChild.data;
		            	
		           	document.getElementById('att1Food'+attidval).options.add(optn);          
					
		            }
		       getNatureOfExp(attidval);                 
		    }
		    
		}

		function getAtt1InnerLocal(val,ido){
			
			document.getElementById('att1localC'+ido).length = 1;
			 xmlHttp=GetXmlHttpObject()
			    if (xmlHttp==null)
			    {
			      alert ("Browser does not support HTTP Request");
			      return;
			    }
			 	var expCat="Local Conveyance";
			    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
			    xmlHttp.onreadystatechange=stateChangedgetAttLocal
			    xmlHttp.open("GET",url,true);
			    xmlHttp.send(null);
			
		}	 
			function stateChangedgetAttLocal() 
			{ 
				
			    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
			    { 
			    	 //alert(xmlHttp.responseXML);
			    	
			    	 var xmlDoc = xmlHttp.responseXML.documentElement;
			           var desc = xmlDoc.getElementsByTagName("att1");
			           //alert(dept.length);
			            for (i = 0; i < desc.length ; i++)
			            {
			            	var descri=desc[i].getElementsByTagName("expenseAtt1");
			            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
			            	var attid=desc[i].getElementsByTagName("ids");
			            	var attidval=attid[0].firstChild.data;
			            	var optn = document.createElement("OPTION");
			            	
			            	optn.value = lokupcode[0].firstChild.data;
			            	optn.text = descri[0].firstChild.data;
			            	
			           	document.getElementById('att1localC'+attidval).options.add(optn);          
						
			            }
			       getNatureOfExp(attidval);                 
			    }
			    
			}

			function getAtt1InnerMisce(val,ido){
				
				document.getElementById('att1Misce'+ido).length = 1;
				 xmlHttp=GetXmlHttpObject()
				    if (xmlHttp==null)
				    {
				      alert ("Browser does not support HTTP Request");
				      return;
				    }
				 	var expCat="Miscellaneous";
				    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
				    xmlHttp.onreadystatechange=stateChangedgetAttMisce
				    xmlHttp.open("GET",url,true);
				    xmlHttp.send(null);
				
			}	 
				function stateChangedgetAttMisce() 
				{ 
					
				    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
				    { 
				    	 //alert(xmlHttp.responseXML);
				    	
				    	 var xmlDoc = xmlHttp.responseXML.documentElement;
				           var desc = xmlDoc.getElementsByTagName("att1");
				           //alert(dept.length);
				            for (i = 0; i < desc.length ; i++)
				            {
				            	var descri=desc[i].getElementsByTagName("expenseAtt1");
				            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
				            	var attid=desc[i].getElementsByTagName("ids");
				            	var attidval=attid[0].firstChild.data;
				            	var optn = document.createElement("OPTION");
				            	
				            	optn.value = lokupcode[0].firstChild.data;
				            	optn.text = descri[0].firstChild.data;
				            	
				           	document.getElementById('att1Misce'+attidval).options.add(optn);          
							
				            }
				       getNatureOfExp(attidval);                 
				    }
				    
				}
			
				function getAtt1InnerInterN(val,ido){
					
					document.getElementById('att1seInterN'+ido).length = 1;
					 xmlHttp=GetXmlHttpObject()
					    if (xmlHttp==null)
					    {
					      alert ("Browser does not support HTTP Request");
					      return;
					    }
					 	var expCat="International Travel";
					    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
					    xmlHttp.onreadystatechange=stateChangedgetAttInterN
					    xmlHttp.open("GET",url,true);
					    xmlHttp.send(null);
					
				}	 
					function stateChangedgetAttInterN() 
					{ 
						
					    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
					    { 
					    	 //alert(xmlHttp.responseXML);
					    	
					    	 var xmlDoc = xmlHttp.responseXML.documentElement;
					           var desc = xmlDoc.getElementsByTagName("att1");
					           //alert(dept.length);
					            for (i = 0; i < desc.length ; i++)
					            {
					            	var descri=desc[i].getElementsByTagName("expenseAtt1");
					            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
					            	var attid=desc[i].getElementsByTagName("ids");
					            	var attidval=attid[0].firstChild.data;
					            	var optn = document.createElement("OPTION");
					            	
					            	optn.value = lokupcode[0].firstChild.data;
					            	optn.text = descri[0].firstChild.data;
					            	
					           	document.getElementById('att1seInterN'+attidval).options.add(optn);          
								
					            }
					       getNatureOfExp(attidval);                 
					    }
					    
					}
				
function getAtt1Inner(val,ido){
	
	document.getElementById('att1se'+ido).length = 1;
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 	var expCat=val.value;
	    var url="getInvExpAttribute1Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAttInner1
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetAttInner1() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att1");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var descri=desc[i].getElementsByTagName("expenseAtt1");
	            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = lokupcode[0].firstChild.data;
	            	optn.text = descri[0].firstChild.data;
	            	
	           	document.getElementById('att1se'+attidval).options.add(optn);          
				
	            }
	       getNatureOfExp(attidval);                 
	    }
	    
	}
	
	
	
	function getNatureOfExp(ido){
		
		//document.getElementById('description'+ido).length = 1;
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 	
		    var url="getInvNOEVal?id="+ido;	    
		    xmlHttp.onreadystatechange=stateChangedgetInvNOE
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		
	}	 
		function stateChangedgetInvNOE() 
		{ 
			var lineCount = document.getElementById('prashidCounter').value;
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	// alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att1");
		          // alert(desc.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var descri=desc[i].getElementsByTagName("expenseAtt1");
		            	var lokupcode=desc[i].getElementsByTagName("lookupCode");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	var descnew = descri[0].firstChild.data;
		            	optn.text=descnew.replace("amp", "&");
		            	
		            	optn.value = lokupcode[0].firstChild.data;
		            	//optn.text = descri[0].firstChild.data;
		            	
		           if(document.masterInvExp.expCat.value=="OutStation Travel") 	
		           	document.getElementById('description'+lineCount).options.add(optn);
		           if(document.masterInvExp.expCat.value=="Entertainment")
		           	document.getElementById('descriptionEnter'+lineCount).options.add(optn);
		           if(document.masterInvExp.expCat.value=="Food Expense")
			        document.getElementById('descriptionFood'+lineCount).options.add(optn);
		           if(document.masterInvExp.expCat.value=="Local Conveyance")
				    document.getElementById('descriptionlocalC'+lineCount).options.add(optn);
		           if(document.masterInvExp.expCat.value=="Miscellaneous")
					document.getElementById('descriptionMisce'+lineCount).options.add(optn);
		           if(document.masterInvExp.expCat.value=="International Travel")
					document.getElementById('descriptionInterN'+lineCount).options.add(optn); 
		           if(document.masterInvExp.expCat.value=="Combined - Food and conveyance")
						document.getElementById('descriptionComb'+lineCount).options.add(optn); 
		            }
		                    
		    }
		    
		}

function gettypeOfFood(val){
	var ido=val.id;
	ido=ido.substring(8);
	document.getElementById('typefoodexpFood'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat="Food Expense";
	    var url="getAttribute2Val?expCat="+expCat+"&id="+ido;
	    //alert(url);
	    xmlHttp.onreadystatechange=stateChangedgettypeOfFood
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgettypeOfFood() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(desc.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	           	document.getElementById('typefoodexpFood'+attidval).options.add(optn);
	          
				
	            }
	            	       
	    }
	    
}
	function getmotrans(val){
		var ido=val.id;
		ido=ido.substring(10);
		document.getElementById('modeTranlocalC'+ido).length = 1;
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat="Local Conveyance";
		    var url="getAttribute2Val?expCat="+expCat+"&id="+ido;	    
		    xmlHttp.onreadystatechange=stateChangedgetmotrans
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		
	}	 
		function stateChangedgetmotrans() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att2");
		           //alert(dept.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = glCode[0].firstChild.data;
		            	optn.text = glCode[0].firstChild.data;
		           	document.getElementById('modeTranlocalC'+attidval).options.add(optn);
		          
					
		            }
		            	       
		    }
		    
	}
		
function saveDtls(){
	
	var fyear=document.getElementById("finYear").value;
	var frmDate=document.getElementById("frmDate").value;
	var toDate=document.getElementById("toDate").value;
	var invtype=document.getElementById("invtype").value;
	var expCat=document.masterInvExp.expCat.value;
	
	if(fyear==''){
		alert("Please Enter Period");
		return false;
	}
	if(frmDate==''){
		alert("Please Enter Exp From");
		return false;
	}
	if(toDate==''){
		alert("Please Enter Exp To");
		return false;
	}
	
	if(invtype=='select'){
		alert("Please Select Invoice Type");
		return false;
	}
	
	if(expCat==''){
		alert("Please select atleast one Expense");
		return false;
	}
	
	if(document.masterInvExp.expCat.value=="OutStation Travel"){
		
		var prashidCounter = document.masterInvExp.prashidCounter.value;
		var lno="";
		var invno="";
		var invoiceDate="";
		var description="";
		var att1se="";
		var dotravel="";
		var day="";
		var travelstime="";
		var departfrm="";
		var travelto="";
		var othercnm="";
		var traveleod="";
		var arratbase="";
		var motrans="";
		var ticket="";
		var rpk="";
		var totalkm="";
		var convAmt="";
		var hotelchramt="";
		var taxhotelch="";
		var breakFast="";
		var lunch="";
		var dinner="";
		var abaAmt="";
		var others="";
		var linStr="";
		var totalStr="";
		var ampm="";
		var aPm="";
		var transMode="";
		var coTravelNm="";
		var cityClass="";
		var totaltTym="";
		var remark="";
		var total="";
		var byPas="";
		
				for(var i=1;i<=prashidCounter;i++){
			lno=document.getElementById("lno"+i).value;
			/*invno=document.getElementById("invno"+i).value;
			if(invno==''){
				alert("Please enter Invoice Number");
				return false;
			}
			invoiceDate=document.getElementById("invoiceDate"+i).value;
			if(invoiceDate==''){
				alert("Please enter Invoice Date");
				return false;
			}*/
			description=document.getElementById("description"+i).value;
			if(description=='select'){
				alert("Please Select Nature Of Expense");
				return false;
			}
			att1se=document.getElementById("att1se"+i).value;
			if(att1se=='select'){
				alert("Please Select Expense Type");
				return false;
			}else{
				var att1Select = document.getElementById("att1se"+i);
				att1se = att1Select.options[att1Select.selectedIndex].text;
			}
			dotravel=document.getElementById("dotravel"+i).value;
			day=document.getElementById("day"+i).value;
			travelstime=document.getElementById("travelstime"+i).value;
			departfrm=document.getElementById("departfrm"+i).value;
			travelto=document.getElementById("travelto"+i).value;
			othercnm=document.getElementById("othercnm"+i).value;
			traveleod=document.getElementById("traveleod"+i).value;
			arratbase=document.getElementById("arratbase"+i).value;
			motrans=document.getElementById("motrans"+i).value;
			ticket=document.getElementById("ticket"+i).value;
			rpk=document.getElementById("rpk"+i).value;
			totalkm=document.getElementById("totalkm"+i).value;
			convAmt=document.getElementById("convAmt"+i).value;
			hotelchramt=document.getElementById("hotelchramt"+i).value;
			taxhotelch=document.getElementById("taxhotelch"+i).value;
			breakFast=document.getElementById("breakFast"+i).value;
			lunch=document.getElementById("lunch"+i).value;
			dinner=document.getElementById("dinner"+i).value;
			abaAmt=document.getElementById("abaAmt"+i).value;
			others=document.getElementById("others"+i).value;
			
			ampm=document.getElementById("amPM"+i).value;
			transMode=document.getElementById("transMode"+i).value;
			coTravelNm=document.getElementById("coTravelNm"+i).value;
			cityClass=document.getElementById("cityClass"+i).value;
			aPm=document.getElementById("aPM"+i).value;
			totaltTym=document.getElementById("totaltTym"+i).value;
			remark=document.getElementById("remark"+i).value;
			total=document.getElementById("total"+i).value;
			byPas=document.getElementById("byPass"+i).value;
			if(dotravel==''){
				alert("Please Enter Date of travel");
				return false;
			}
			if(travelstime==''){
				alert("Please Enter Travel Start Time");
				return false;
			}
			if(ampm==''){
				alert("Please Select AM/PM");
				return false;
			}
			if(transMode==''){
				alert("Please Select Transport Mode");
				return false;
			}
			if(transMode.includes('Co-traveller') && coTravelNm==''){
				alert("Please Enter Co-traveller's Name");
				return false;
			}
			if(departfrm==''){
				alert("Please Enter Depart From");
				return false;
			}
			if(travelto==''){
				alert("Please Enter Travel To");
				return false;
			}
			if(travelto=='OTHER_CITIES' && othercnm==''){
				alert("Please Enter Other City Name");
				return false;
			}
			if(cityClass==''){
				alert("Please Select Class OF City");
				return false;
			}
			
			if(traveleod==''){
				alert("Please Enter Travel EOD");
				return false;
			}			
			
			if(att1se=='Taxi Expense'){
				if(aPm==''){
					alert("Please Select AM/PM");
					return false;
				}
				if(totaltTym==''){
					alert("Please Enter Total travel Time");
					return false;
				}
				if(ticket==''){
					alert("Please Enter Taxi Amount");
					return false;
				}
				
			}
			if(att1se=='Additional Boarding Allowance'){
				if(aPm==''){
					alert("Please Select AM/PM");
					return false;
				}
				if(totaltTym==''){
					alert("Please Enter Total travel Time");
					return false;
				}
				if(abaAmt==''){
					alert("Please Enter ABA Amount");
					return false;
				}
				
			}
			if(att1se=='Conveyance Expense'){
				if(aPm==''){
					alert("Please Select AM/PM");
					return false;
				}
				if(totaltTym==''){
					alert("Please Enter Total travel Time");
					return false;
				}
				if(motrans==''){
					alert("Please Enter Mode Of Transport");
					return false;
				}
				if(totalkm==''){
					alert("Please Enter Total KM Travelled");
					return false;
				}
				if(convAmt==''){
					alert("Please Enter Conveyance Amount");
					return false;
				}
			}
			
			if(att1se=='Food Expense Out Station'){
				if(aPm==''){
					alert("Please Select AM/PM");
					return false;
				}
				if(totaltTym==''){
					alert("Please Enter Total travel Time");
					return false;
				}
				if(breakFast=='' && lunch=='' && dinner=='') {
					alert("Please Enter Breakfast/Luch/Dinner");
					return false;
				
			}
		}		
			if(att1se=='Others Expense'){
					if(others==''){
						alert("Please Enter Others Amount");
						return false;
					}
					
			}
			
			if(att1se=='Tickets Expense'){
				if(aPm==''){
					alert("Please Select AM/PM");
					return false;
				}
				if(totaltTym==''){
					alert("Please Enter Total travel Time");
					return false;
				}
				if(ticket=='') {
					alert("Please Enter Ticket Amount");
					return false;
				
			}
		}			
			if(att1se=='Hotel Charges and Taxes'){
				if(hotelchramt==''){
					alert("Please Enter Hotel Charges Amount");
					return false;
				}
				
		}
			
			/*if(dotravel=='')dotravel='-';
			if(day=='')day='-';
			if(travelstime=='')travelstime='-';
			if(departfrm=='')departfrm='-';
			if(travelto=='')travelto='-';
			if(othercnm=='')othercnm='-';
			if(traveleod=='')traveleod='-';
			if(arratbase=='')arratbase='-';
			if(motrans=='')motrans='-';
			if(ticket=='')ticket='-';
			if(rpk=='')rpk='-';
			if(totalkm=='')totalkm='-';
			
			if(convAmt=='')convAmt='-';
			if(hotelchramt=='')hotelchramt='-';
			if(taxhotelch=='')taxhotelch='-';
			if(breakFast=='')breakFast='-';
			if(lunch=='')lunch='-';
			if(dinner=='')dinner='-';
			if(abaAmt=='')abaAmt='-';*/
			if(others=='')others='0';
			if(byPas=='')byPas='-';
			
			linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
			day+'~'+travelstime+'~'+departfrm+'~'+travelto+'~'+othercnm+'~'+traveleod+'~'+arratbase+'~'+motrans+'~'+ticket
			+'~'+rpk+'~'+totalkm+'~'+convAmt+'~'+hotelchramt+'~'+taxhotelch+'~'+breakFast+'~'+lunch+'~'+dinner+'~'+abaAmt+'~'+others
			+'~'+ampm+'~'+transMode+'~'+coTravelNm+'~'+cityClass+'~'+aPm+'~'+totaltTym+'~'+remark+'~'+total+'~'+byPas
			+'@@';
		}
		totalStr=linStr;
		//alert(totalStr);
		
		
	}
	
	if(document.masterInvExp.expCat.value=="Entertainment"){
		
		var prashidCounter = document.masterInvExp.prashidCounter.value;
		var lno="";
		var invno="";
		var invoiceDate="";
		var description="";
		var att1se="";
		var dotravel="";
		var day="";
		var nmOfPer="";
		var customer1cmpNm="";
		var customer2cmpNm="";
		var customer3cmpNm="";
		var customer4cmpNm="";
		var customer5cmpNm="";
		var customer6cmpNm="";
		var bafMemb="";
		var place="";
		var amount="";
		var rmks="";
		var linStr="";
		var totalStr="";
		
		
		var expCat=document.masterInvExp.expCat.value;
		
		
		for(var i=1;i<=prashidCounter;i++){
			lno=document.getElementById("lnoEnter"+i).value;
			/*invno=document.getElementById("invnoEnter"+i).value;
			if(invno==''){
				alert("Please enter Invoice Number");
				return false;
			}
			invoiceDate=document.getElementById("invoiceDateEnter"+i).value;
			if(invoiceDate==''){
				alert("Please enter Invoice Date");
				return false;
			}*/
			description=document.getElementById("descriptionEnter"+i).value;
			if(description=='select'){
				alert("Please Select Nature Of Expense");
				return false;
			}
			att1se=document.getElementById("att1Enter"+i).value;
			if(att1se=='select'){
				alert("Please Select Expense Type");
				return false;
			}
			dotravel=document.getElementById("doeEnter"+i).value;
			day=document.getElementById("dayEnter"+i).value;
			nmOfPer=document.getElementById("totalPerEnter"+i).value;
			customer1cmpNm=document.getElementById("nameofperson1Enter"+i).value;
			customer2cmpNm=document.getElementById("nameofperson2Enter"+i).value;
			customer3cmpNm=document.getElementById("nameofperson3Enter"+i).value;
			customer4cmpNm=document.getElementById("nameofperson4Enter"+i).value;
			customer5cmpNm=document.getElementById("nameofperson5Enter"+i).value;
			customer6cmpNm=document.getElementById("nameofperson6Enter"+i).value;
			
			bafMemb=document.getElementById("bafmemberEnter"+i).value;
			place=document.getElementById("placeEnter"+i).value;
			amount=document.getElementById("amountEnter"+i).value;
			rmks=document.getElementById("remarkEnter"+i).value;
			if(dotravel==''){
				alert('Please Enter Date Of Expense');
				return false;
			}
			if(nmOfPer=='' || nmOfPer==0){
				alert('Please Enter Number Of Persons');
				return false;
			}
			
			if(customer1cmpNm=='' && customer2cmpNm=='' && customer3cmpNm=='' && customer4cmpNm=='' && customer5cmpNm=='' && customer6cmpNm==''){
				alert("Please Enter atleast One Company Name");
				return false;
			}
			
			if(amount=='')amount='0';
			if(rmks=='')rmks='-';
			
			linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
			day+'~'+nmOfPer+'~'+customer1cmpNm+'~'+customer2cmpNm+'~'+customer3cmpNm+'~'+customer4cmpNm+'~'+customer5cmpNm+'~'+customer6cmpNm+'~'
			+bafMemb+'~'+place+'~'+amount+'~'+rmks+'@@';
		}
		totalStr=linStr;
		//alert(totalStr);
		
	}
if(document.masterInvExp.expCat.value=="Food Expense"){
		
		var prashidCounter = document.masterInvExp.prashidCounter.value;
		var lno="";
		var invno="";
		var invoiceDate="";
		var description="";
		var att1se="";
		var dotravel="";
		var day="";
		var typeofFood="";
		var empId="";
		var nmOfEmp="";
		var workReq="";
		var noOfEmp="";
		var noOfGuest="";
		var expenseAmt="";
		var remarks="";
		var totalFod="";
		var byPassFod="";
		
		var linStr="";
		var totalStr="";
		
		
		for(var i=1;i<=prashidCounter;i++){
			lno=document.getElementById("lnoFood"+i).value;
			/*invno=document.getElementById("invnoFood"+i).value;
			if(invno==''){
				alert("Please enter Invoice Number");
				return false;
			}
			invoiceDate=document.getElementById("invoiceDateFood"+i).value;
			if(invoiceDate==''){
				alert("Please enter Invoice Date");
				return false;
			}*/
			
			description=document.getElementById("descriptionFood"+i).value;
			if(description=='select'){
				alert("Please Select Nature Of Expense");
				return false;
			}
			att1se=document.getElementById("att1Food"+i).value;
			if(att1se=='select'){
				alert("Please Select Expense Type");
				return false;
			}
			dotravel=document.getElementById("doeFood"+i).value;
			day=document.getElementById("dayFood"+i).value;
			typeofFood=document.getElementById("typefoodexpFood"+i).value;
			empId=document.getElementById("empIdFood"+i).value;
			nmOfEmp=document.getElementById("nameOfEmpFood"+i).value;
			workReq=document.getElementById("workReqFood"+i).value;
			noOfEmp=document.getElementById("totalnoEmpFood"+i).value;
			noOfGuest=document.getElementById("noguestAuditFood"+i).value;
			expenseAmt=document.getElementById("expamountFood"+i).value;
			remarks=document.getElementById("remarkFood"+i).value;
			totalFod=document.getElementById("totalFood"+i).value;
			byPassFod=document.getElementById("byPassFood"+i).value;
			
			if(dotravel==''){
				alert("Please Select Date Of Expense");
				return false;
			}
			if(typeofFood=='select'){
				alert("Please Select Type Of Food Expense");
				return false;
			}
			if(empId==''){
				alert("Please Enter Employee Id");
				return false;
			}
			if(nmOfEmp=='' && (typeofFood=='Food for Auditor' || typeofFood=='Food for Guest' || typeofFood=='Food during FC Meeting' )){
				alert("Please Enter Number Of Employee");
				return false;
			}
			if(noOfGuest=='' && (typeofFood=='Food for Auditor' || typeofFood=='Food for Guest' || typeofFood=='Food during FC Meeting' )){
				alert("Please Enter Number Of Employee");
				return false;
			}
			if(expenseAmt=='' || expenseAmt==0){
				alert("Please Enter Expense Amount");
				return false;
			}
			if(remarks=='')remarks='-';
			if(byPassFod=='')byPassFod='-';
			
			linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
			day+'~'+typeofFood+'~'+empId+'~'+nmOfEmp+'~'+workReq+'~'+noOfEmp+'~'+noOfGuest+'~'+expenseAmt+'~'+remarks+'~'+totalFod+'~'+byPassFod
			+'@@';
		}
		totalStr=linStr;
		//alert(totalStr);
		
	}
if(document.masterInvExp.expCat.value=="Local Conveyance"){
	
	var prashidCounter = document.masterInvExp.prashidCounter.value;
	var lno="";
	var invno="";
	var invoiceDate="";
	var description="";
	var att1se="";
	var dotravel="";
	var day="";
	var travelFrm="";
	var travelTo="";
	var returnBackTo="";
	var modeOfTrans="";
	var vehicleNo="";
	var ratePKm="";
	var totalKm="";
	var parkingchrg="";
	var totalConAmt="";
	var remarks="";
	var totalAmt="";
	var byPasLoc="";
	
	var linStr="";
	var totalStr="";
	
	
	for(var i=1;i<=prashidCounter;i++){
		lno=document.getElementById("lnolocalC"+i).value;
		/*invno=document.getElementById("invnolocalC"+i).value;
		if(invno==''){
			alert("Please enter Invoice Number");
			return false;
		}
		invoiceDate=document.getElementById("invoiceDatelocalC"+i).value;
		if(invoiceDate==''){
			alert("Please enter Invoice Date");
			return false;
		}*/
		description=document.getElementById("descriptionlocalC"+i).value;
		if(description=='select'){
			alert("Please Select Nature Of Expense");
			return false;
		}
		att1se=document.getElementById("att1localC"+i).value;
		if(att1se=='select'){
			alert("Please Select Expense Type");
			return false;
		}
		dotravel=document.getElementById("dotlocalC"+i).value;
		day=document.getElementById("daylocalC"+i).value;
		travelFrm=document.getElementById("travFrmlocalC"+i).value;
		travelTo=document.getElementById("travTolocalC"+i).value;
		returnBackTo=document.getElementById("retBacklocalC"+i).value;
		modeOfTrans=document.getElementById("modeTranlocalC"+i).value;
		vehicleNo=document.getElementById("ownVehlocalC"+i).value;
		ratePKm=document.getElementById("ratePKlocalC"+i).value;
		totalKm=document.getElementById("totKMlocalC"+i).value;
		parkingchrg=document.getElementById("ParkTolllocalC"+i).value;
		totalConAmt=document.getElementById("ConvTotlocalC"+i).value;
		remarks=document.getElementById("remarklocalC"+i).value;
		totalAmt=document.getElementById("TotAmtlocalC"+i).value;
		byPasLoc=document.getElementById("byPasslocC"+i).value;
			
		if(dotravel==''){
			alert("Please Select Date Of Expense");
			return false;
		}
		if(travelFrm==''){
			alert("Please Enter Travel From");
			return false;
		}
		if(travelTo==''){
			alert("Please Enter Travel To");
			return false;
		}
		if(returnBackTo==''){
			alert("Please Enter Return Back To");
			return false;
		}
		if(modeOfTrans=='select'){
			alert("Please Select Mode Of Transport");
			return false;
		}
		if((modeOfTrans=='Own_Car' || modeOfTrans=='Own_TW')&& vehicleNo==''){
			alert("Please Enter Vehicle Number");
			return false;
		}
		if(ratePKm=='' && modeOfTrans!='Metro'){
			alert("Please Enter Rate Per KM");
			return false;
		} 
		
		
		if(remarks=='')remarks='-';
		if(byPasLoc=='')byPasLoc='-';
		
		linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
		day+'~'+travelFrm+'~'+travelTo+'~'+returnBackTo+'~'+modeOfTrans+'~'+vehicleNo+'~'+ratePKm+'~'+totalKm+'~'+parkingchrg+'~'+totalConAmt+'~'+
		remarks+'~'+totalAmt+'~'+byPasLoc+'@@';
	}
	totalStr=linStr;
	//alert(totalStr);
	
}

if(document.masterInvExp.expCat.value=="Miscellaneous"){
	
	var prashidCounter = document.masterInvExp.prashidCounter.value;
	var lno="";
	var invno="";
	var invoiceDate="";
	var description="";
	var att1se="";
	var dotravel="";
	var day="";
	var expPeriod="";
	var Amt="";
	var rmks="";
	var totalAmt="";
	var byPasMisc="";
	
	var linStr="";
	var totalStr="";
	
	
	for(var i=1;i<=prashidCounter;i++){
		lno=document.getElementById("lnoMisce"+i).value;
		/*invno=document.getElementById("invnoMisce"+i).value;
		if(invno==''){
			alert("Please enter Invoice Number");
			return false;
		}
		invoiceDate=document.getElementById("invoiceDateMisce"+i).value;
		if(invoiceDate==''){
			alert("Please enter Invoice Date");
			return false;
		}*/
		description=document.getElementById("descriptionMisce"+i).value;
		if(description=='select'){
			alert("Please Select Nature Of Expense");
			return false;
		}
		att1se=document.getElementById("att1Misce"+i).value;
		if(att1se=='select'){
			alert("Please Select Expense Type");
			return false;
		}
		dotravel=document.getElementById("doeMisce"+i).value;
		day=document.getElementById("dayMisce"+i).value;
		expPeriod=document.getElementById("ExpPeriodMisce"+i).value;
		Amt=document.getElementById("amountMisce"+i).value;
		rmks=document.getElementById("remarkMiscC"+i).value;
		totalAmt=document.getElementById("TotAmtMiscC"+i).value;
		byPasMisc=document.getElementById("byPassMisc"+i).value;
		
		if(dotravel==''){
			alert("Please Select Date Of Expense");
			return false;
		}
		if(expPeriod==''){
			alert("Please Enter Expense Period");
			return false;
		}
		
		
		if(totalAmt=='' || totalAmt==0){
			alert("Please Enter Total Amount");
			return false;
		}
		if(byPasMisc=='')byPasMisc='-';
		
		linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
		day+'~'+expPeriod+'~'+Amt+'~'+rmks+'~'+totalAmt+'~'+byPasMisc+'@@';
	}
	totalStr=linStr;
	//alert(totalStr);
	
}

if(document.masterInvExp.expCat.value=="International Travel"){
	
	var prashidCounter = document.masterInvExp.prashidCounter.value;
	var lno="";
	var invno="";
	var invoiceDate="";
	var description="";
	var att1se="";
	var dotravel="";
	var day="";
	var tripFor="";
	var scenerio="";
	var travelstime="";
	var departfrm="";
	var travelTo="";
	var statusOftravel="";
	var arrAtBase="";
	var currNm="";
	var exchRate="";
	var perDiemUS="";
	var perDiemINR="";
	var hotelchrTax="";
	var hotelchrINR="";
	var taxiChrgF="";
	var taxiChrgINR="";
	var busTick="";
	var tickChrINR="";
	var otherAmtF="";
	var otherAmtINR="";
	var perhr="";
	var perhr1="";
	var rmks="";
	var totalAmt="";
	var byPass="";
	
	var linStr="";
	var totalStr="";
	
	
for(var i=1;i<=prashidCounter;i++){
		lno=document.getElementById("lnoInterN"+i).value;
		/*invno=document.getElementById("invnoInterN"+i).value;
		if(invno==''){
			alert("Please enter Invoice Number");
			return false;
		}
		invoiceDate=document.getElementById("invoiceDateInterN"+i).value;
		if(invoiceDate==''){
			alert("Please enter Invoice Date");
			return false;
		}*/
		description=document.getElementById("descriptionInterN"+i).value;
		if(description=='select'){
			alert("Please Select Nature Of Expense");
			return false;
		}
		att1se=document.getElementById("att1seInterN"+i).value;
		if(att1se=='select'){
			alert("Please Select Expense Type");
			return false;
		}
		dotravel=document.getElementById("dotravelInterN"+i).value;
		day=document.getElementById("dayInterN"+i).value;
		tripFor=document.getElementById("tripForInterN"+i).value;
		scenerio=document.getElementById("sceneInterN"+i).value;
		travelstime=document.getElementById("travelstimeInter"+i).value;
		departfrm=document.getElementById("deprtFrmInterN"+i).value;
		travelTo=document.getElementById("travelToInterN"+i).value;
		statusOftravel=document.getElementById("traveleodInterN"+i).value;
		arrAtBase=document.getElementById("arratbaseInterN"+i).value;
		currNm=document.getElementById("currNmInterN"+i).value;
		exchRate=document.getElementById("excRtInterN"+i).value;
		perDiemUS=document.getElementById("perDiemInterN"+i).value;
		perDiemINR=document.getElementById("perDiemINRInterN"+i).value;
		hotelchrTax=document.getElementById("hotlTaxInterN"+i).value;
		hotelchrINR=document.getElementById("hotelchrInterN"+i).value;
		taxiChrgF=document.getElementById("taxichrFInterN"+i).value;
		taxiChrgINR=document.getElementById("taxichrInterN"+i).value;
		busTick=document.getElementById("buschrFInterN"+i).value;
		tickChrINR=document.getElementById("buschrInterN"+i).value;
		otherAmtF=document.getElementById("othersFAmtInterN"+i).value;
		otherAmtINR=document.getElementById("othersAmtInterN"+i).value;
		
		perhr=document.getElementById("hrPerInter"+i).value;
		perhr1=document.getElementById("hrPer1Inter"+i).value;
		rmks=document.getElementById("remarkInterN"+i).value;
		totalAmt=document.getElementById("TotAmtInterN"+i).value;		
		byPass=document.getElementById("byPassInterN"+i).value;	
		
		if(dotravel==''){	alert("Please Enter Date Of Expense");	return false;	}
		if(tripFor==''){alert("Please Select Trip For");return false;	}
		if(scenerio==''){	alert("Please Select Scenerio");return false;		}
		if(travelstime==''){alert("Please Enter Travel Start Time");	return false;	}
		if(departfrm==''){alert("Please Enter Depart from");	return false;	}
		if(travelTo==''){alert("Please Enter Travel To");	return false;	}
		if(statusOftravel==''){alert("Please Select Travel EOD");	return false;	}
		if(currNm==''){alert("Please Enter Currency Name");	return false;	}
		if(perhr==''){alert("Please Enter Hour Period");	return false;	}
		if(totalAmt=='' || totalAmt==0){alert("Please Enter Total Amount");	return false;	}
		
		
		
		if(byPass=='')byPass='-';
		//alert(travelstime);
		linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
		day+'~'+tripFor+'~'+scenerio+'~'+travelstime+'~'+departfrm+'~'+travelTo+'~'+statusOftravel+'~'+arrAtBase+'~'+currNm
		+'~'+exchRate+'~'+perDiemUS+'~'+perDiemINR+'~'+hotelchrTax+'~'+hotelchrINR+'~'+taxiChrgF+'~'+taxiChrgINR+'~'+busTick+'~'+tickChrINR+'~'+otherAmtF
		+'~'+otherAmtINR+'~'+perhr+'~'+perhr1+'~'+rmks+'~'+totalAmt+'~'+byPass+'@@';
	}
	totalStr=linStr;
	//alert(totalStr);
	
	
}
if(document.masterInvExp.expCat.value=="Combined - Food and conveyance")
	{
		
		var prashidCounter = document.masterInvExp.prashidCounter.value;
		var lno="";
		var invno="";
		var invoiceDate="";
		var description="";
		var att1se="";
		var dotravel="";
		var day="";
		
		var typeofFood="";
		var empId="";
		var nmOfEmp="";
		var workReq="";
		var noOfEmp="";
		var noOfGuest="";
		var expenseAmt="";
		
		var travelFrm="";
		var travelTo="";
		var returnBackTo="";
		var modeOfTrans="";
		var vehicleNo="";
		var ratePKm="";
		var totalKm="";
		var parkingchrg="";
		var totalConAmt="";
		var remarks="";
		var byPasLoc="";
		
		var linStr="";
		var totalStr="";
		
		
		for(var i=1;i<=prashidCounter;i++){
			lno=document.getElementById("lnoComb"+i).value;
			/*invno=document.getElementById("invnoComb"+i).value;
			if(invno==''){
				alert("Please enter Invoice Number");
				return false;
			}
			invoiceDate=document.getElementById("invoiceDateComb"+i).value;
			if(invoiceDate==''){
				alert("Please enter Invoice Date");
				return false;
			}*/
			description=document.getElementById("descriptionComb"+i).value;
			if(description=='select'){
				alert("Please Select Nature Of Expense");
				return false;
			}
			att1se=document.getElementById("att1Comb"+i).value;
			if(att1se=='select'){
				alert("Please Select Expense Type");
				return false;
			}
			dotravel=document.getElementById("dotComb"+i).value;
			day=document.getElementById("dayComb"+i).value;
			
			travelFrm=document.getElementById("travFrmComb"+i).value;
			travelTo=document.getElementById("travToComb"+i).value;
			returnBackTo=document.getElementById("retBackComb"+i).value;
			modeOfTrans=document.getElementById("modeTranComb"+i).value;
			if(modeOfTrans=='select')modeOfTrans='';
			vehicleNo=document.getElementById("ownVehComb"+i).value;
			ratePKm=document.getElementById("ratePKComb"+i).value;
			totalKm=document.getElementById("totKMComb"+i).value;
			parkingchrg=document.getElementById("ParkTollComb"+i).value;			
			
			typeofFood=document.getElementById("typefoodexpComb"+i).value;
			if(typeofFood=='select')typeofFood='';
			empId=document.getElementById("empIdComb"+i).value;
			nmOfEmp=document.getElementById("nameOfEmpComb"+i).value;
			workReq=document.getElementById("workReqComb"+i).value;
			noOfEmp=document.getElementById("totalnoEmpComb"+i).value;
			noOfGuest=document.getElementById("noguestAuditComb"+i).value;
			expenseAmt=document.getElementById("expamountComb"+i).value;
			totalConAmt=document.getElementById("TotAmtComb"+i).value;
			remarks=document.getElementById("remarkComb"+i).value;			
			byPasLoc=document.getElementById("byPassComb"+i).value;
			
			if(remarks=='')remarks='-';
			if(byPasLoc=='')byPasLoc='-';
			
			linStr+=lno+'~'+invno+'~'+invoiceDate+'~'+description+'~'+att1se+'~'+dotravel+'~'+
			day+'~'+travelFrm+'~'+travelTo+'~'+returnBackTo+'~'+modeOfTrans+'~'+vehicleNo+'~'+ratePKm+'~'+totalKm+'~'+parkingchrg+'~'+
			typeofFood+'~'+empId+'~'+nmOfEmp+'~'+workReq+'~'+noOfEmp+'~'+noOfGuest+'~'+expenseAmt+'~'+totalConAmt+'~'+remarks+'~'+byPasLoc+
			'@@';
		}
		totalStr=linStr;
		
	//alert(totalStr);
	
	}
	
	
	var url="saveInvoiceExp?totalStr="+totalStr+"&fyear="+fyear+"&frmDate="+frmDate+"&toDate="+toDate+"&invtype="+invtype+"&expCat="+expCat;
	//alert(url);
	document.masterInvExp.action=url
	document.masterInvExp.method="POST";
	document.masterInvExp.submit();
}

function getCombfieldDtls(val){
		var ido=val.id;
		ido=ido.substring(8);
		document.getElementById('gtotal').value='';
		if(val.value=='FOOD_EXPENSE'){
			document.getElementById("typefoodexpComb"+ido).style.backgroundColor ="";
			document.getElementById("typefoodexpComb"+ido).disabled = false;
			document.getElementById("typefoodexpComb"+ido).value="select";
			
			document.getElementById("empIdComb"+ido).style.backgroundColor ="";
			document.getElementById("empIdComb"+ido).readOnly = false;
			document.getElementById("empIdComb"+ido).value="";
			
			document.getElementById("nameOfEmpComb"+ido).style.backgroundColor ="";
			document.getElementById("nameOfEmpComb"+ido).readOnly = false;
			document.getElementById("nameOfEmpComb"+ido).value="";
			
			document.getElementById("workReqComb"+ido).style.backgroundColor ="";
			document.getElementById("workReqComb"+ido).readOnly = false;
			document.getElementById("workReqComb"+ido).value="";
			
			document.getElementById("totalnoEmpComb"+ido).style.backgroundColor ="";
			document.getElementById("totalnoEmpComb"+ido).readOnly = false;
			document.getElementById("totalnoEmpComb"+ido).value="";
			
			document.getElementById("noguestAuditComb"+ido).style.backgroundColor ="";
			document.getElementById("noguestAuditComb"+ido).readOnly = false;
			document.getElementById("noguestAuditComb"+ido).value="";
			
			document.getElementById("expamountComb"+ido).style.backgroundColor ="";
			document.getElementById("expamountComb"+ido).readOnly = false;
			document.getElementById("expamountComb"+ido).value="";
			
			document.getElementById("TotAmtComb"+ido).style.backgroundColor ="";
			document.getElementById("TotAmtComb"+ido).readOnly = true;
			document.getElementById("TotAmtComb"+ido).value="";
			
						
			document.getElementById("travFrmComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("travFrmComb"+ido).readOnly = true;
			document.getElementById("travFrmComb"+ido).value="";
			
			document.getElementById("travToComb"+ido).value="";
			document.getElementById("travToComb"+ido).readOnly = true;
			document.getElementById("travToComb"+ido).style.backgroundColor ="#D9D9D1";  
			
			document.getElementById("retBackComb"+ido).value="";
			document.getElementById("retBackComb"+ido).readOnly = true;
			document.getElementById("retBackComb"+ido).style.backgroundColor ="#D9D9D1";  
			
			document.getElementById("modeTranComb"+ido).value="select";
			document.getElementById("modeTranComb"+ido).disabled = true;
			document.getElementById("modeTranComb"+ido).style.backgroundColor ="#D9D9D1";  
			
			document.getElementById("ownVehComb"+ido).value="";
			document.getElementById("ownVehComb"+ido).readOnly = true;
			document.getElementById("ownVehComb"+ido).style.backgroundColor ="#D9D9D1";  
			
			document.getElementById("ratePKComb"+ido).value="";
			document.getElementById("ratePKComb"+ido).readOnly = true;
			document.getElementById("ratePKComb"+ido).style.backgroundColor ="#D9D9D1";  
			
			document.getElementById("totKMComb"+ido).value="";
			document.getElementById("totKMComb"+ido).readOnly = true;
			document.getElementById("totKMComb"+ido).style.backgroundColor ="#D9D9D1"; 
			
			document.getElementById("ParkTollComb"+ido).value="";
			document.getElementById("ParkTollComb"+ido).readOnly = true;
			document.getElementById("ParkTollComb"+ido).style.backgroundColor ="#D9D9D1"; 
			
							
		}else if(val.value=='LOCAL_COVEYANCE'){
			document.getElementById("travFrmComb"+ido).style.backgroundColor ="";
			document.getElementById("travFrmComb"+ido).readOnly = false;
			document.getElementById("travFrmComb"+ido).value="";
			
			document.getElementById("travToComb"+ido).value="";
			document.getElementById("travToComb"+ido).readOnly = false;
			document.getElementById("travToComb"+ido).style.backgroundColor ="";  
			
			document.getElementById("retBackComb"+ido).value="";
			document.getElementById("retBackComb"+ido).readOnly = false;
			document.getElementById("retBackComb"+ido).style.backgroundColor ="";  
			
			document.getElementById("modeTranComb"+ido).value="select";
			document.getElementById("modeTranComb"+ido).disabled = false;
			document.getElementById("modeTranComb"+ido).style.backgroundColor ="";  
			
			document.getElementById("ownVehComb"+ido).value="";
			document.getElementById("ownVehComb"+ido).readOnly = false;
			document.getElementById("ownVehComb"+ido).style.backgroundColor ="";  
			
			document.getElementById("ratePKComb"+ido).value="";
			document.getElementById("ratePKComb"+ido).readOnly = true;
			document.getElementById("ratePKComb"+ido).style.backgroundColor ="";  
			
			document.getElementById("totKMComb"+ido).value="";
			document.getElementById("totKMComb"+ido).readOnly = false;
			document.getElementById("totKMComb"+ido).style.backgroundColor =""; 
			
			document.getElementById("ParkTollComb"+ido).value="";
			document.getElementById("ParkTollComb"+ido).readOnly = false;
			document.getElementById("ParkTollComb"+ido).style.backgroundColor =""; 
			
			document.getElementById("typefoodexpComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("typefoodexpComb"+ido).disabled = true;
			document.getElementById("typefoodexpComb"+ido).value="select";
			
			document.getElementById("empIdComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("empIdComb"+ido).readOnly = true;
			document.getElementById("empIdComb"+ido).value="";
			
			document.getElementById("nameOfEmpComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("nameOfEmpComb"+ido).readOnly = true;
			document.getElementById("nameOfEmpComb"+ido).value="";
			
			document.getElementById("workReqComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("workReqComb"+ido).readOnly = true;
			document.getElementById("workReqComb"+ido).value="";
			
			document.getElementById("totalnoEmpComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("totalnoEmpComb"+ido).readOnly = true;
			document.getElementById("totalnoEmpComb"+ido).value="";
			
			document.getElementById("noguestAuditComb"+ido).style.backgroundColor ="#D9D9D1";
			document.getElementById("noguestAuditComb"+ido).readOnly = true;
			document.getElementById("noguestAuditComb"+ido).value="";
			
			document.getElementById("expamountComb"+ido).style.backgroundColor ="";
			document.getElementById("expamountComb"+ido).readOnly = false;
			document.getElementById("expamountComb"+ido).value="";
			
			document.getElementById("TotAmtComb"+ido).style.backgroundColor ="";
			document.getElementById("TotAmtComb"+ido).readOnly = true;
			document.getElementById("TotAmtComb"+ido).value="";
			
			
		}
}

function getCombmotrans(val){
	var ido=val.id;
	ido=ido.substring(8);
	document.getElementById('modeTranComb'+ido).length = 1;
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat="Local Conveyance";
	    var url="getAttribute2Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetCombmotrans
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetCombmotrans() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	           	document.getElementById('modeTranComb'+attidval).options.add(optn);
	          
				
	            }
	            	       
	    }
	    
}

function getCombtypeOfFood(val){
		var ido=val.id;
		ido=ido.substring(8);
		document.getElementById('typefoodexpComb'+ido).length = 1;
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat="Food Expense";
		    var url="getAttribute2Val?expCat="+expCat+"&id="+ido;
		    //alert(url);
		    xmlHttp.onreadystatechange=stateChangedgetCombtypeOfFood
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		
	}	 
		function stateChangedgetCombtypeOfFood() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att2");
		           //alert(desc.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = glCode[0].firstChild.data;
		            	optn.text = glCode[0].firstChild.data;
		           	document.getElementById('typefoodexpComb'+attidval).options.add(optn);
		          
					
		            }
		            	       
		    }
		    
	}	
	
function getCombFields(val){
	
	if(val.value!='select'){
	if(val.value=='LOCAL_COVEYANCE'){
		getCombmotrans(val);
	}else{
		getCombtypeOfFood(val);
	 }
	}	
}

function searchprepaywinInv(){
	
	/*if(document.getElementById("suppliernm").value==''){
		alert("Please Select Supplier");
		return false;
	}
	
	if(document.getElementById("supplierSite").value==''){
		alert("Please Select Supplier Site");
		return false;
	}
	
	var supplierid=document.getElementById("supplierid").value;
	var supplierSiteid=document.getElementById("siteid").value;*/
	
	var url="searchprepaymentInv";
	window.open(url,'Search PrePayment','width=800,height=400,resizable=no');
}

function getDayFol(val){
	
	if(val.value!=''){
		if(document.masterInvExp.expCat.value=="OutStation Travel"){
	var id=val.id.substring(8);
	
	var seld=val.value;
	var myArray1 = seld.split('-');
	var target1 = myArray1[2] + myArray1[1] + myArray1[0];
	var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
	
	var d=new Date(tarDate);
	
	var n=weekday[d.getDay()];
	
	document.getElementById("day"+id).value=n;
		}
		
		if(document.masterInvExp.expCat.value=="Entertainment"){
			var id=val.id.substring(8);
			
			var seld=val.value;
			var myArray1 = seld.split('-');
			var target1 = myArray1[2] + myArray1[1] + myArray1[0];
			var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
			
			var d=new Date(tarDate);
			
			var n=weekday[d.getDay()];
			
			document.getElementById("dayEnter"+id).value=n;
				}
	
		if(document.masterInvExp.expCat.value=="Food Expense"){
			var id=val.id.substring(7);
			
			var seld=val.value;
			var myArray1 = seld.split('-');
			var target1 = myArray1[2] + myArray1[1] + myArray1[0];
			var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
			
			var d=new Date(tarDate);
			
			var n=weekday[d.getDay()];
			
			document.getElementById("dayFood"+id).value=n;
				}
	
		if(document.masterInvExp.expCat.value=="Local Conveyance"){
			var id=val.id.substring(9);
			
			var seld=val.value;
			var myArray1 = seld.split('-');
			var target1 = myArray1[2] + myArray1[1] + myArray1[0];
			var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
			
			var d=new Date(tarDate);
			
			var n=weekday[d.getDay()];
			
			document.getElementById("daylocalC"+id).value=n;
				}
		if(document.masterInvExp.expCat.value=="Miscellaneous"){
			var id=val.id.substring(8);
			
			var seld=val.value;
			var myArray1 = seld.split('-');
			var target1 = myArray1[2] + myArray1[1] + myArray1[0];
			var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
			
			var d=new Date(tarDate);
			
			var n=weekday[d.getDay()];
			
			document.getElementById("dayMisce"+id).value=n;
				}
		if(document.masterInvExp.expCat.value=="International Travel"){
			var id=val.id.substring(14);
			
			var seld=val.value;
			var myArray1 = seld.split('-');
			var target1 = myArray1[2] + myArray1[1] + myArray1[0];
			var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
			
			var d=new Date(tarDate);
			
			var n=weekday[d.getDay()];
			
			document.getElementById("dayInterN"+id).value=n;
				}
		if(document.masterInvExp.expCat.value=="Combined - Food and conveyance"){
			var id=val.id.substring(7);
			
			var seld=val.value;
			var myArray1 = seld.split('-');
			var target1 = myArray1[2] + myArray1[1] + myArray1[0];
			var tarDate=myArray1[2]+'/'+myArray1[1]+'/'+myArray1[0];
			
			var d=new Date(tarDate);
			
			var n=weekday[d.getDay()];
			
			document.getElementById("dayComb"+id).value=n;
				}
	}
}


function getTotal(){
		
	var prashidCounter = document.masterInvExp.prashidCounter.value;
	var gTot=0;
	var expType=document.masterInvExp.expCat.value;
 for(var i=1;i<=prashidCounter;i++){	
	 var toalTemp=0;
	
	if(expType=='OutStation Travel'){ 
	 var att1se=document.getElementById("att1se"+i).value;
	if(att1se=='select'){
		alert("Please Select Expense Type in Row"+i);
		return false;
	}else{
		var att1Select = document.getElementById("att1se"+i);
		att1se = att1Select.options[att1Select.selectedIndex].text;
	}
	
	if(att1se=='Taxi Expense' || att1se=='Tickets Expense'){
		var tick=document.getElementById('ticket'+i).value;
		if(tick=='')tick=0;
		toalTemp=parseInt(tick);
		
	}
	
	if(att1se=='Additional Boarding Allowance'){
		var abam=document.getElementById('abaAmt'+i).value;
		if(abam=='')abam=0;
		toalTemp=parseInt(abam);
	}
	
	if(att1se=='Conveyance Expense'){
		var modTrans=document.getElementById("motrans"+i).value;
		var parToll=document.getElementById('tollPark'+i).value;
		if(parToll=='')parToll=0;
		if(modTrans!='Metro'){
		var rpk=document.getElementById('rpk'+i).value;
		var totalkm=document.getElementById('totalkm'+i).value;		
		if(totalkm=='')totalkm=0;
		if(rpk=='')rpk=0;		
		toalTemp=parseInt(rpk)*parseInt(totalkm);
		toalTemp=parseInt(toalTemp)+parseInt(parToll);
		document.getElementById('convAmt'+i).value=toalTemp;
		}
		else{
		toalTemp=document.getElementById('convAmt'+i).value;
		toalTemp=parseInt(toalTemp)+parseInt(parToll);	
		}
	}
	
	if(att1se=='Food Expense Out Station'){
	var	breakFast=document.getElementById("breakFast"+i).value;
	var	lunch=document.getElementById("lunch"+i).value;
	var	dinner=document.getElementById("dinner"+i).value;
	
	if(breakFast=='')breakFast=0;
	if(lunch=='')lunch=0;
	if(dinner=='')dinner=0;
	
	toalTemp=parseInt(breakFast)+parseInt(lunch)+parseInt(dinner);
	
	}		
	if(att1se=='Others Expense'){
	var	others=document.getElementById("others"+i).value;
	if(others=='')others=0;
		toalTemp=parseInt(others);
	}
	
	if(att1se=='Hotel Charges and Taxes'){
		var hotCharg=document.getElementById("hotelchramt"+i).value;
		var hotlTax=document.getElementById("taxhotelch"+i).value;
		if(hotCharg=='')hotCharg=0;
		if(hotlTax=='')hotlTax=0;
		toalTemp=parseInt(hotCharg)+parseInt(hotlTax);			
     }
	document.getElementById('total'+i).value=toalTemp;
	}
	if(expType=='Entertainment'){
		var expAmt=document.getElementById("amountEnter"+i).value;
		if(expAmt=='')expAmt=0;
		toalTemp=parseInt(expAmt);
		document.getElementById('amountEnter'+i).value=toalTemp;	
	}
	
	if(expType=='Food Expense'){
		var expFoodAmt=document.getElementById("expamountFood"+i).value;
		if(expFoodAmt=='')expFoodAmt=0;
		toalTemp=parseInt(expFoodAmt);		
		document.getElementById('totalFood'+i).value=toalTemp;
	}
	if(expType=='Local Conveyance'){
		var modTrans=document.getElementById("modeTranlocalC"+i).value;
		if(modTrans!='Metro'){
		var rpk=document.getElementById('ratePKlocalC'+i).value;
		var totalkm=document.getElementById('totKMlocalC'+i).value;
		var parkTax=document.getElementById('ParkTolllocalC'+i).value;
		if(totalkm=='')totalkm=0;
		if(rpk=='')rpk=0;
		if(parkTax=='')parkTax=0;
		toalTemp=parseInt(rpk)*parseInt(totalkm);
		toalTemp=parseInt(toalTemp)+parseInt(parkTax);
		document.getElementById('ConvTotlocalC'+i).value=toalTemp;
		}
		else{
		var parkTax=document.getElementById('ParkTolllocalC'+i).value;
		var totalkm=document.getElementById('totKMlocalC'+i).value;
		if(totalkm=='')totalkm=0;
		if(parkTax=='')parkTax=0;
		toalTemp=parseInt(totalkm)+parseInt(parkTax);
		document.getElementById('ConvTotlocalC'+i).value=toalTemp;
		}
		document.getElementById('TotAmtlocalC'+i).value=toalTemp;
	}
	if(expType=='Miscellaneous'){
		var misceAmt=document.getElementById("amountMisce"+i).value;
		if(misceAmt=='')misceAmt=0;
		toalTemp=parseInt(misceAmt);
		document.getElementById('TotAmtMiscC'+i).value=toalTemp;
	}
	if(expType=='International Travel'){
		var excRt=document.getElementById("excRtInterN"+i).value;
		if(excRt=='')excRt=0;
		if(document.getElementById('att1seInterN'+i).value=='TAXI_CHARGES'){
			var taxiFore=document.getElementById("taxichrFInterN"+i).value;
			if(taxiFore=='')taxiFore=0;
			
			toalTemp=parseInt(taxiFore)*parseInt(excRt);
			document.getElementById("taxichrInterN"+i).value=toalTemp;
		}
		if(document.getElementById('att1seInterN'+i).value=='OTHERS_2'){
			var otherAmtFore=document.getElementById("othersFAmtInterN"+i).value;
			if(otherAmtFore=='')otherAmtFore=0;
			toalTemp=parseInt(otherAmtFore)*parseInt(excRt);
			document.getElementById("othersAmtInterN"+i).value=toalTemp;		
		}
		if(document.getElementById('att1seInterN'+i).value=='FIXED_ALLOWANCE'){
		 var perDiemAmt=document.getElementById("perDiemInterN"+i).value;
		 if(perDiemAmt=='')perDiemAmt=0;
		 	toalTemp=parseInt(perDiemAmt)*parseInt(excRt);
			document.getElementById("perDiemINRInterN"+i).value=toalTemp;	
		}
		if(document.getElementById('att1seInterN'+i).value=='TICKET_CHARGES'){
			 var busTktAmt=document.getElementById("buschrFInterN"+i).value;
			 if(busTktAmt=='')busTktAmt=0;
			   toalTemp=parseInt(busTktAmt)*parseInt(excRt);
			document.getElementById("buschrInterN"+i).value=toalTemp;	
		}
		
		if(document.getElementById('att1seInterN'+i).value=='HOTEL_CHARGES'){
			 var htoeltxAmt=document.getElementById("hotlTaxInterN"+i).value;
			 if(htoeltxAmt=='')htoeltxAmt=0;
			   toalTemp=parseInt(htoeltxAmt)*parseInt(excRt);
			document.getElementById("hotelchrInterN"+i).value=toalTemp;	
		}
		
		/*toalTemp=parseInt(hotelChr)+parseInt(hotelTax)+parseInt(taxiFore)+parseInt(taxiChr)+parseInt(bustickFore)+parseInt(bustick)+parseInt(otherAmtFore)+parseInt(otherAmt);
		document.getElementById('TotAmtInterN'+i).value=toalTemp;*/
		//toalTemp=parseInt(perDiemAmt)+parseInt(hotelTax)+parseInt(taxiChr)+parseInt(bustick)+parseInt(otherAmt);
		document.getElementById('TotAmtInterN'+i).value=toalTemp;
	}
	
	if(expType=='Combined - Food and conveyance'){
		 var att1comb=document.getElementById("att1Comb"+i).value;
			if(att1comb=='select'){
				alert("Please Select Expense Type in Row"+i);
				return false;
			}else{
				var att1combSelect = document.getElementById("att1Comb"+i);
				att1comb = att1combSelect.options[att1combSelect.selectedIndex].text;
			}
			
			if(att1comb=='Food Expense'){
				var expComb=document.getElementById('expamountComb'+i).value;
				if(expComb=='')expComb=0;
				toalTemp=parseInt(expComb);
				document.getElementById('TotAmtComb'+i).value=toalTemp;	
			}
			if(att1comb=='Local Conveyance'){
				var modTrans=document.getElementById("modeTranComb"+i).value;
				if(modTrans!='Metro'){
				var rpk=document.getElementById('ratePKComb'+i).value;
				var totalkm=document.getElementById('totKMComb'+i).value;
				var parkTax=document.getElementById('ParkTollComb'+i).value;
				if(totalkm=='')totalkm=0;
				if(rpk=='')rpk=0;
				if(parkTax=='')parkTax=0;
				toalTemp=parseInt(rpk)*parseInt(totalkm);
				toalTemp=parseInt(toalTemp)+parseInt(parkTax);
				document.getElementById('expamountComb'+i).value=toalTemp;
				}
				else{
				var parkTax=document.getElementById('ParkTollComb'+i).value;
				var totalkm=document.getElementById('totKMComb'+i).value;
				var expAmt=document.getElementById('expamountComb'+i).value;
				if(totalkm=='')totalkm=0;
				if(parkTax=='')parkTax=0;
				if(expAmt=='')expAmt=0;
				toalTemp=parseInt(totalkm)+parseInt(parkTax)+parseInt(expAmt);
				//document.getElementById('expamountComb'+i).value=toalTemp;
				}
				document.getElementById('TotAmtComb'+i).value=toalTemp;
			}
	}
	
	gTot=parseInt(gTot)+parseInt(toalTemp);
 }
 document.getElementById('gtotal').value=gTot;
}

function airAlert(val){
	
	var ido=val.id;
	ido=ido.substring(9);
	
	document.getElementById('convAmt'+ido).value='';
	document.getElementById('total'+ido).value='';
	document.getElementById('gtotal').value='';		         
	
	if(val.value=='Air'){
		alert('Original Boarding pass need to submit along with claim');
	}
	
}

function abaAlert(val){
	
	var ido=val.id;
	ido=ido.substring(6);
	
	if(val.value!=''){
		alert('ABA allowed only for working on Holidays / Weekly Off');
		getTotal();
	}
	
}
function remTotalAmt(val){
	var ido=val.id;
	ido=ido.substring(15);
	
	if(ido=='' || ido==undefined)ido=val.id.substring(10);
	
	document.getElementById('expamountFood'+ido).value='';
	document.getElementById('totalFood'+ido).value='';
	document.getElementById('gtotal').value='';
}

function resetOutstFields(val){
	var ido=val.id;
	ido=ido.substring(8);
	
	document.getElementById('travelto'+ido).value='';
	document.getElementById('motrans'+ido).value='';
	
	document.getElementById('total'+ido).value='';
	
	document.getElementById('gtotal').value='';
	
}

function getExchRate(val){
	var ido=val.id;
	ido=ido.substring(12);
	
	document.getElementById('excRtInterN'+ido).value = '';
	
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	    var currNm=val.value;
	    var url="getExchRtVal?currNm="+currNm+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetExchRt
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetExchRt() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	           
	            	var glCode=desc[0].getElementsByTagName("cat");
	            	var attid=desc[0].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var exhRtVal=glCode[0].firstChild.data;
	           	document.getElementById('excRtInterN'+attidval).value=exhRtVal;
	          
	            	       
	    }
}
	function validateHhMm(inputField) {
      //  var isValid = /^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(inputField.value);
		var isValid = /^(1[012]|[0-9]):[0-5][0-9](?:\s)?$/.test(inputField.value);

        if (isValid) {
            inputField.style.backgroundColor = '';
            return isValid;
        } else {
            inputField.style.backgroundColor = '#fba';
            alert("Enter Correct Time Format like 4:00,8:53,12:20");
            return false;
        }        
    }

/*function getTotlTrvTym(val){
	
	var ido=val.id;
	ido=ido.substring(11);
	if(ido=='' || ido==undefined)ido=val.id.substring(9);
	
	var str1=document.getElementById('travelstime'+ido).value;
	var str2=document.getElementById('arratbase'+ido).value;
	
    if(str1 === str2){
        return 0;
    }
    var time1 = str1.split(':');
    var time2 = str2.split(':');
    if(eval(time1[0]) > eval(time2[0])){
        alert('');
    } else if(eval(time1[0]) == eval(time2[0]) && eval(time1[1]) > eval(time2[1])) {
        return 1;
    } else {
        return -1;
    }
}*/
	
function disabInterFields(val){
	
	var ido=val.id;
	ido=ido.substring(13);
	if(ido=='' || ido==undefined)ido=val.id.substring(12);
	if(ido=='' || ido==undefined)ido=val.id.substring(11);
	
	document.getElementById("perDiemInterN"+ido).value='';
	document.getElementById("perDiemINRInterN"+ido).value='';
	document.getElementById("hotlTaxInterN"+ido).value='';
	document.getElementById("hotelchrInterN"+ido).value='';
	document.getElementById("taxichrFInterN"+ido).value='';
	document.getElementById("taxichrInterN"+ido).value='';
	document.getElementById("buschrFInterN"+ido).value='';
	document.getElementById("othersFAmtInterN"+ido).value='';
	document.getElementById("othersAmtInterN"+ido).value='';
	document.getElementById('TotAmtInterN'+ido).value='';
	document.getElementById('gtotal').value='';		
	
}