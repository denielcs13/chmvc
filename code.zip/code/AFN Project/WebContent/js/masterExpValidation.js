function getAtt1(val){
	var ido=val.id;
	
	ido=ido.substring(6);
	
	//alert(ido);
	document.getElementById('att1se'+ido).length = 1;
	//if(val.value=='OutStation Travel'){
		document.getElementById("att1sel"+ido).style.display="block";
		document.getElementById("att1txt"+ido).style.display="none";
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat=val.value;
	    var url="getAttribute1Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAtt1
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	/*}else{
		document.getElementById("att1sel"+ido).style.display="none";
		document.getElementById("att1txt"+ido).style.display="block";
        getAtt2(val);
	}*/
}	 
	function stateChangedgetAtt1() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att1");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt1");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	            	
	           	document.getElementById('att1se'+attidval).options.add(optn);
	          
				
	            }
	            var passval=document.getElementById("expcat"+attidval);
	            //alert(passval);
	            getAtt2(passval);
	    }
	    
	}
	
	function getAtt2(val){
		var ido=val.id;
		ido=ido.substring(6);
		
		document.getElementById('att2se'+ido).length = 1;
		if(val.value=='OutStation Travel' || val.value=='International Travel' || val.value=='Local Conveyance' || val.value=='Food Expense'){
			document.getElementById('att2sel'+ido).style.display="block";
			document.getElementById("att2txt"+ido).style.display="none";
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat=val.value;
		    var url="getAttribute2Val?expCat="+expCat+"&id="+ido;	    
		    xmlHttp.onreadystatechange=stateChangedgetAtt2
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		}else{
			document.getElementById('att2sel'+ido).style.display="none";
			document.getElementById("att2txt"+ido).style.display="block";
			getAtt3(val);
		}
	}	 
		function stateChangedgetAtt2() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att2");
		           //alert(dept.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = glCode[0].firstChild.data;
		            	optn.text = glCode[0].firstChild.data;
		           	document.getElementById('att2se'+attidval).options.add(optn);
		          
					
		            }
		            var passval=document.getElementById("expcat"+attidval);
		            getAtt3(passval);		       
		    }
		    
		}
function getAtt3(val){
	var ido=val.id;
	ido=ido.substring(6);
			document.getElementById('att3se'+ido).length = 1;
			if(val.value=='OutStation Travel' || val.value=='International Travel'){
				document.getElementById('att3sel'+ido).style.display="block";
				document.getElementById("att3txt"+ido).style.display="none";	
			 xmlHttp=GetXmlHttpObject()
			    if (xmlHttp==null)
			    {
			      alert ("Browser does not support HTTP Request");
			      return;
			    }
			 var expCat=val.value;
			    var url="getAttribute3Val?expCat="+expCat+"&id="+ido;	    
			    xmlHttp.onreadystatechange=stateChangedgetAtt3
			    xmlHttp.open("GET",url,true);
			    xmlHttp.send(null);
			}else if(val.value=='Local Conveyance'){
				document.getElementById('att3sel'+ido).style.display="none";
				document.getElementById("att3txt"+ido).style.display="block";
				document.getElementById("att3tx"+ido).value="Rate per KM";
				getAtt4(val);
			}else{
				document.getElementById('att3sel'+ido).style.display="none";
				document.getElementById("att3txt"+ido).style.display="block";
				document.getElementById("att3tx"+ido).value="Rate per KM";
				getAtt4(val);
			}
		}	 
function stateChangedgetAtt3() 
			{ 
				
			    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
			    { 
			    	 //alert(xmlHttp.responseXML);
			    	
			    	 var xmlDoc = xmlHttp.responseXML.documentElement;
			           var desc = xmlDoc.getElementsByTagName("att2");
			           //alert(dept.length);
			            for (i = 0; i < desc.length ; i++)
			            {
			            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
			            	var attid=desc[i].getElementsByTagName("ids");
			            	var attidval=attid[0].firstChild.data;
			            	
			            	var optn = document.createElement("OPTION");
			            	
			            	optn.value = glCode[0].firstChild.data;
			            	optn.text = glCode[0].firstChild.data;
			           	document.getElementById('att3se'+attidval).options.add(optn);
			          
						
			            }
			            var passval=document.getElementById("expcat"+attidval);
			            getAtt4(passval); 
			    }
			    
			}
function getAtt4(val){
	var ido=val.id;
	ido=ido.substring(6);
	document.getElementById('att4se'+ido).length = 1;
	if(val.value=='OutStation Travel' || val.value=='International Travel'){
		document.getElementById('att4sel'+ido).style.display="block";
		document.getElementById("att4txt"+ido).style.display="none";
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat=val.value;
	    var url="getAttribute4Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAtt4
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	}else{
		document.getElementById('att4sel'+ido).style.display="none";
		document.getElementById("att4txt"+ido).style.display="block";
		getAtt5(val);
	}
}	 
	function stateChangedgetAtt4() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	            	document.getElementById('att4se'+attidval).options.add(optn);
	          
				
	            }
	            var passval=document.getElementById("expcat"+attidval);
	            getAtt5(passval);
	    }
	    
	}
function getAtt5(val){
	var ido=val.id;
	ido=ido.substring(6);
		document.getElementById('att5se'+ido).length = 1;
		
		if(val.value=='International Travel'){
			document.getElementById('att5sel'+ido).style.display="block";
			document.getElementById("att5txt"+ido).style.display="none";
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 var expCat=val.value;
		    var url="getAttribute5Val?expCat="+expCat+"&id="+ido;	    
		    xmlHttp.onreadystatechange=stateChangedgetAtt5
		    xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		}else{
			document.getElementById('att5sel'+ido).style.display="none";
			document.getElementById("att5txt"+ido).style.display="block";
			document.getElementById("att5tx"+ido).value='Rate per KM';
			getAtt6(val);
		}
	}	 
		function stateChangedgetAtt5() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		    { 
		    	 //alert(xmlHttp.responseXML);
		    	
		    	 var xmlDoc = xmlHttp.responseXML.documentElement;
		           var desc = xmlDoc.getElementsByTagName("att2");
		           //alert(dept.length);
		            for (i = 0; i < desc.length ; i++)
		            {
		            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
		            	var attid=desc[i].getElementsByTagName("ids");
		            	var attidval=attid[0].firstChild.data;
		            	var optn = document.createElement("OPTION");
		            	
		            	optn.value = glCode[0].firstChild.data;
		            	optn.text = glCode[0].firstChild.data;
		            	document.getElementById('att5se'+attidval).options.add(optn);
		          
					
		            }
		            var passval=document.getElementById("expcat"+attidval);
		            getAtt6(passval);
		    }
		    
		}	
		
function getAtt6(val){
	var ido=val.id;
	ido=ido.substring(6);
		document.getElementById('att6se'+ido).length = 1;
	if(val.value=='OutStation Travel'){
		document.getElementById('att6sel'+ido).style.display="block";
		document.getElementById("att6txt"+ido).style.display="none";
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat=val.value;
	    var url="getAttribute6Val?expCat="+expCat+"&id="+ido;	    
	    xmlHttp.onreadystatechange=stateChangedgetAtt6
	    xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	}else{
		document.getElementById('att6sel'+ido).style.display="none";
		document.getElementById("att6txt"+ido).style.display="block";
		getAtt7(val);
	}
}	 
	function stateChangedgetAtt6() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	    { 
	    	 //alert(xmlHttp.responseXML);
	    	
	    	 var xmlDoc = xmlHttp.responseXML.documentElement;
	           var desc = xmlDoc.getElementsByTagName("att2");
	           //alert(dept.length);
	            for (i = 0; i < desc.length ; i++)
	            {
	            	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	            	var attid=desc[i].getElementsByTagName("ids");
	            	var attidval=attid[0].firstChild.data;
	            	var optn = document.createElement("OPTION");
	            	
	            	optn.value = glCode[0].firstChild.data;
	            	optn.text = glCode[0].firstChild.data;
	            	document.getElementById('att6se'+attidval).options.add(optn);
	          
				
	            }
	            var passval=document.getElementById("expcat"+attidval);
	            getAtt7(passval);
	    }
	    
	}
	function getAtt7(val){
		var ido=val.id;
		ido=ido.substring(6);
		document.getElementById('att7se'+ido).length = 1;
	if(val.value=='OutStation Travel'){
		document.getElementById('att7sel'+ido).style.display="block";
		document.getElementById("att7txt"+ido).style.display="none";
	 xmlHttp=GetXmlHttpObject()
	    if (xmlHttp==null)
	    {
	      alert ("Browser does not support HTTP Request");
	      return;
	    }
	 var expCat=val.value;
	    var url="getAttribute7Val?expCat="+expCat+"&id="+ido;	    
	xmlHttp.onreadystatechange=stateChangedgetAtt7
	xmlHttp.open("GET",url,true);
		    xmlHttp.send(null);
		}else{
			document.getElementById('att7sel'+ido).style.display="none";
			document.getElementById("att7txt"+ido).style.display="block";
			//getAtt7(val);
		}
	}	 
		function stateChangedgetAtt7() 
		{ 
			
		    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
	{ 
		 //alert(xmlHttp.responseXML);
		
		 var xmlDoc = xmlHttp.responseXML.documentElement;
	       var desc = xmlDoc.getElementsByTagName("att2");
	       //alert(dept.length);
	        for (i = 0; i < desc.length ; i++)
	        {
	        	var glCode=desc[i].getElementsByTagName("expenseAtt2");
	        	var attid=desc[i].getElementsByTagName("ids");
            	var attidval=attid[0].firstChild.data;
            	
	        	var optn = document.createElement("OPTION");
	        	
	        	optn.value = glCode[0].firstChild.data;
	        	optn.text = glCode[0].firstChild.data;
	        	document.getElementById('att7se'+attidval).options.add(optn);
	      
			
	        }
	        
	    }
	    
	}	
function checkexpMaster(){
	var prashidCounter = document.masterExp.prashidCounter.value;
	var empgrdval='';
	var empgrdarr='';
	var expcatval='';
	var expcatarr='';
	var att1tval='';
	var att1arr='';
	var att2tval='';
	var att2arr='';
	var att3tval;
	var att3arr;
	var att4tval;
	var att4arr;
	var att5tval;
	var att5arr;
	var att6tval;
	var att6arr;
	var att7tval;
	var att7arr;
	
	var att8tval;
	var att9tval;
	var att10tval;
	var currencyval;
	var amountval;
	var frmdtval;
	var todtval;
	
	var totalStr='';
	var linStr='';
	for(var i=1;i<=prashidCounter;i++){
		
		if(document.getElementById('empgrd' + i).value == 'select'){
			alert("Please Select Expense Category");
			return false; 
		}		
		else if(document.getElementById('expcat' + i).value == 'select'){
			alert("Please Select Expense Category");
			return false; 
		}
		/*else if(document.getElementById('frmDate' + i).value == ''){
			alert("Please select From Date");
			return false;
		}
		else if(document.getElementById('toDate' + i).value == ''){
			alert("Please select To Date");
			return false;
		}*/
		else if(document.getElementById('att1se' + i).value== 'select' && document.getElementById('att1tx' + i).value==''){
				alert("Please Fill Attribute1 Value");
				return false;
		}
		else{
			empgrdval=document.getElementById('empgrd' + i).value;
			//empgrdarr+=empgrdval+'~';
			
			expcatval=document.getElementById('expcat' + i).value;
			//expcatarr+=expcatval+'~';
			
			if(document.getElementById('att1se' + i).value== 'select'){
				att1tval=document.getElementById('att1tx' + i).value;
			}else{
				att1tval=document.getElementById('att1se' + i).value;
			}
			//att1arr+=att1tval+'~';
			
			if(document.getElementById('att2se' + i).value== 'select'){
				att2tval=document.getElementById('att2tx' + i).value;
			}else{
				att2tval=document.getElementById('att2se' + i).value;
			}
			if(document.getElementById('att3se' + i).value== 'select'){
				att3tval=document.getElementById('att3tx' + i).value;
			}else{
				att3tval=document.getElementById('att3se' + i).value;
			}
			if(document.getElementById('att4se' + i).value== 'select'){
				att4tval=document.getElementById('att4tx' + i).value;
			}else{
				att4tval=document.getElementById('att4se' + i).value;
			}
			if(document.getElementById('att5se' + i).value== 'select'){
				att5tval=document.getElementById('att2tx' + i).value;
			}else{
				att5tval=document.getElementById('att2se' + i).value;
			}
			if(document.getElementById('att2se' + i).value== 'select'){
				att2tval=document.getElementById('att2tx' + i).value;
			}else{
				att2tval=document.getElementById('att2se' + i).value;
			}
			if(document.getElementById('att2se' + i).value== 'select'){
				att2tval=document.getElementById('att2tx' + i).value;
			}else{
				att2tval=document.getElementById('att2se' + i).value;
			}
			if(document.getElementById('att3se' + i).value== 'select'){
				att3tval=document.getElementById('att3tx' + i).value;
			}else{
				att3tval=document.getElementById('att3se' + i).value;
			}
			if(document.getElementById('att4se' + i).value== 'select'){
				att4tval=document.getElementById('att4tx' + i).value;
			}else{
				att4tval=document.getElementById('att4se' + i).value;
			}
			if(document.getElementById('att5se' + i).value== 'select'){
				att5tval=document.getElementById('att5tx' + i).value;
			}else{
				att5tval=document.getElementById('att5se' + i).value;
			}
			if(document.getElementById('att6se' + i).value== 'select'){
				att6tval=document.getElementById('att6tx' + i).value;
			}else{
				att6tval=document.getElementById('att6se' + i).value;
			}
			if(document.getElementById('att7se' + i).value== 'select'){
				att7tval=document.getElementById('att7tx' + i).value;
			}else{
				att7tval=document.getElementById('att7se' + i).value;
			}
			
			att8tval=document.getElementById('att8tx' + i).value;
			att9tval=document.getElementById('att9tx' + i).value;
			att10tval=document.getElementById('att10tx' + i).value;
			
			currencyval=document.getElementById('currency' + i).value;
			amountval=document.getElementById('amount' + i).value;
			frmdtval=document.getElementById('frmDate' + i).value;
			todtval=document.getElementById('toDate' + i).value;
			//att2arr+=att2tval+'~';
			if(att1tval=='')att1tval='-';
			if(att2tval=='')att2tval='-';
			if(att3tval=='')att3tval='-';
			if(att4tval=='')att4tval='-';
			if(att5tval=='')att5tval='-';
			if(att6tval=='')att6tval='-';
			if(att7tval=='')att7tval='-';
			if(att8tval=='')att8tval='-';
			if(att9tval=='')att9tval='-';
			if(att10tval=='')att10tval='-';
			if(frmdtval=='')frmdtval='-';
			if(todtval=='')todtval='-';
			
			linStr+=empgrdval+'~'+expcatval+'~'+att1tval+'~'+att2tval+'~'+att3tval+'~'+att4tval+'~'+
					att5tval+'~'+att6tval+'~'+att7tval+'~'+att8tval+'~'+att9tval+'~'+att10tval+'~'+currencyval+'~'+amountval+'~'+frmdtval
					+'~'+todtval+'@@';
			
		}
		
	}
	totalStr=linStr;
	//alert(totalStr);
	document.masterExp.action="savemasterExp?totalStr="+totalStr;
	document.masterExp.method="POST";
	document.masterExp.submit();
}

function addmasterRow(){
	
	var prashidCounter = document.masterExp.prashidCounter.value;
	if (document.getElementById('empgrd' + prashidCounter).value == 'select' || document.getElementById('expcat' + prashidCounter).value == 'select')
	{
		alert("Please fill the last row first.");
		return false;
	}
	
	if (document.masterExp.ch.length == undefined) {
		document.masterExp.ch.disabled = false;
	}
	if (document.masterExp.ch.length == 1) {
		document.masterExp.ch[0].disabled = false;
	}
	prashidCounter = parseInt(prashidCounter) + 1;
	document.masterExp.prashidCounter.value = prashidCounter;
	//alert(document.getElementById('innerTable').tBodies[0]);
	var tblBody = document.getElementById('innerTable').tBodies[0];
	var slrow = document.getElementById("thirdrowf");
	//var extrarow=document.getElementById("trrow");
	
	var newline = slrow.cloneNode(false);
	
	var newline00 = slrow.cells[0].cloneNode(false);
	newline00.innerHTML = '<select name="empgrd'+ prashidCounter + '" id="empgrd'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select>';
	var empgrdselect = newline00.getElementsByTagName('select');
	empgrdselect.id = 'empgrd' + prashidCounter;
	newline.appendChild(newline00);
	
	var newline01 = slrow.cells[1].cloneNode(false);
	newline01.innerHTML = '<select name="expcat'+ prashidCounter + '" id="expcat'+ prashidCounter + '" style="border-color: #59839E;width: 100%" onchange="getAtt1(this);"> <option value="select">--Select--</option></select>';
	var expcatselect = newline01.getElementsByTagName('select');
	expcatselect.id = 'expcat' + prashidCounter;
	newline.appendChild(newline01);
	
	var newline02 = slrow.cells[2].cloneNode(false);
	newline02.innerHTML = '<div id="att1sel'+ prashidCounter + '"><select name="att1se'+ prashidCounter + '" id="att1se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att1txt'+ prashidCounter +'"><input type="text" name="att1tx'+ prashidCounter +'" id="att1tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att1seselect = newline02.getElementsByTagName('select');
	att1seselect.id = 'att1se' + prashidCounter;
	newline.appendChild(newline02);
	
	var newline03 = slrow.cells[3].cloneNode(false);
	newline03.innerHTML = '<div id="att2sel'+ prashidCounter + '"><select name="att2se'+ prashidCounter + '" id="att2se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att2txt'+ prashidCounter +'"><input type="text" name="att2tx'+ prashidCounter +'" id="att2tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att1seselect = newline03.getElementsByTagName('select');
	att1seselect.id = 'att2se' + prashidCounter;
	newline.appendChild(newline03);
	
	var newline04 = slrow.cells[4].cloneNode(false);
	newline04.innerHTML = '<div id="att3sel'+ prashidCounter + '"><select name="att3se'+ prashidCounter + '" id="att3se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att3txt'+ prashidCounter +'"><input type="text" name="att3tx'+ prashidCounter +'" id="att3tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att3seselect = newline04.getElementsByTagName('select');
	att3seselect.id = 'att3se' + prashidCounter;
	newline.appendChild(newline04);
	
	var newline05 = slrow.cells[5].cloneNode(false);
	newline05.innerHTML = '<div id="att4sel'+ prashidCounter + '"><select name="att4se'+ prashidCounter + '" id="att4se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att4txt'+ prashidCounter +'"><input type="text" name="att4tx'+ prashidCounter +'" id="att4tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att4seselect = newline05.getElementsByTagName('select');
	att4seselect.id = 'att4se' + prashidCounter;
	newline.appendChild(newline05);

	var newline06 = slrow.cells[6].cloneNode(false);
	newline06.innerHTML = '<div id="att5sel'+ prashidCounter + '"><select name="att5se'+ prashidCounter + '" id="att5se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att5txt'+ prashidCounter +'"><input type="text" name="att5tx'+ prashidCounter +'" id="att5tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att5seselect = newline06.getElementsByTagName('select');
	att5seselect.id = 'att5se' + prashidCounter;
	newline.appendChild(newline06);
	
	var newline07 = slrow.cells[7].cloneNode(false);
	newline07.innerHTML = '<div id="att6sel'+ prashidCounter + '"><select name="att6se'+ prashidCounter + '" id="att6se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att6txt'+ prashidCounter +'"><input type="text" name="att6tx'+ prashidCounter +'" id="att6tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att6seselect = newline07.getElementsByTagName('select');
	att6seselect.id = 'att6se' + prashidCounter;
	newline.appendChild(newline07);
	
	var newline08 = slrow.cells[8].cloneNode(false);
	newline08.innerHTML = '<div id="att7sel'+ prashidCounter + '"><select name="att7se'+ prashidCounter + '" id="att7se'+ prashidCounter + '" style="border-color: #59839E;width: 100%"> <option value="select">--Select--</option></select></div><div style="display: none;" id="att7txt'+ prashidCounter +'"><input type="text" name="att7tx'+ prashidCounter +'" id="att7tx'+ prashidCounter +'" style="border-color: #59839E" size="8" value=""></div>';
	var att7seselect = newline08.getElementsByTagName('select');
	att7seselect.id = 'att7se' + prashidCounter;
	newline.appendChild(newline08);
	
	var newline09 = slrow.cells[9].cloneNode(false);
	newline09.innerHTML = '<input type="text" name="att8tx'+ prashidCounter + '" id="att8tx'+ prashidCounter + '" size="5" style="border-color: #59839E" value="">';
	newline.appendChild(newline09);
	
	var newline10 = slrow.cells[10].cloneNode(false);
	newline10.innerHTML = '<input type="text" name="att9tx'+ prashidCounter + '" id="att9tx'+ prashidCounter + '" size="5" style="border-color: #59839E" value="">';
	newline.appendChild(newline10);
	
	var newline11 = slrow.cells[11].cloneNode(false);
	newline11.innerHTML = '<input type="text" name="att10tx'+ prashidCounter + '" id="att10tx'+ prashidCounter + '" size="5" style="border-color: #59839E" value="">';
	newline.appendChild(newline11);
	
	var newline12 = slrow.cells[12].cloneNode(false);
	newline12.innerHTML = '<input type="text" name="currency'+ prashidCounter + '" id="currency'+ prashidCounter + '" size="5" style="border-color: #59839E" value="">';
	newline.appendChild(newline12);
	
	var newline13 = slrow.cells[13].cloneNode(false);
	newline13.innerHTML = '<input type="text" name="amount'+ prashidCounter + '" id="amount'+ prashidCounter + '" size="5" style="border-color: #59839E" value="">';
	newline.appendChild(newline13);
	
	/*var newline14 = slrow.cells[14].cloneNode(false);
	newline14.innerHTML = '<input type="text" size="7" class="frmdatepick" name="frmDate" id="frmDate'+ prashidCounter + '" onblur="return checkDate(frmDate);">';
	newline.appendChild(newline14);*/
	var newline14 = slrow.cells[14].cloneNode(false);
	newline14.innerHTML = '<input type="text" size="8" name="frmDate" id="frmDate'+ prashidCounter + '" readonly="readonly" onclick=javascript:NewCal("frmDate'+prashidCounter+'","ddmmmyyyy","","") style="border-color: #59839E">';
	newline.appendChild(newline14);
	
	/*var newline15 = slrow.cells[15].cloneNode(false);
	newline15.innerHTML = '<input type="text" size="7" class="todatepick" name="toDate" id="toDate'+ prashidCounter + '" onblur="return checkDate(toDate);" >';
	newline.appendChild(newline15);*/
	
	var newline15 = slrow.cells[15].cloneNode(false);
	newline15.innerHTML = '<input type="text" size="8" name="toDate" id="toDate'+ prashidCounter + '" readonly="readonly" onclick=javascript:NewCal("toDate'+prashidCounter+'","ddmmmyyyy","","") style="border-color: #59839E">';
	newline.appendChild(newline15);
	
	var newline16 = slrow.cells[16].cloneNode(false);
	newline16.innerHTML = '<input type="checkbox" name="ch" value="' + prashidCounter + '" size="2" />';
	newline.appendChild(newline16);
	
	
	tblBody.appendChild(newline);
	
	/*var newli = extrarow.cloneNode(false);
	var new00 = extrarow.cells[0].cloneNode(true);
	newli.appendChild(new00);*/
	
	getNewempgrd(prashidCounter);
		
}



function removeRow(tblId)
{
  var hidCount = document.createinv.prashidCounter.value;
    
  var tbl = document.getElementById("innerTable");
  var rowsDeleted = 0;
  var rowsDeletedCheck = 0;
  var countArrayOriginal = new Array('0');
  if(hidCount > 0){
    for(i=0;i<hidCount;i++)
    {
      if(document.createinv.ch[i].checked==true)
      {
        rowsDeletedCheck = parseInt(rowsDeletedCheck)+1;
      }
    }
  }

  if(rowsDeletedCheck == parseInt(hidCount)+1) 
  {
    alert('All rows cannot be deleted.');
    return false;
  }
  else
  {
      if(hidCount > 0){
        for(i=0;i<hidCount;i++)
        {
          if(document.createinv.ch[i].checked==true)
          {
        	  tbl.deleteRow(1+i);
            rowsDeleted = parseInt(rowsDeleted)+1;
            hidCount = parseInt(hidCount)-1;
            i=parseInt(i)-1;
            countArrayOriginal.splice(i+1,1);
          }
        }
       document.createinv.prashidCounter.value = hidCount;
      }
      if (hidCount == 1)
      {
        document.createinv.ch[0].disabled=true;
        document.createinv.lno.value=parseInt(hidCount);
      }
      else
      {
        for(j=1;j<=hidCount;j++)
        {
          document.createinv.lno[j].value=parseInt(j)+1;
          //document.createinv.ch[0].disabled=true;
        }
      }
    }

 }

function getNewempgrd(ido){
	
 xmlHttp=GetXmlHttpObject()
    if (xmlHttp==null)
    {
      alert ("Browser does not support HTTP Request");
      return;
    }
 
    var url="getNewempgrdVal?id="+ido;	    
xmlHttp.onreadystatechange=stateChangedgetNewempgrd
xmlHttp.open("GET",url,true);
	    xmlHttp.send(null);
	
}	 
	function stateChangedgetNewempgrd() 
	{ 
		
	    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
{ 
	  var xmlDoc = xmlHttp.responseXML.documentElement;
       var desc = xmlDoc.getElementsByTagName("employgr");
       //alert(dept.length);
        for (i = 0; i < desc.length ; i++)
        {
        	var glCode=desc[i].getElementsByTagName("employeeGr");
        	var attid=desc[i].getElementsByTagName("ids");
        	var attidval=attid[0].firstChild.data;
        	
        	var optn = document.createElement("OPTION");
        	
        	optn.value = glCode[0].firstChild.data;
        	optn.text = glCode[0].firstChild.data;
        	document.getElementById('empgrd'+attidval).options.add(optn);
      
		
        }
      getNewExpCat(attidval);  
    }
    
}
	
	function getNewExpCat(ido){
		
		 xmlHttp=GetXmlHttpObject()
		    if (xmlHttp==null)
		    {
		      alert ("Browser does not support HTTP Request");
		      return;
		    }
		 
		    var url="getNewExpCatVal?id="+ido;	    
		xmlHttp.onreadystatechange=stateChangedgetNewExpCat
		xmlHttp.open("GET",url,true);
			    xmlHttp.send(null);
			
		}	 
			function stateChangedgetNewExpCat() 
			{ 
				
			    if (xmlHttp.readyState==4 || xmlHttp.readyState=="200")
		{ 
			  var xmlDoc = xmlHttp.responseXML.documentElement;
		       var desc = xmlDoc.getElementsByTagName("employgr");
		       //alert(dept.length);
		        for (i = 0; i < desc.length ; i++)
		        {
		        	var glCode=desc[i].getElementsByTagName("employeeGr");
		        	var attid=desc[i].getElementsByTagName("ids");
		        	var attidval=attid[0].firstChild.data;
		        	
		        	var optn = document.createElement("OPTION");
		        	
		        	optn.value = glCode[0].firstChild.data;
		        	optn.text = glCode[0].firstChild.data;
		        	document.getElementById('expcat'+attidval).options.add(optn);
		      
				
		        }
		      
		    }
		    
		}
	
function searchexp(){
	//var masteId=document.getElementById("masterExp").value;
	/*if(masteId==''){
		alert("Please enter Master Sequence");
		return false;
	}*/
	document.getElementById("flag").value="search";
	document.viewmasterExp.submit();
}

function showexpMaster(){
	
	var lstsize=document.getElementById("expList").value;
	var radcnt=0;
	for(var i=1;i<=lstsize;i++){
		if(document.getElementById("rad"+i).checked==true){
			radcnt=1;
			var expCat=document.getElementById("expCat"+i).value;
			var att=document.getElementById("att"+i).value;			
		}
	}
	if(radcnt==0){
		alert("Please select atleast one record");
		return false;
	}else{
		document.getElementById("searchExp").value=expCat;
		document.getElementById("searchatt").value=	att;
		document.getElementById("flag").value="searchExpDtls";
		document.viewmasterExp.submit();
	}
}

function updateexpMaster(){	

	var prashidCounter = document.viewmasterExp.viewexpList.value;
	var empgrdval='';
	var empgrdarr='';
	var expcatval='';
	var expcatarr='';
	var att1tval='';
	var att1arr='';
	var att2tval='';
	var att2arr='';
	var att3tval;
	var att3arr;
	var att4tval;
	var att4arr;
	var att5tval;
	var att5arr;
	var att6tval;
	var att6arr;
	var att7tval;
	var att7arr;
	
	var att8tval;
	var att9tval;
	var att10tval;
	var currencyval;
	var amountval;
	var frmdtval;
	var todtval;
	
	var totalStr='';
	var linStr='';
	for(var i=1;i<=prashidCounter;i++){
		
		var mastersq=document.getElementById("masterSeq"+i).value;
		var lineSq=document.getElementById("lineSeq"+i).value;
		var comId=mastersq+","+lineSq;
		if(document.getElementById("ch"+i).checked==true){
		
				
		if(document.getElementById('empgrd' + comId).value == 'select'){
			alert("Please Select Expense Category");
			return false; 
		}		
		else if(document.getElementById('expcat' + comId).value == 'select'){
			alert("Please Select Expense Category");
			return false; 
		}
		
		else if(document.getElementById('att1se' + comId).value== 'select' && document.getElementById('att1tx' + comId).value==''){
				alert("Please Fill Attribute1 Value");
				return false;
		}
		else{
			empgrdval=document.getElementById('empgrd' + comId).value;
			//empgrdarr+=empgrdval+'~';
			
			expcatval=document.getElementById('expcat' + comId).value;
			//expcatarr+=expcatval+'~';
			
			if(document.getElementById('att1se' + comId).value== 'select'){
				att1tval=document.getElementById('att1tx' + comId).value;
			}else{
				att1tval=document.getElementById('att1se' + comId).value;
			}
			//att1arr+=att1tval+'~';
			
			if(document.getElementById('att2se' + comId).value== 'select'){
				att2tval=document.getElementById('att2tx' + comId).value;
			}else{
				att2tval=document.getElementById('att2se' + comId).value;
			}
			if(document.getElementById('att3se' + comId).value== 'select'){
				att3tval=document.getElementById('att3tx' + comId).value;
			}else{
				att3tval=document.getElementById('att3se' + comId).value;
			}
			if(document.getElementById('att4se' + comId).value== 'select'){
				att4tval=document.getElementById('att4tx' + comId).value;
			}else{
				att4tval=document.getElementById('att4se' + comId).value;
			}
			if(document.getElementById('att5se' + comId).value== 'select'){
				att5tval=document.getElementById('att2tx' + comId).value;
			}else{
				att5tval=document.getElementById('att2se' + comId).value;
			}
			if(document.getElementById('att2se' + comId).value== 'select'){
				att2tval=document.getElementById('att2tx' + comId).value;
			}else{
				att2tval=document.getElementById('att2se' + comId).value;
			}
			if(document.getElementById('att2se' + comId).value== 'select'){
				att2tval=document.getElementById('att2tx' + comId).value;
			}else{
				att2tval=document.getElementById('att2se' + comId).value;
			}
			if(document.getElementById('att3se' + comId).value== 'select'){
				att3tval=document.getElementById('att3tx' + comId).value;
			}else{
				att3tval=document.getElementById('att3se' + comId).value;
			}
			if(document.getElementById('att4se' + comId).value== 'select'){
				att4tval=document.getElementById('att4tx' + comId).value;
			}else{
				att4tval=document.getElementById('att4se' + comId).value;
			}
			if(document.getElementById('att5se' + comId).value== 'select'){
				att5tval=document.getElementById('att5tx' + comId).value;
			}else{
				att5tval=document.getElementById('att5se' + comId).value;
			}
			if(document.getElementById('att6se' + comId).value== 'select'){
				att6tval=document.getElementById('att6tx' + comId).value;
			}else{
				att6tval=document.getElementById('att6se' + comId).value;
			}
			if(document.getElementById('att7se' + comId).value== 'select'){
				att7tval=document.getElementById('att7tx' + comId).value;
			}else{
				att7tval=document.getElementById('att7se' + comId).value;
			}
			
			att8tval=document.getElementById('att8tx' + comId).value;
			att9tval=document.getElementById('att9tx' + comId).value;
			att10tval=document.getElementById('att10tx' + comId).value;
			
			currencyval=document.getElementById('currency' + comId).value;
			amountval=document.getElementById('amount' + comId).value;
			frmdtval=document.getElementById('frmDate' + comId).value;
			todtval=document.getElementById('toDate' + comId).value;
			//att2arr+=att2tval+'~';
			if(att1tval=='')att1tval='-';
			if(att2tval=='')att2tval='-';
			if(att3tval=='')att3tval='-';
			if(att4tval=='')att4tval='-';
			if(att5tval=='')att5tval='-';
			if(att6tval=='')att6tval='-';
			if(att7tval=='')att7tval='-';
			if(att8tval=='')att8tval='-';
			if(att9tval=='')att9tval='-';
			if(att10tval=='')att10tval='-';
			if(frmdtval=='')frmdtval='-';
			if(todtval=='')todtval='-';
			
			linStr+=mastersq+'~'+lineSq+'~'+empgrdval+'~'+expcatval+'~'+att1tval+'~'+att2tval+'~'+att3tval+'~'+att4tval+'~'+
					att5tval+'~'+att6tval+'~'+att7tval+'~'+att8tval+'~'+att9tval+'~'+att10tval+'~'+currencyval+'~'+amountval+'~'+frmdtval
					+'~'+todtval+'@@';
			
		}
	 }
	}
	totalStr=linStr;
	//alert(totalStr);
	document.viewmasterExp.action="updatemasterExp?totalStr="+totalStr;
	document.viewmasterExp.method="POST";
	document.viewmasterExp.submit();

	
}

function searchexpInv(){
	//var masteId=document.getElementById("masterExp").value;
	/*if(masteId==''){
		alert("Please enter Master Sequence");
		return false;
	}*/
	document.getElementById("flag").value="search";
	document.viewmasterInvExp.submit();
}

function showexpInvMaster(){
	
	var lstsize=document.getElementById("expList").value;
	var radcnt=0;
	for(var i=1;i<=lstsize;i++){
		if(document.getElementById("rad"+i).checked==true){
			radcnt=1;
			var expNo=document.getElementById("expNo"+i).value;
			var expCat=document.getElementById("expCat"+i).value;			
		}
	}
	if(radcnt==0){
		alert("Please select atleast one record");
		return false;
	}else{
		document.getElementById("searchExpCat").value=expCat;
		document.getElementById("expNumber").value=	expNo;
		document.getElementById("flag").value="searchExpDtls";
		document.viewmasterInvExp.submit();
	}
}

