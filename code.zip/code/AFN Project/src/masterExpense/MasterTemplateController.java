package masterExpense;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;

@Controller
public class MasterTemplateController {

	
	@RequestMapping(value = "/masterExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String masterExpense(Model model,HttpServletRequest request, HttpServletResponse response) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		String query=null;
		try {
			Connection conn;
			HttpSession session = request.getSession();
			ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
			String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
			request.setAttribute("msg",msg);
			ArrayList expenseList=new ArrayList();
			String[] expenselst=null;
			ArrayList gradeList=new ArrayList();
			String[] gradelst=null;
			//String empGrd=null;
			String userId=(String)session.getAttribute("userId");
			conn=new Connectionc().getConnection();
			query=bundle.getString("getemployeeGrade");
			ps=conn.prepareStatement(query);
			//ps.setString(1, userId);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				gradelst=new String[1];
				gradelst[0]=rs.getString(1);
				
				gradeList.add(gradelst);
			}		
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getExpenseCategory");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				expenselst=new String[1];
				expenselst[0]=rs.getString(1);
				
				expenseList.add(expenselst);
			}
			
			request.setAttribute("expenseList",expenseList);
			request.setAttribute("gradeList",gradeList);
			
			return "masterExpTemplate";
			
		}catch(Exception e) {
			e.printStackTrace();
			return "welcome";
		}finally {
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
		}
		
	}
	
	@RequestMapping(value = "/savemasterExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String savemasterExp(Model model,HttpServletRequest request, HttpServletResponse response) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		String query=null;
		try {
			Connection conn;
			HttpSession session = request.getSession();
			ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			CallableStatement callableStmt=null;
			conn=new Connectionc().getConnection();
			String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
			request.setAttribute("msg",msg);
			String loginId=(String)session.getAttribute("loginID");
			String flag="";
			/*String empgrd=request.getParameter("empgrd")!=null?request.getParameter("empgrd"):"";
			String expcat=request.getParameter("expcat")!=null?request.getParameter("expcat"):"";
			String att1=("".equals(request.getParameter("att1")))?request.getParameter("att1t"):request.getParameter("att1");
			String att2=("".equals(request.getParameter("att2")))?request.getParameter("att2t"):request.getParameter("att2");
			String att3=("".equals(request.getParameter("att3")))?request.getParameter("att3t"):request.getParameter("att3");
			String att4=("".equals(request.getParameter("att4")))?request.getParameter("att4t"):request.getParameter("att4");
			String att5=("".equals(request.getParameter("att5")))?request.getParameter("att5t"):request.getParameter("att5");
			String att6=("".equals(request.getParameter("att6")))?request.getParameter("att6t"):request.getParameter("att6");
			String att7=("".equals(request.getParameter("att7")))?request.getParameter("att7t"):request.getParameter("att7");
			String att8=request.getParameter("att8")!=null?request.getParameter("att8"):"";
			String att9=request.getParameter("att9")!=null?request.getParameter("att9"):"";
			String att10=request.getParameter("att10")!=null?request.getParameter("att10"):"";
			String currency=request.getParameter("currency")!=null?request.getParameter("currency"):"";
			String amount=request.getParameter("amount")!=null?request.getParameter("amount"):"";
			String frmDate=request.getParameter("frmDate")!=null?request.getParameter("frmDate"):"";
			String toDate=request.getParameter("toDate")!=null?request.getParameter("toDate"):"";
			
			callableStmt=conn.prepareCall("{call xxbaf_save_master_expense(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			callableStmt.setString(1, empgrd);
			callableStmt.setString(2, expcat);
			callableStmt.setString(3, att1);
			callableStmt.setString(4, att2);
			callableStmt.setString(5, att3);
			callableStmt.setString(6, att4);
			callableStmt.setString(7, att5);
			callableStmt.setString(8, att6);
			callableStmt.setString(9, att7);
			callableStmt.setString(10, att8);
			callableStmt.setString(11, att9);
			callableStmt.setString(12, att10);
			callableStmt.setString(13, currency);
			callableStmt.setString(14, amount);
			callableStmt.setString(15, frmDate);
			callableStmt.setString(16, toDate);
			callableStmt.setString(17, loginId);			
			callableStmt.registerOutParameter(18, Types.VARCHAR);*/
			
			String dataText=request.getParameter("totalStr");
			//System.out.println(dataText);
			
		String[]data=dataText.split("@@");
		//System.out.println("length --> "+data.length);
				for(int a=0;a<(data.length)-1;a++) {
					for(int b=(data.length)-1;b>a;b--) {
						if(data[a].equals(data[b])) {
							System.out.println("Equal");
							flag="Equal";
						}
					}
				}
		if(!(flag.equalsIgnoreCase("Equal"))) {	
			callableStmt=conn.prepareCall("{call xxbaf_save_master_expense(?,?,?)}");
			
			callableStmt.setString(1, dataText);			
			callableStmt.setString(2, loginId);			
			callableStmt.registerOutParameter(3, Types.VARCHAR);
			
			callableStmt.execute();	
			msg=callableStmt.getString(3);
			
		}else {
		msg="Duplicate Data cannot be Entered";
		}
			return "redirect:/masterExp?msg=" + msg;
			
		}catch(Exception e) {
			e.printStackTrace();
			return "welcome";
		}finally {
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
		}
		
	}
	
	@RequestMapping(value = "/viewmasterExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String viewmasterExpense(Model model,HttpServletRequest request, HttpServletResponse response) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		String query=null;
		try {
			Connection conn;
			HttpSession session = request.getSession();
			ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			
			String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
			String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"";
			request.setAttribute("msg",msg);
		if(flag.equals("search")) {	
			
			ArrayList expenseList=new ArrayList();
			String[] expenselst=null;
			
			String userId=(String)session.getAttribute("userId");
			conn=new Connectionc().getConnection();
			
			query=bundle.getString("getmasterExpView");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				expenselst=new String[2];
				expenselst[0]=rs.getString(1);
				expenselst[1]=rs.getString(2);
				//expenselst[2]=rs.getString(3);
				
				expenseList.add(expenselst);
			}
			
			request.setAttribute("expenseList",expenseList);
			request.setAttribute("expenseListSize",expenseList.size());
						
			//return "viewmasterExpTemplate";
		 }
		if(flag.equals("searchExpDtls")) {
			
			String searchExp=request.getParameter("searchExp")!=null?request.getParameter("searchExp"):"";
			String searchatt=request.getParameter("searchatt")!=null?request.getParameter("searchatt"):"";
			
			/*ArrayList expenseList=new ArrayList();
			String[] expenselst=null;*/
			ArrayList viewexpenseList=new ArrayList();
			String[] viewexpenselst=null;
			ArrayList expenseList=new ArrayList();
			String[] expenselst=null;
			ArrayList gradeList=new ArrayList();
			String[] gradelst=null;
			String userId=(String)session.getAttribute("userId");
			conn=new Connectionc().getConnection();
			
			/*query=bundle.getString("getmasterExpView");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				expenselst=new String[2];
				expenselst[0]=rs.getString(1);
				expenselst[1]=rs.getString(2);
				//expenselst[2]=rs.getString(3);
				
				expenseList.add(expenselst);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}*/
			query=bundle.getString("getemployeeGrade");
			ps=conn.prepareStatement(query);
			//ps.setString(1, userId);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				gradelst=new String[1];
				gradelst[0]=rs.getString(1);
				
				gradeList.add(gradelst);
			}		
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getExpenseCategory");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				expenselst=new String[1];
				expenselst[0]=rs.getString(1);
				
				expenseList.add(expenselst);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getExpWiseCatView");
			ps=conn.prepareStatement(query);
			
			ps.setString(1, searchExp);
			ps.setString(2, searchatt);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[18];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				
				viewexpenseList.add(viewexpenselst);
			}
			
			//request.setAttribute("expenseList",expenseList);
			//request.setAttribute("expenseListSize",expenseList.size());
			request.setAttribute("viewexpenseList",viewexpenseList);
			request.setAttribute("viewexpenseListSize",viewexpenseList.size());
			request.setAttribute("expenseList",expenseList);
			request.setAttribute("gradeList",gradeList);
			
		}
		
		return "viewmasterExpTemplate";
		
		}catch(Exception e) {
			e.printStackTrace();
			return "welcome";
		}finally {
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
		}
		
	}
	
	@RequestMapping(value = "/updatemasterExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String updatemasterExp(Model model,HttpServletRequest request, HttpServletResponse response) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		String query=null;
		String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
		try {
			Connection conn;
			HttpSession session = request.getSession();
			ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			CallableStatement callableStmt=null;
			conn=new Connectionc().getConnection();			
			
			String loginId=(String)session.getAttribute("loginID");
			String flag="";
		
			String dataText=request.getParameter("totalStr");
			
			callableStmt=conn.prepareCall("{call xxbaf_update_master_expense(?,?,?)}");
			
			callableStmt.setString(1, dataText);			
			callableStmt.setString(2, loginId);			
			callableStmt.registerOutParameter(3, Types.VARCHAR);
			
			callableStmt.execute();	
			msg=callableStmt.getString(3);
			request.setAttribute("msg",msg);
			return "redirect:/viewmasterExp?msg=" + msg;
			
		}catch(Exception e) {
			e.printStackTrace();
			msg="Some Error Occurred";
			request.setAttribute("msg",msg);
			return "welcome";
		}finally {
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
		}
		
	}
	
}
