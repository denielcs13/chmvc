package masterExpense;

import java.io.File;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import commonController.Connectionc;
import invoiceForms.SearchPrepaymentForm;
import invoiceForms.UploadFileForm;

@Controller
public class MasterInvoiceController {

	
	@RequestMapping(value = "/employeeExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String employeeExp(Model model,HttpServletRequest request,HttpServletResponse response) {
		Connection conn;
		HttpSession session=request.getSession();
		String userName=(String)session.getAttribute("userName");
		ResultSet rs=null;
		PreparedStatement ps=null;
		String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
		request.setAttribute("msg",msg);	
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		try {
		System.out.println("okkkk");
		conn=new Connectionc().getConnection();
		ArrayList yearList=new ArrayList();
		String[] finYears=null;
		String[] invtype=null;
		ArrayList InvoiceList=new ArrayList();
		ArrayList expenseList=new ArrayList();
		String[] expenselst=null;
		ArrayList descList=new ArrayList();
		String[] description=null;
		String query=bundle.getString("getfinancialYears");
		ps=conn.prepareStatement(query);
		
		rs=ps.executeQuery();
		
		while(rs.next()) {
			finYears=new String[1];
			finYears[0]=rs.getString(1);
			
			yearList.add(finYears);
		}
		
		if(rs!=null) {rs=null;}
		if(ps!=null) {ps=null;}
		if(query!=null) {query=null;}
		
		query=bundle.getString("getmasterinvoiceType");
		ps=conn.prepareStatement(query);
		
		rs=ps.executeQuery();
		
		while(rs.next()) {
			invtype=new String[1];
			invtype[0]=rs.getString(1);
					
			InvoiceList.add(invtype);
		}
		
		if(rs!=null) {rs=null;}
		if(ps!=null) {ps=null;}
		if(query!=null) {query=null;}
		
		query=bundle.getString("getExpenseCategory");
		ps=conn.prepareStatement(query);
		
		rs=ps.executeQuery();
		
		while(rs.next()) {
			expenselst=new String[1];
			expenselst[0]=rs.getString(1);
			
			expenseList.add(expenselst);
		}
		
		if(rs!=null) {rs=null;}
		if(ps!=null) {ps=null;}
		if(query!=null) {query=null;}
		
		query=bundle.getString("getExpInvoiceNOE");
		ps=conn.prepareStatement(query);
		
		rs=ps.executeQuery();
		
		while(rs.next()) {
			description=new String[2];
			description[0]=rs.getString(1);
			description[1]=rs.getString(2);
			
			descList.add(description);
		}		
		
		request.setAttribute("expenseList",expenseList);		
		request.setAttribute("InvoiceList",InvoiceList);
		request.setAttribute("yearList", yearList);
		request.setAttribute("descList", descList);
		}catch(Exception e) {
			return "login";
		}
		return "masterExpInvoice";
	}
	
	
	@RequestMapping(value = "/saveInvoiceExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String saveInvoiceExp(@ModelAttribute UploadFileForm filef,Model model,HttpServletRequest request,HttpServletResponse response) {
		Connection conn;
		HttpSession session=request.getSession();
		String userName=(String)session.getAttribute("userName");
		ResultSet rs=null;
		PreparedStatement ps=null;
		String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
		request.setAttribute("msg",msg);	
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		CallableStatement callableStmt=null;
		String loginId=(String)session.getAttribute("loginID");
		String flag="";
		PreparedStatement prepareStmt=null;
		try {
		System.out.println("okkkk");
		
		
		List<MultipartFile> files = filef.getInvFile();
		
		ArrayList fileNames = new ArrayList();
       
        if (null != files && files.size() > 0 )
        {
            for (MultipartFile multipartFile : files) {
 
                String fileName = multipartFile.getOriginalFilename();
                if(!("".equals(fileName))){
                fileNames.add(fileName);
                
              //  File imageFile = new File(context.getRealPath("") + File.separator + "uploadimage" + File.separator, fileName);
                File imageFile = new File(System.getProperty("user.home") + "/Desktop/uploadimage/", fileName);
                System.out.println(imageFile);
                if(!(imageFile.exists())) {
                	boolean a=imageFile.mkdir();
                	if(a) {
                 	System.out.println(a);
                	}else {
                		System.out.println("Fail");
                	}
                }
                try
                {
               
                    multipartFile.transferTo(imageFile);
                } catch (IOException e)
                {
                   // e.printStackTrace();
                }
               } 
            }
        }
        System.out.println(Arrays.toString(fileNames.toArray()));
        System.out.println(fileNames.size());
        
		conn=new Connectionc().getConnection();
		String dataText=request.getParameter("totalStr");
		String fyear=request.getParameter("fyear");
		String frmDate=request.getParameter("frmDate");
		String toDate=request.getParameter("toDate");
		String invtype=request.getParameter("invtype");
		String expCat=request.getParameter("expCat");
		
		callableStmt=conn.prepareCall("{call XXBAF_INV_EXP_CREATE(?,?,?,?,?,?,?,?,?,?)}");
		
		callableStmt.setString(1, dataText);			
		callableStmt.setString(2, fyear);
		callableStmt.setString(3, frmDate);
		callableStmt.setString(4, toDate);
		callableStmt.setString(5, invtype);
		callableStmt.setString(6, expCat);		
		callableStmt.setString(7, loginId);
		callableStmt.setString(8, "");
		callableStmt.registerOutParameter(9, Types.VARCHAR);
		callableStmt.registerOutParameter(10, Types.VARCHAR);
		
		callableStmt.execute();	
		msg=callableStmt.getString(10);
		if(msg.contains("Invoice has been saved successfully.") || msg.contains("Invoice has been updated successfully")) {	
		if (null != files && fileNames.size() > 0)
        {
   	for(int i=1;i<=fileNames.size();i++) {
   	 String query="insert into xxbaf_uploaded_file_master_inv(EXP_NO,FILE_NAME,UPLOADED_DT,UPLAODED_BY,file_seq) values(?,?,sysdate,?,?)";
   	 prepareStmt=conn.prepareStatement(query);
   	 prepareStmt.setString(1, callableStmt.getString(9));
   	 prepareStmt.setString(2, (String) fileNames.get(i-1)!=null?(String) fileNames.get(i-1):"");
   	 prepareStmt.setString(3, loginId);
   	 prepareStmt.setInt(4, i);
   	 
   	 prepareStmt.executeUpdate();
   	} 
   	
        }
	}	
		return "redirect:/employeeExp?msg=" + msg;
		}catch(Exception e) {
			e.printStackTrace();
			return "redirect:/employeeExp?msg=Some Error Occurred";
		}
		
	}
	

	@RequestMapping(value="/searchprepaymentInv",  method = {RequestMethod.POST,RequestMethod.GET})
	public String getprepaymentInv(ModelMap model, SearchPrepaymentForm searchForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		Connection conn;
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		String msg="";
		conn=new Connectionc().getConnection();
		//String[]supplierdtls=null;
		ArrayList prepay=new ArrayList<>();
	String supplierid=request.getParameter("supplierid")!=null?request.getParameter("supplierid"):"";
	String siteid=request.getParameter("Siteid")!=null?request.getParameter("Siteid"):"";
		try {
			
			//if(flag.equals("search")) {
				
				String query=bundle.getString("getPrepaymentDtls");
				ps=conn.prepareStatement(query);
				ps.setString(1, supplierid);
				ps.setString(2, siteid);
				
				System.out.println(query);				
								
				rs=ps.executeQuery();
				
				while(rs.next()) {
					searchForm=new SearchPrepaymentForm();
					searchForm.setInvoiceId(rs.getString("INVOICE_ID")!=null?rs.getString("INVOICE_ID"):"-");
					searchForm.setPrepayNum(rs.getString("pre_pay_num")!=null?rs.getString("pre_pay_num"):"-");
					searchForm.setPrepayAmt(rs.getString("pre_pay_amt")!=null?rs.getString("pre_pay_amt"):"-");
					searchForm.setPrepayBal(rs.getString("pre_pay_bal")!=null?rs.getString("pre_pay_bal"):"-");
					searchForm.setAmountPaid(rs.getString("amount_paid")!=null?rs.getString("amount_paid"):"");
					
					prepay.add(searchForm);		
					
				}
				request.setAttribute("prepay", prepay);
				request.setAttribute("prepaySize", prepay.size());
				
		//	}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		return "searchPrepayInv";
	}

	@RequestMapping(value = "/viewinvExp", method = {RequestMethod.GET,RequestMethod.POST})
	public String viewinvExp(Model model,HttpServletRequest request,HttpServletResponse response) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		String query=null;
		try {
			Connection conn;
			HttpSession session = request.getSession();
			ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
			conn=new Connectionc().getConnection();
			String msg=request.getParameter("msg")!=null?request.getParameter("msg"):"";
			String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"";
			request.setAttribute("msg",msg);
		if(flag.equals("search")) {	
			
			ArrayList expenseList=new ArrayList();
			String[] expenselst=null;
			String expNo=request.getParameter("masterExp")!=null?request.getParameter("masterExp"):"";
			String userId=(String)session.getAttribute("userId");
			
			query=bundle.getString("getExpInvView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNo);
			ps.setString(2, expNo);
			ps.setString(3, expNo);
			ps.setString(4, expNo);
			ps.setString(5, expNo);
			ps.setString(6, expNo);
			ps.setString(7, expNo);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				expenselst=new String[4];
				expenselst[0]=rs.getString(1);
				expenselst[1]=rs.getString(2);
				expenselst[2]=rs.getString(3);
				expenselst[3]=rs.getString(4);
				
				expenseList.add(expenselst);
			}
			
			request.setAttribute("expenseList",expenseList);
			request.setAttribute("expenseListSize",expenseList.size());
						
		 }
		if(flag.equals("searchExpDtls")) {
			
			String searchExpCat=request.getParameter("searchExpCat")!=null?request.getParameter("searchExpCat"):"";
			String expNumber=request.getParameter("expNumber")!=null?request.getParameter("expNumber"):"";
			
			String[] viewexpenselst=null;
			ArrayList viewexpenseList=new ArrayList();
			String[] finYears=null;
			ArrayList yearList=new ArrayList();			
			String[] invtype=null;
			ArrayList InvoiceList=new ArrayList();
			String[] expenselst=null;
			ArrayList expenseList=new ArrayList();
			String[] description=null;
			ArrayList descList=new ArrayList();
			
			
			query=bundle.getString("getfinancialYears");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				finYears=new String[1];
				finYears[0]=rs.getString(1);
				
				yearList.add(finYears);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getmasterinvoiceType");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				invtype=new String[1];
				invtype[0]=rs.getString(1);
						
				InvoiceList.add(invtype);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getExpenseCategory");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				expenselst=new String[1];
				expenselst[0]=rs.getString(1);
				
				expenseList.add(expenselst);
			}
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
			
			query=bundle.getString("getExpInvoiceNOE");
			ps=conn.prepareStatement(query);
			
			rs=ps.executeQuery();
			
			while(rs.next()) {
				description=new String[2];
				description[0]=rs.getString(1);
				description[1]=rs.getString(2);
				
				descList.add(description);
			}		
			
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
		if(searchExpCat.equalsIgnoreCase("OutStation Travel")) {	
			query=bundle.getString("getInvoiceExpOutstatCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[39];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				viewexpenselst[18]=rs.getString(19);
				viewexpenselst[19]=rs.getString(20);
				viewexpenselst[20]=rs.getString(21);
				viewexpenselst[21]=rs.getString(22);
				viewexpenselst[22]=rs.getString(23);
				viewexpenselst[23]=rs.getString(24);
				viewexpenselst[24]=rs.getString(25);
				viewexpenselst[25]=rs.getString(26);
				viewexpenselst[26]=rs.getString(27);
				viewexpenselst[27]=rs.getString(28);
				viewexpenselst[28]=rs.getString(29);
				viewexpenselst[29]=rs.getString(30);
				viewexpenselst[30]=rs.getString(31);
				viewexpenselst[31]=rs.getString(32);
				viewexpenselst[32]=rs.getString(33);
				viewexpenselst[33]=rs.getString(34);
				viewexpenselst[34]=rs.getString(35);
				viewexpenselst[35]=rs.getString(36);
				viewexpenselst[36]=rs.getString(37);
				viewexpenselst[37]=rs.getString(38);
				viewexpenselst[38]=rs.getString(39);
				
				
				viewexpenseList.add(viewexpenselst);
			}
		}
		if(searchExpCat.equalsIgnoreCase("Entertainment")) {	
			query=bundle.getString("getInvoiceExpEnterCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[23];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				viewexpenselst[18]=rs.getString(19);
				viewexpenselst[19]=rs.getString(20);
				viewexpenselst[20]=rs.getString(21);
				viewexpenselst[21]=rs.getString(22);
				viewexpenselst[22]=rs.getString(23);
				
				
				
				viewexpenseList.add(viewexpenselst);
			}
		}	
		
		if(searchExpCat.equalsIgnoreCase("Food Expense")) {	
			query=bundle.getString("getInvoiceExpFoodCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[22];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				viewexpenselst[18]=rs.getString(19);
				viewexpenselst[19]=rs.getString(20);
				viewexpenselst[20]=rs.getString(21);
				viewexpenselst[21]=rs.getString(22);
				
				viewexpenseList.add(viewexpenselst);
			}
		}	
		if(searchExpCat.equalsIgnoreCase("Local Conveyance")) {	
			query=bundle.getString("getInvoiceExpLocCoCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[23];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				viewexpenselst[18]=rs.getString(19);
				viewexpenselst[19]=rs.getString(20);
				viewexpenselst[20]=rs.getString(21);
				viewexpenselst[21]=rs.getString(22);
				viewexpenselst[22]=rs.getString(23);
				
				viewexpenseList.add(viewexpenselst);
			}
		}
		if(searchExpCat.equalsIgnoreCase("Miscellaneous")) {	
			query=bundle.getString("getInvoiceMiscCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[17];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				
				viewexpenseList.add(viewexpenselst);
			}
		}
		if(searchExpCat.equalsIgnoreCase("International Travel")) {	
			query=bundle.getString("getInvoiceInterCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[37];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				viewexpenselst[18]=rs.getString(19);
				viewexpenselst[19]=rs.getString(20);
				viewexpenselst[20]=rs.getString(21);
				viewexpenselst[21]=rs.getString(22);
				viewexpenselst[22]=rs.getString(23);
				viewexpenselst[23]=rs.getString(24);
				viewexpenselst[24]=rs.getString(25);
				viewexpenselst[25]=rs.getString(26);
				viewexpenselst[26]=rs.getString(27);
				viewexpenselst[27]=rs.getString(28);
				viewexpenselst[28]=rs.getString(29);
				viewexpenselst[29]=rs.getString(30);
				viewexpenselst[30]=rs.getString(31);
				viewexpenselst[31]=rs.getString(32);
				viewexpenselst[32]=rs.getString(33);
				viewexpenselst[33]=rs.getString(34);
				viewexpenselst[34]=rs.getString(35);
				viewexpenselst[35]=rs.getString(36);
				viewexpenselst[36]=rs.getString(37);
				
				viewexpenseList.add(viewexpenselst);
			}
		}
		
		if(searchExpCat.equalsIgnoreCase("Combined - Food and conveyance")) {	
			query=bundle.getString("getInvoiceCombCatView");
			ps=conn.prepareStatement(query);
			ps.setString(1, expNumber);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				viewexpenselst=new String[30];
				viewexpenselst[0]=rs.getString(1);
				viewexpenselst[1]=rs.getString(2);
				viewexpenselst[2]=rs.getString(3);
				viewexpenselst[3]=rs.getString(4);
				viewexpenselst[4]=rs.getString(5);
				viewexpenselst[5]=rs.getString(6);
				viewexpenselst[6]=rs.getString(7);
				viewexpenselst[7]=rs.getString(8);
				viewexpenselst[8]=rs.getString(9);
				viewexpenselst[9]=rs.getString(10);
				viewexpenselst[10]=rs.getString(11);
				viewexpenselst[11]=rs.getString(12);
				viewexpenselst[12]=rs.getString(13);
				viewexpenselst[13]=rs.getString(14);
				viewexpenselst[14]=rs.getString(15);
				viewexpenselst[15]=rs.getString(16);
				viewexpenselst[16]=rs.getString(17);
				viewexpenselst[17]=rs.getString(18);
				viewexpenselst[18]=rs.getString(19);
				viewexpenselst[19]=rs.getString(20);
				viewexpenselst[20]=rs.getString(21);
				viewexpenselst[21]=rs.getString(22);
				viewexpenselst[22]=rs.getString(23);
				viewexpenselst[23]=rs.getString(24);
				viewexpenselst[24]=rs.getString(25);
				viewexpenselst[25]=rs.getString(26);
				viewexpenselst[26]=rs.getString(27);
				viewexpenselst[27]=rs.getString(28);
				viewexpenselst[28]=rs.getString(29);
				viewexpenselst[29]=rs.getString(30);
				
				
				viewexpenseList.add(viewexpenselst);
			}
		}
			request.setAttribute("expenseList",expenseList);		
			request.setAttribute("InvoiceList",InvoiceList);
			request.setAttribute("yearList", yearList);
			request.setAttribute("descList", descList);
		request.setAttribute("ExpCat", searchExpCat);
			request.setAttribute("viewexpenseList",viewexpenseList);
			request.setAttribute("viewexpenseListSize",viewexpenseList.size());
		}
		}catch(Exception e) {
			e.printStackTrace();
			return "welcome";
		}finally {
			if(rs!=null) {rs=null;}
			if(ps!=null) {ps=null;}
			if(query!=null) {query=null;}
		}
		return "viewExpInvTemplate";
	}
	
}
