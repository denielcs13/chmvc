package invoiceForms;

import java.io.File;
import java.io.Serializable;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class UploadFileForm implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	private List<MultipartFile> invFile =null;
	 
	 public List<MultipartFile> getInvFile() {
			return invFile;
		}
		public void setInvFile(List<MultipartFile> invFile) {
			
			this.invFile = invFile;
			/*if(!(invFile.isEmpty())) {
			this.invFile = invFile;
			}else {
				this.invFile =null;
			}*/
		}
	
	/*private File invFile;
	private File invFile1;
	private File invFile2;
	
	public File getInvFile() {
		return invFile;
	}
	public void setInvFile(File invFile) {
		this.invFile = invFile;
	}
	public File getInvFile1() {
		return invFile1;
	}
	public void setInvFile1(File invFile1) {
		this.invFile1 = invFile1;
	}
	public File getInvFile2() {
		return invFile2;
	}
	public void setInvFile2(File invFile2) {
		this.invFile2 = invFile2;
	}*/
	
	

}
