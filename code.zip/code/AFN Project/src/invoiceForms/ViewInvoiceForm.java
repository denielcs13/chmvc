package invoiceForms;

import java.io.Serializable;

public class ViewInvoiceForm implements Serializable{

	private static final long serialVersionUID = 1L;

	private String apfno;

	public String getApfno() {
		return apfno;
	}

	public void setApfno(String apfno) {
		this.apfno = apfno;
	}
	
	
	
}
