package commonController;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewFileController extends HttpServlet {

	public void doPost(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException {
				
			}
			
			public void doGet(HttpServletRequest request, HttpServletResponse response)  
			            throws ServletException, IOException {		
				
			try
			{
				String fileName= request.getParameter("fileName")!=null?request.getParameter("fileName"):"";
				String [] fullPathValue=null;
				if(fileName!=null && fileName.length()>0)
				{
						String pathValue = "";
						
						//fullPathValue=System.getProperty("user.home") + "/Desktop/uploadimage/", fileName;
						File imageFile = new File(System.getProperty("user.home") + "/Desktop/uploadimage/");
						
						String filepath = imageFile + File.separator + fileName;
						System.out.println(filepath);
						PrintWriter out = response.getWriter();  
						response.setContentType("APPLICATION/OCTET-STREAM");   
						response.setHeader("Content-Disposition","attachment; filename=\"" + fileName + "\"");   
						FileInputStream fileInputStream = new FileInputStream(filepath);  		          
						int i;   
						while ((i=fileInputStream.read()) != -1) {  
							out.write(i);   
						}   
						fileInputStream.close();   
						out.close(); 
				}			
				
				}  
			    catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			    }
				
			}
			
}
