package commonController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connectionc {
	
	/*String JDBC_DRIVER = "oracle.jdbc.OracleDriver";  
	String DB_URL = "jdbc:oracle:thin:@karan:1521:orcl2";

    String USER = "scott";
	String PASS = "tiger";
	
	Connection conn;
	//Connection getConn(String dname,String url,String id,String pass)throws Exception
	Connection getConn(String dname,String url,String id,String pass)throws Exception
	{
		Class.forName(dname);
		conn = DriverManager.getConnection(url,id,pass);		
		return conn;
	}*/
	
	public Connection getConnection() //Providing a Database Connection
	{
	    Connection conn=null;
	    
	    //Registering a driver
	    
	    try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
					e.printStackTrace();
		}

	    //Getting a connection   
	    try {
			//conn = DriverManager.getConnection("jdbc:oracle:thin:@karan:1521:orcl2", "scott", "tiger");
	    	conn = DriverManager.getConnection("jdbc:oracle:thin:@oracleebs.baf.com:1532:GBAF", "xxbaf", "xxbaf");
	    	//conn = DriverManager.getConnection("jdbc:oracle:thin:@182.76.57.113:1532:GBAF", "xxbaf", "xxbaf");
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return conn;
	}

	

}
