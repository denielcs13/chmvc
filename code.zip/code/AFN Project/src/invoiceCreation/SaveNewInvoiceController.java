package invoiceCreation;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import commonController.Connectionc;
import invoiceForms.SaveNewInvoiceForm;
import invoiceForms.UploadFileForm;



@Controller
public class SaveNewInvoiceController  {
    public SaveNewInvoiceController(){}
    @Autowired
    ServletContext context; 
    
    @RequestMapping(value="/savenewinvoice",  method = {RequestMethod.POST,RequestMethod.GET}) 
    public String execute(@ModelAttribute UploadFileForm filef,ModelMap model, SaveNewInvoiceForm saveInvoiceForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
    	System.out.println("******user******SaveNewInvoiceController*****************");
    	//ServletContext context; 
    	Connection myConnection             =null;
        String error_msg                    =null;
        String afpno                   =null;
        HttpSession session=request.getSession();
        CallableStatement callableStmt=null;
        PreparedStatement prepareStmt=null;
        ResultSet resultSet=null;
        String isSave="";
       String name=(String)session.getAttribute("name");
       String loginID=(String)session.getAttribute("loginID");
       String msg="";
       String forward="";
            try 
            {
            	List<MultipartFile> files = filef.getInvFile();
            	ArrayList fileNames = new ArrayList();
                myConnection                =new Connectionc().getConnection();
            //&& ( (!(files.get(0).isEmpty())) || (!(files.get(1).isEmpty())) || (!(files.get(2).isEmpty())) )   
                
                if (null != files && files.size() > 0 )
                {
                    for (MultipartFile multipartFile : files) {
         
                        String fileName = multipartFile.getOriginalFilename();
                        //if(!("".equals(fileName))){
                        fileNames.add(fileName);
                        
                      //  File imageFile = new File(context.getRealPath("") + File.separator + "uploadimage" + File.separator, fileName);
                        File imageFile = new File(System.getProperty("user.home") + "/Desktop/uploadimage/", fileName);
                        System.out.println(imageFile);
                        if(!(imageFile.exists())) {
                        	boolean a=imageFile.mkdir();
                        	if(a) {
                         	System.out.println(a);
                        	}else {
                        		System.out.println("Fail");
                        	}
                        }
                        try
                        {
                       
                            multipartFile.transferTo(imageFile);
                        } catch (IOException e)
                        {
                           // e.printStackTrace();
                        }
                      // } 
                    }
                }
            	
            	/*File invFile=filef.getInvFile();
            	File invFile1=filef.getInvFile1();
            	File invFile2=filef.getInvFile2();
            	
            	myConnection                =new Connectionc().getConnection();
            	ArrayList fileNames = new ArrayList();
                
                if (null != invFile)
                {                        
                	    String fileName = invFile.getName();
                        fileNames.add(fileName);
         
                      //  File imageFile = new File(context.getRealPath("") + File.separator + "uploadimage" + File.separator, fileName);
                        File imageFile = new File(System.getProperty("user.home") + "/Desktop/uploadimage/", fileName);
                        System.out.println(imageFile);
                        try
                        {
                       
                            multipartFile.transferTo(imageFile);
                        } catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                */
            	
                System.out.println(Arrays.toString(fileNames.toArray()));
                System.out.println(fileNames.size());
                
                if(request.getParameter("editFlag")!=null) 	
                {
                	afpno=request.getParameter("afpno")!=null?request.getParameter("afpno"):"";
                }
                
               // callableStmt=myConnection.prepareCall("{call sp_create_invoice(?,?,?,?,?,?,?,?,?,?,?)}");
               // callableStmt=myConnection.prepareCall("{call XXBAF_SP_CREATE_INVOICE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                callableStmt=myConnection.prepareCall("{call XXBAF_SP_CREATE_INVOICE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                String itemString = request.getParameter("itemStr");
                String submissionFlag=request.getParameter("submissionFlag")!=null?request.getParameter("submissionFlag"):"";
                saveInvoiceForm.setSiteid(Integer.parseInt(request.getParameter("siteid")!=null?request.getParameter("siteid"):""));
                saveInvoiceForm.setSuppliernumber(Integer.parseInt(request.getParameter("suppliernum")!=null?request.getParameter("suppliernum"):""));
                saveInvoiceForm.setInvno(request.getParameter("invno")!=null?request.getParameter("invno"):"");
                saveInvoiceForm.setTotalinvAmt(request.getParameter("totalinvAmt")!=null?request.getParameter("totalinvAmt"):"");
                saveInvoiceForm.setOthernote(request.getParameter("othernote")!=null?request.getParameter("othernote"):"");
                saveInvoiceForm.setGstno(request.getParameter("gstno")!=null?request.getParameter("gstno"):"");
                saveInvoiceForm.setSuppliername(request.getParameter("suppliername")!=null?request.getParameter("suppliername"):"");
                saveInvoiceForm.setOrgId(Integer.parseInt(request.getParameter("orgId")!=null?request.getParameter("orgId"):""));
                saveInvoiceForm.setInvoiceDate(request.getParameter("invdate")!=null?request.getParameter("invdate"):"");
                saveInvoiceForm.setFinYear(request.getParameter("finYear")!=null?request.getParameter("finYear"):"");
                saveInvoiceForm.setFrmDate(request.getParameter("frmDt")!=null?request.getParameter("frmDt"):"");
                saveInvoiceForm.setToDate(request.getParameter("toDt")!=null?request.getParameter("toDt"):"");
                
                saveInvoiceForm.setCurrency(request.getParameter("currency")!=null?request.getParameter("currency"):"");
                saveInvoiceForm.setInvtype(request.getParameter("invoicetype")!=null?request.getParameter("invoicetype"):"");
                saveInvoiceForm.setTotalpreAmt(request.getParameter("prepay")!=null?request.getParameter("prepay"):"");
                saveInvoiceForm.setTotaldedAmt(request.getParameter("deduct")!=null?request.getParameter("deduct"):"");
                saveInvoiceForm.setPreinvId(request.getParameter("preinvId")!=null?request.getParameter("preinvId"):"");
                saveInvoiceForm.setDedinvId(request.getParameter("dedinvId")!=null?request.getParameter("dedinvId"):"");
                saveInvoiceForm.setRcmfuncflag(request.getParameter("rcmfuncflag")!=null?request.getParameter("rcmfuncflag"):"");
                
                callableStmt.setInt(1,saveInvoiceForm.getSiteid());
                callableStmt.setInt(2,saveInvoiceForm.getSuppliernumber());                
                callableStmt.setString(3,saveInvoiceForm.getInvno().trim());
                callableStmt.setString(4,saveInvoiceForm.getTotalinvAmt());
                callableStmt.setString(5,itemString);
                callableStmt.setString(6,submissionFlag);
                callableStmt.registerOutParameter(7, Types.VARCHAR);  //afpno
                callableStmt.registerOutParameter(8, Types.VARCHAR); //Message
                //callableStmt.setString(9,name);
                callableStmt.setString(9,loginID);
                if(!(afpno.equals(""))){
                	callableStmt.setString(10,afpno);
                }else {
                callableStmt.setString(10,"");
                }
                callableStmt.setString(11,saveInvoiceForm.getOthernote());
                callableStmt.setString(12,saveInvoiceForm.getGstno());   //GST No
                callableStmt.setString(13,saveInvoiceForm.getSuppliername());
                callableStmt.setInt(14, saveInvoiceForm.getOrgId());
                callableStmt.setString(15, saveInvoiceForm.getInvoiceDate());
                callableStmt.setString(16, saveInvoiceForm.getFinYear());
                callableStmt.setString(17, saveInvoiceForm.getFrmDate());
                callableStmt.setString(18, saveInvoiceForm.getToDate());
                
                callableStmt.setString(19, saveInvoiceForm.getCurrency());
                callableStmt.setString(20, saveInvoiceForm.getTotalpreAmt());
                callableStmt.setString(21, saveInvoiceForm.getTotaldedAmt());
                callableStmt.setString(22, saveInvoiceForm.getInvtype());
                callableStmt.setString(23, saveInvoiceForm.getPreinvId());
                callableStmt.setString(24, saveInvoiceForm.getDedinvId());
                callableStmt.setString(25, saveInvoiceForm.getRcmfuncflag());
                
                callableStmt.execute();
               
                request.setAttribute("invoiceFlag","Y");
               
                 msg=callableStmt.getString(8);
                 request.setAttribute("supplierID",saveInvoiceForm.getSuppliernumber());
                 
                 if(msg.contains("Invoice has been submitted successfully") || msg.contains("Invoice has been updated successfully")) {
                	 if (null != files && fileNames.size() > 0)
                     {
                	for(int i=1;i<=fileNames.size();i++) {
                	 String query="insert into xxbaf_uploaded_file(AFP_NO,FILE_NAME,UPLOADED_DT,UPLAODED_BY,file_seq) values(?,?,sysdate,?,?)";
                	 prepareStmt=myConnection.prepareStatement(query);
                	 prepareStmt.setString(1, callableStmt.getString(7));
                	 prepareStmt.setString(2, (String) fileNames.get(i-1)!=null?(String) fileNames.get(i-1):"");
                	 prepareStmt.setString(3, loginID);
                	 prepareStmt.setInt(4, i);
                	 
                	 prepareStmt.executeUpdate();
                	} 
                	
                     }
                	 System.out.println("afpno"+callableStmt.getString(7));
                	 request.setAttribute("afpno",callableStmt.getString(7));
                	 afpno=callableStmt.getString(7);
                	 if(callableStmt!=null){
                     	callableStmt.close();
                     	callableStmt=null;
                     }
                	 callableStmt=myConnection.prepareCall("{call sendInvMail(?,?)}");
                	 callableStmt.setString(1,afpno);
                	 callableStmt.setString(2,submissionFlag);
                	 callableStmt.execute();
                	 
                	 request.setAttribute("invStatus","Submitted");
                     session.setAttribute("invStatus","Submitted");
                	 forward="redirect:/viewnewinvoice?msg="+msg+"&flag=viewInv&afpno="+afpno;
                 }
                               
                 else {
                
                
                System.out.println("in saveNewInvoiceAction-----"+callableStmt.getString(8));              
                
                request.setAttribute("msg", callableStmt.getString(8));
                
                forward="redirect:/createInvoice?msg="+msg;
                 }
            }
            catch(SQLException seq)
            
            {  try{myConnection.rollback();}catch(Exception tr) {}
            	seq.printStackTrace();
            	forward="redirect:/createInvoice?msg=Some Error Occurred";
            }
            catch(Exception e)
            {try{myConnection.rollback();}catch(Exception tr1) {}
                e.printStackTrace();
                forward="redirect:/createInvoice?msg=Some Error Occurred";
            }
            finally
            {
                   try 
                    {
                        if(callableStmt!=null){
                        	callableStmt.close();
                        	callableStmt=null;
                        }
                    	myConnection.close();
                       
                    } 
                    catch (Exception e)
                    {
                    	myConnection=null;
                    	error_msg = e.getMessage();
                     
                        return "failure";
                    }
                
            } 	
            return forward;
        //}
       
    }
    
    
    
    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver()
    {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(20848820);
        return multipartResolver;
    }
}

