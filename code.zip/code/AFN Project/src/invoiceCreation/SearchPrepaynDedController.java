package invoiceCreation;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import commonController.Connectionc;
import invoiceForms.SearchPrepaymentForm;

@Controller
public class SearchPrepaynDedController {

	
	@RequestMapping(value="/searchprepayment",  method = {RequestMethod.POST,RequestMethod.GET})
	public String getprepayment(ModelMap model, SearchPrepaymentForm searchForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		Connection conn;
	//	HttpSession session=request.getSession();
	//	String flag=request.getParameter("flag")!=null?request.getParameter("flag"):"-";
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		String msg="";
		conn=new Connectionc().getConnection();
		//String[]supplierdtls=null;
		ArrayList prepay=new ArrayList<>();
	String supplierid=request.getParameter("supplierid")!=null?request.getParameter("supplierid"):"";
	String siteid=request.getParameter("Siteid")!=null?request.getParameter("Siteid"):"";
		try {
			
			//if(flag.equals("search")) {
				
				String query=bundle.getString("getPrepaymentDtls");
				ps=conn.prepareStatement(query);
				ps.setString(1, supplierid);
				ps.setString(2, siteid);
				
				System.out.println(query);				
								
				rs=ps.executeQuery();
				
				while(rs.next()) {
					searchForm=new SearchPrepaymentForm();
					searchForm.setInvoiceId(rs.getString("INVOICE_ID")!=null?rs.getString("INVOICE_ID"):"-");
					searchForm.setPrepayNum(rs.getString("pre_pay_num")!=null?rs.getString("pre_pay_num"):"-");
					searchForm.setPrepayAmt(rs.getString("pre_pay_amt")!=null?rs.getString("pre_pay_amt"):"-");
					searchForm.setPrepayBal(rs.getString("pre_pay_bal")!=null?rs.getString("pre_pay_bal"):"-");
					searchForm.setAmountPaid(rs.getString("amount_paid")!=null?rs.getString("amount_paid"):"");
					
					prepay.add(searchForm);		
					
				}
				request.setAttribute("prepay", prepay);
				request.setAttribute("prepaySize", prepay.size());
				
		//	}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		return "searchPrepay";
	}
	
	@RequestMapping(value="/searchdeduction",  method = {RequestMethod.POST,RequestMethod.GET})
	public String getdeduction(ModelMap model, SearchPrepaymentForm searchForm , HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		Connection conn;
		ResultSet rs=null;
		ResourceBundle bundle = ResourceBundle.getBundle("view/sql");
		PreparedStatement ps=null;
		String msg="";
		conn=new Connectionc().getConnection();
		ArrayList deduction=new ArrayList<>();
	String supplierid=request.getParameter("supplierid")!=null?request.getParameter("supplierid"):"";
	String siteid=request.getParameter("Siteid")!=null?request.getParameter("Siteid"):"";
		try {
			
			//if(flag.equals("search")) {
				
				String query=bundle.getString("getDeductionDtls");
				ps=conn.prepareStatement(query);
				ps.setString(1, supplierid);
				ps.setString(2, siteid);
				
				System.out.println(query);				
								
				rs=ps.executeQuery();
				
				while(rs.next()) {
					searchForm=new SearchPrepaymentForm();
					searchForm.setDedInvId(rs.getString("INVOICE_ID")!=null?rs.getString("INVOICE_ID"):"-");
					searchForm.setCreditMemNo(rs.getString("CREDIT_MEMO_NUM")!=null?rs.getString("CREDIT_MEMO_NUM"):"-");
					searchForm.setCreditMemAmt(rs.getString("CREDIT_MEMO_AMT")!=null?rs.getString("CREDIT_MEMO_AMT"):"-");
					searchForm.setRemAmt(rs.getString("AMOUNT_REMAINING")!=null?rs.getString("AMOUNT_REMAINING"):"-");
					
					deduction.add(searchForm);		
					
				}
				request.setAttribute("deduction", deduction);
				request.setAttribute("deductionSize", deduction.size());
				
		//	}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		return "searchDeduction";
	}
}
